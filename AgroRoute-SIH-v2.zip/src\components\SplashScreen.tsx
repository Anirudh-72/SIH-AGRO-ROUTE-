import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const duration = 2500;
    const interval = 30;
    let elapsed = 0;

    const timer = setInterval(() => {
      elapsed += interval;
      setProgress(Math.min((elapsed / duration) * 100, 100));
      if (elapsed >= duration) {
        clearInterval(timer);
        setFadeOut(true);
        setTimeout(onComplete, 400);
      }
    }, interval);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-900 transition-opacity duration-400 ${
        fadeOut ? 'opacity-0' : 'opacity-100'
      }`}
    >
      {/* Decorative rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-96 h-96 rounded-full border border-emerald-700/30 animate-ping" style={{ animationDuration: '3s' }} />
        <div className="absolute w-64 h-64 rounded-full border border-emerald-600/30 animate-ping" style={{ animationDuration: '2s', animationDelay: '0.5s' }} />
      </div>

      {/* Logo Mark */}
      <div className="relative z-10 flex flex-col items-center gap-8">
        {/* Main Logo Icon */}
        <div className="relative">
          <div className="w-32 h-32 rounded-3xl bg-white flex items-center justify-center shadow-2xl border-4 border-emerald-400">
            <svg viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-20 h-20">
              {/* Wheat / plant stem */}
              <path d="M40 70 L40 25" stroke="#059669" strokeWidth="3" strokeLinecap="round"/>
              {/* Left grain */}
              <ellipse cx="28" cy="28" rx="10" ry="5" fill="#059669" transform="rotate(-40 28 28)"/>
              {/* Right grain */}
              <ellipse cx="52" cy="28" rx="10" ry="5" fill="#059669" transform="rotate(40 52 28)"/>
              {/* Center top grain */}
              <ellipse cx="40" cy="20" rx="10" ry="5" fill="#34d399" transform="rotate(-5 40 20)"/>
              {/* Route path */}
              <path d="M20 60 Q30 50 40 55 Q50 60 60 48" stroke="#0ea5e9" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="none"/>
              <circle cx="20" cy="60" r="3" fill="#0ea5e9"/>
              <circle cx="60" cy="48" r="3" fill="#0ea5e9"/>
              {/* Truck icon at route end */}
              <rect x="54" y="43" width="12" height="8" rx="1.5" fill="#0ea5e9"/>
              <circle cx="57" cy="52" r="2" fill="#065f89"/>
              <circle cx="63" cy="52" r="2" fill="#065f89"/>
            </svg>
          </div>
          {/* Glow ring */}
          <div className="absolute inset-0 rounded-3xl ring-4 ring-emerald-400/40 animate-pulse" />
        </div>

        {/* Brand Text */}
        <div className="text-center">
          <h1 className="text-5xl font-black text-white tracking-tight leading-none">
            AgroRoute
          </h1>
          <p className="text-emerald-300 font-bold text-lg mt-1 tracking-widest uppercase">
            Kisan Setu Portal
          </p>
          <p className="text-emerald-500 text-sm font-medium mt-2">
            Govt. of Andhra Pradesh · APMC Guntur
          </p>
        </div>

        {/* Progress bar */}
        <div className="w-64">
          <div className="w-full bg-emerald-900/60 h-1.5 rounded-full overflow-hidden border border-emerald-700/50">
            <div
              className="h-full bg-gradient-to-r from-emerald-400 to-teal-300 rounded-full transition-all duration-75 ease-linear"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-emerald-500 text-xs font-medium text-center mt-2">
            Loading…
          </p>
        </div>
      </div>

      {/* Bottom footer stamp */}
      <div className="absolute bottom-8 text-emerald-600 text-xs font-medium text-center px-4">
        Smart India Hackathon 2024 · Zero-Cash Direct-to-Farmer Platform
      </div>
    </div>
  );
};
