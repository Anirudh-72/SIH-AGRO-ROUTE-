import React, { useState, useMemo } from 'react';
import { SupportedLanguage } from '../data/translations';
import { FarmerAsk, BuyerBid, MatchedContract, LcvVehicle, BuyerProfile, PricePoint, GrievanceRecord } from '../types';
import { filterAsksByHaversine, GUNTUR_APMC_LAT, GUNTUR_APMC_LON, VIJAYAWADA_HUB_LAT, VIJAYAWADA_HUB_LON } from '../data/mockData';
import { FoliumRoutingMap } from './FoliumRoutingMap';
import { PriceDiscoveryChart } from './PriceDiscoveryChart';
import { DoubleAuctionConsole } from './DoubleAuctionConsole';
import { INITIAL_BUYERS } from '../firebase';
import {
  Building2,
  ShieldCheck,
  TrendingUp,
  Truck,
  PlusCircle,
  FileCheck2,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Clock,
  MapPin,
  Scale,
  DollarSign,
  Search,
  Filter,
  LogOut,
  ChevronRight,
  Printer,
  Sparkles,
  Phone,
  Layers,
  ArrowRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface BuyerPortalProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onReturnToModeSelection: () => void;
  farmerAsks: FarmerAsk[];
  buyerBids: BuyerBid[];
  matchedContracts: MatchedContract[];
  lcvVehicles: LcvVehicle[];
  priceData: PricePoint[];
  commodity: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton';
  onCommodityChange: (c: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton') => void;
  onAddBid: (bid: BuyerBid) => void;
  onRaiseGrievance: (grievance: GrievanceRecord) => void;
}

export const BuyerPortal: React.FC<BuyerPortalProps> = ({
  language,
  onLanguageChange,
  onReturnToModeSelection,
  farmerAsks,
  buyerBids,
  matchedContracts,
  lcvVehicles,
  priceData,
  commodity,
  onCommodityChange,
  onAddBid,
  onRaiseGrievance,
}) => {
  // Current logged in buyer (defaults to ITC for instant review, with quick switcher)
  const [activeBuyer, setActiveBuyer] = useState<BuyerProfile | null>(INITIAL_BUYERS[0]);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Active Tab: 'live_market' | 'place_bid' | 'my_contracts' | 'deliveries' | 'market_analytics'
  const [activeTab, setActiveTab] = useState<
    'live_market' | 'place_bid' | 'my_contracts' | 'deliveries' | 'market_analytics'
  >('live_market');

  // Hub selection & Pooling Radius
  const [selectedHub, setSelectedHub] = useState<'Guntur APMC Yard Hub' | 'Guntur Cold Storage Cluster' | 'Vijayawada Auto Nagar Yard'>(
    'Guntur APMC Yard Hub'
  );
  const [poolingRadiusKm, setPoolingRadiusKm] = useState<number>(8.0);
  const [marketSearch, setMarketSearch] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'distance' | 'price_asc' | 'price_desc' | 'moq_desc'>('distance');

  // Bid Form State
  const [bidCommodity, setBidCommodity] = useState<'Guntur Teja Mirchi' | 'Shankar-6 Cotton'>('Guntur Teja Mirchi');
  const [bidDemandQtl, setBidDemandQtl] = useState<number>(25); // 25 Quintals = 2500 KG
  const [bidPricePerQtl, setBidPricePerQtl] = useState<number>(22400);
  const [bidDeliveryHub, setBidDeliveryHub] = useState<string>('Guntur APMC Yard Hub');
  const [bidSuccessMessage, setBidSuccessMessage] = useState<string>('');
  
  // Step-Up Auth (MFA) State for Escrow Release
  const [mfaModalOpen, setMfaModalOpen] = useState<boolean>(false);
  const [mfaCode, setMfaCode] = useState<string>('');
  const [mfaContractId, setMfaContractId] = useState<string | null>(null);

  // Grievance Modal State
  const [grievanceContract, setGrievanceContract] = useState<MatchedContract | null>(null);
  const [grievanceCategory, setGrievanceCategory] = useState<'weighment' | 'quality_dispute' | 'payment_delay' | 'driver_issue'>('quality_dispute');
  const [grievanceDesc, setGrievanceDesc] = useState<string>('');
  const [grievanceSubmitted, setGrievanceSubmitted] = useState<boolean>(false);

  // Hub coordinates
  const hubCoords = useMemo(() => {
    if (selectedHub === 'Vijayawada Auto Nagar Yard') {
      return { lat: VIJAYAWADA_HUB_LAT, lon: VIJAYAWADA_HUB_LON };
    }
    if (selectedHub === 'Guntur Cold Storage Cluster') {
      return { lat: 16.3200, lon: 80.4500 };
    }
    return { lat: GUNTUR_APMC_LAT, lon: GUNTUR_APMC_LON };
  }, [selectedHub]);

  // Geofiltered farmer asks for this buyer
  const geofilteredAsks = useMemo(() => {
    let withDistance = filterAsksByHaversine(farmerAsks, hubCoords.lat, hubCoords.lon, poolingRadiusKm);
    withDistance = withDistance.filter((a) => {
      const matchCommodity = a.commodity === commodity;
      const matchSearch =
        marketSearch.trim() === '' ||
        a.name.toLowerCase().includes(marketSearch.toLowerCase()) ||
        a.village.toLowerCase().includes(marketSearch.toLowerCase()) ||
        a.farmer_id.toLowerCase().includes(marketSearch.toLowerCase());
      return matchCommodity && matchSearch;
    });

    // Multi-Parametric Sorting
    if (sortOrder === 'price_asc') {
      withDistance.sort((a, b) => a.ask_price_per_qtl - b.ask_price_per_qtl);
    } else if (sortOrder === 'price_desc') {
      withDistance.sort((a, b) => b.ask_price_per_qtl - a.ask_price_per_qtl);
    } else if (sortOrder === 'moq_desc') {
      withDistance.sort((a, b) => b.weight_kg - a.weight_kg);
    } else {
      withDistance.sort((a, b) => (a.distance_to_hub_km || 0) - (b.distance_to_hub_km || 0));
    }

    return withDistance;
  }, [farmerAsks, hubCoords, poolingRadiusKm, commodity, marketSearch, sortOrder]);

  // Contracts matched for this buyer
  const myContracts = useMemo(() => {
    if (!activeBuyer) return [];
    return matchedContracts.filter(
      (c) =>
        c.buyer_id === activeBuyer.buyer_id ||
        c.buyer_name.toLowerCase().includes(activeBuyer.business_name.toLowerCase())
    );
  }, [matchedContracts, activeBuyer]);

  // Open bids for this buyer
  const myOpenBids = useMemo(() => {
    if (!activeBuyer) return [];
    return buyerBids.filter(
      (b) =>
        b.bid_id.includes(activeBuyer.buyer_id.replace('B-', '')) ||
        b.buyer_name.toLowerCase().includes(activeBuyer.business_name.toLowerCase())
    );
  }, [buyerBids, activeBuyer]);

  // Handle placing a new bid
  const handlePlaceBid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBuyer) {
      setIsAuthModalOpen(true);
      return;
    }

    const demandKg = Math.round(bidDemandQtl * 100);
    const newBid: BuyerBid = {
      bid_id: `B-${activeBuyer.buyer_id.replace('B-', '')}-${Math.floor(100 + Math.random() * 900)}`,
      buyer_name: activeBuyer.business_name,
      hub_name: bidDeliveryHub,
      commodity: bidCommodity,
      demand_weight_kg: demandKg,
      bid_price_per_qtl: bidPricePerQtl,
      lat: hubCoords.lat,
      lon: hubCoords.lon,
      buyer_email: activeBuyer.email,
      created_at: new Date().toISOString(),
    };

    onAddBid(newBid);

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch (e) {
      // Confetti fallback
    }

    setBidSuccessMessage(
      language === 'te'
        ? `బిడ్ విజయవంతంగా నమోదైంది! ఆర్డర్ ID: ${newBid.bid_id}. డబుల్-ఆక్షన్ ఇంజిన్ ద్వారా రైతుల లాట్లతో మ్యాచ్ చేయబడుతోంది.`
        : `Bid submitted successfully! Order ID: ${newBid.bid_id}. Instant matching in progress via Continuous Double-Auction.`
    );

    setTimeout(() => {
      setBidSuccessMessage('');
      setActiveTab('my_contracts');
    }, 2200);
  };

  // Handle Quick Counter-Bid / Match on an Ask
  const handleQuickCounterBid = (ask: FarmerAsk) => {
    setBidCommodity(ask.commodity);
    setBidDemandQtl(Math.ceil(ask.weight_kg / 100));
    setBidPricePerQtl(ask.ask_price_per_qtl + 100); // Competitive bid
    setActiveTab('place_bid');
  };

  // Submit Grievance
  const handleSubmitGrievance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!grievanceContract || !activeBuyer) return;

    const record: GrievanceRecord = {
      grievance_id: `GRV-${Date.now().toString().slice(-6)}`,
      contract_id: grievanceContract.contract_id,
      raised_by: 'buyer',
      party_name: activeBuyer.business_name,
      phone: activeBuyer.phone,
      category: grievanceCategory,
      description: grievanceDesc || 'Dispute regarding lot moisture/grade at weighment hub.',
      status: 'Investigating',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };

    onRaiseGrievance(record);
    setGrievanceSubmitted(true);
    setTimeout(() => {
      setGrievanceSubmitted(false);
      setGrievanceContract(null);
      setGrievanceDesc('');
    }, 2000);
  };

  return (
    <div className="max-w-7xl mx-auto w-full space-y-6">
      {/* Top Buyer Portal Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 shadow-lg border-2 border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center text-3xl shadow-sm">
            🏢
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white">
                {activeBuyer ? activeBuyer.business_name : 'APMC Buyer Portal'}
              </h1>
              {activeBuyer?.verified && (
                <span className="inline-flex items-center gap-1 text-[11px] font-black bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded-full border border-emerald-500/40">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Govt-Verified APMC Trader
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 font-medium mt-1">
              License: <strong className="text-slate-200">{activeBuyer?.trader_license}</strong> | GSTIN: <span className="text-slate-300">{activeBuyer?.gstin}</span> | Hub: <span className="text-sky-300">{activeBuyer?.hub_name}</span>
            </p>
          </div>
        </div>

        {/* Top Actions: Buyer Switcher, Language & Exit */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick Demo Buyer Switcher */}
          <div className="flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700 text-xs">
            <span className="px-2 text-slate-400 text-[11px] font-bold">Trader:</span>
            {INITIAL_BUYERS.map((b) => (
              <button
                key={b.buyer_id}
                onClick={() => {
                  setActiveBuyer(b);
                  if (b.commodities[0]) {
                    setBidCommodity(b.commodities[0]);
                    onCommodityChange(b.commodities[0]);
                  }
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  activeBuyer?.buyer_id === b.buyer_id
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title={b.business_name}
              >
                {b.buyer_id.replace('B-', '')}
              </button>
            ))}
          </div>

          {/* Language Switcher */}
          <div className="flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700 text-xs font-bold">
            <button
              onClick={() => onLanguageChange('te')}
              className={`px-2 py-1 rounded-lg ${language === 'te' ? 'bg-white text-slate-900' : 'text-slate-300'}`}
            >
              తెలుగు
            </button>
            <button
              onClick={() => onLanguageChange('hi')}
              className={`px-2 py-1 rounded-lg ${language === 'hi' ? 'bg-white text-slate-900' : 'text-slate-300'}`}
            >
              हिंदी
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2 py-1 rounded-lg ${language === 'en' ? 'bg-white text-slate-900' : 'text-slate-300'}`}
            >
              EN
            </button>
          </div>

          {/* Return to Selection Button */}
          <button
            id="buyer-portal-exit-btn"
            onClick={onReturnToModeSelection}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-black flex items-center gap-1.5 border border-slate-700"
          >
            <RotateCcw className="w-3.5 h-3.5 text-sky-400" />
            <span>మోడ్ మార్చండి / Exit</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white p-1.5 rounded-2xl border border-gray-200 shadow-2xs flex gap-2 overflow-x-auto text-xs sm:text-sm font-black">
        <button
          onClick={() => setActiveTab('live_market')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'live_market' ? 'bg-sky-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Search className="w-4 h-4" />
          <span>రైతుల లైవ్ మార్కెట్ (Live Market Asks)</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] ${activeTab === 'live_market' ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-700'}`}>
            {geofilteredAsks.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('place_bid')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'place_bid' ? 'bg-sky-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          <span>కొత్త బిడ్ దాఖలు చేయండి (Place Bid)</span>
        </button>

        <button
          onClick={() => setActiveTab('my_contracts')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'my_contracts' ? 'bg-sky-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          <span>నా బిడ్లు & ఒప్పందాలు (My Contracts)</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] ${activeTab === 'my_contracts' ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-700'}`}>
            {myContracts.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('deliveries')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'deliveries' ? 'bg-sky-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>ఇన్‌కమింగ్ డెలివరీలు (Incoming Logistics)</span>
        </button>

        <button
          onClick={() => setActiveTab('market_analytics')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'market_analytics' ? 'bg-sky-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>ధరల విశ్లేషణ (Price Discovery)</span>
        </button>
      </div>

      {/* =================================================================== */}
      {/* TAB 1: LIVE MARKET (GEOFILTERED FARMER ASKS) */}
      {/* =================================================================== */}
      {activeTab === 'live_market' && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              {/* Commodity Toggle */}
              <div className="flex items-center bg-gray-100 p-1 rounded-xl border border-gray-200">
                <button
                  onClick={() => onCommodityChange('Guntur Teja Mirchi')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${
                    commodity === 'Guntur Teja Mirchi' ? 'bg-emerald-600 text-white shadow-xs' : 'text-gray-700'
                  }`}
                >
                  🌶️ Guntur Teja Mirchi
                </button>
                <button
                  onClick={() => onCommodityChange('Shankar-6 Cotton')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${
                    commodity === 'Shankar-6 Cotton' ? 'bg-sky-600 text-white shadow-xs' : 'text-gray-700'
                  }`}
                >
                  ☁️ Shankar-6 Cotton
                </button>
              </div>

              {/* Haversine Pooling Radius Selector */}
              <div className="flex items-center gap-1.5 text-xs font-bold text-gray-600 bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-200">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span>పూలింగ్ పరిధి (Radius):</span>
                <select
                  value={poolingRadiusKm}
                  onChange={(e) => setPoolingRadiusKm(Number(e.target.value))}
                  className="bg-white border border-gray-300 rounded-lg px-2 py-1 text-xs font-black text-gray-900"
                >
                  <option value={5}>5 km</option>
                  <option value={8}>8 km (APMC Standard)</option>
                  <option value={15}>15 km</option>
                  <option value={30}>30 km (District Wide)</option>
                </select>
              </div>
            </div>

            {/* Search and Sort */}
            <div className="flex items-center gap-3 w-full sm:w-auto">
              {/* Sort Selection */}
              <div className="flex items-center gap-1.5 text-xs font-bold text-gray-600 bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-200">
                <Filter className="w-4 h-4 text-sky-600" />
                <select
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as any)}
                  className="bg-white border border-gray-300 rounded-lg px-2 py-1 text-xs font-black text-gray-900 focus:outline-none"
                >
                  <option value="distance">దూరం (Proximity)</option>
                  <option value="price_asc">ధర: తక్కువ-ఎక్కువ (Price: Low-High)</option>
                  <option value="price_desc">ధర: ఎక్కువ-తక్కువ (Price: High-Low)</option>
                  <option value="moq_desc">పరిమాణం (MOQ: High-Low)</option>
                </select>
              </div>

              {/* Search Input */}
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-gray-400" />
                <input
                  type="text"
                  value={marketSearch}
                  onChange={(e) => setMarketSearch(e.target.value)}
                  placeholder="వెతకండి (Typo-Tolerant Search)..."
                  className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>
          </div>

          {/* Farmer Asks Grid */}
          {geofilteredAsks.length === 0 ? (
            <div className="bg-white p-12 rounded-2xl border border-gray-200 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-gray-100 text-gray-400 flex items-center justify-center text-xl mx-auto">
                🔍
              </div>
              <h3 className="text-base font-black text-gray-800">
                {poolingRadiusKm} కి.మీ పరిధిలో లభించే రైతుల లాట్లు లేవు
              </h3>
              <p className="text-xs text-gray-500 max-w-md mx-auto">
                పరిధిని (Radius) పెంచండి లేదా ఇతర పంటను ఎంచుకోండి. రైతులు పంట ఆర్డర్ నమోదు చేసిన వెంటనే ఇక్కడ ప్రత్యక్షమవుతుంది.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {geofilteredAsks.map((ask) => {
                const qtl = (ask.weight_kg / 100).toFixed(2);
                const totalEstimated = Math.round((ask.weight_kg / 100) * ask.ask_price_per_qtl);
                const isWithinRadius = ask.within_pooling_radius ?? true;

                return (
                  <div
                    key={ask.farmer_id}
                    className="bg-white rounded-2xl p-5 border border-gray-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
                  >
                    <div>
                      {/* Card Header: Channel & Distance */}
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-[11px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                          {ask.farmer_id}
                        </span>
                        <span
                          className={`text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                            isWithinRadius ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          <MapPin className="w-3 h-3" />
                          {ask.distance_to_hub_km ?? 4.2} km దూరం
                        </span>
                      </div>

                      {/* Farmer Name & Village */}
                      <h4 className="text-base font-black text-gray-900 leading-tight">
                        {ask.name}
                      </h4>
                      <p className="text-xs text-gray-500 font-semibold mt-0.5 flex items-center gap-1">
                        <span>గ్రామం: <strong>{ask.village}</strong></span>
                        <span>• VLE: {ask.vle_id}</span>
                      </p>

                      {/* Quantity & Ask Rate Box */}
                      <div className="mt-4 p-3 bg-gray-50 rounded-xl border border-gray-200 grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-gray-500 font-bold block text-[10px] uppercase">బరువు (Weight)</span>
                          <strong className="text-base font-black text-gray-900">{ask.weight_kg} kg</strong>
                          <span className="text-[11px] text-gray-500 block font-medium">({qtl} క్వింటాళ్లు)</span>
                        </div>
                        <div className="text-right">
                          <span className="text-gray-500 font-bold block text-[10px] uppercase">రైతు కోరిన ధర</span>
                          <strong className="text-base font-black text-emerald-800">
                            ₹{ask.ask_price_per_qtl.toLocaleString('en-IN')}
                          </strong>
                          <span className="text-[10px] text-gray-500 block font-semibold">ప్రతి క్వింటాల్ కు</span>
                        </div>
                      </div>

                      {/* Channel Indicator */}
                      {ask.channel && (
                        <div className="mt-2 text-[10px] font-bold text-gray-500 flex items-center gap-1">
                          <span>నమోదు విధానం:</span>
                          <span className="px-1.5 py-0.5 rounded bg-gray-100 text-gray-700 uppercase">
                            {ask.channel === 'ivr_simulated' ? '📞 IVR / కీప్యాడ్ కాల్' : ask.channel === 'touch' ? '🌾 కిసాన్ ATM' : '🏢 VLE అసిస్టెడ్'}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Action Button: Counter-Bid or Match */}
                    <button
                      onClick={() => handleQuickCounterBid(ask)}
                      className="w-full py-2.5 px-4 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-black flex items-center justify-center gap-2 shadow-xs transition-all active:scale-98"
                    >
                      <Scale className="w-4 h-4 text-sky-200" />
                      <span>ఈ లాట్ పై బిడ్ దాఖలు చేయండి</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 2: PLACE BID FLOW (FEED INTO CONTINUOUS DOUBLE AUCTION) */}
      {/* =================================================================== */}
      {activeTab === 'place_bid' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-gray-200 shadow-2xs space-y-6">
            <div className="border-b border-gray-100 pb-4">
              <span className="text-xs font-bold text-sky-700 uppercase tracking-wider bg-sky-50 px-2.5 py-1 rounded-full border border-sky-200">
                APMC e-Procurement Bidding
              </span>
              <h3 className="text-2xl font-black text-gray-900 mt-2">
                కొత్త కొనుగోలు బిడ్ నమోదు చేయండి
              </h3>
              <p className="text-xs text-gray-500 font-medium mt-1">
                మీరు పేర్కొనే గరిష్ట ధర మరియు పరిమాణం ఆధారంగా డబుల్-ఆక్షన్ అల్గారిథమ్ ఆటోమేటిక్‌గా రైతు లాట్లతో మ్యాచ్ చేస్తుంది.
              </p>
            </div>

            {bidSuccessMessage && (
              <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-2xl flex items-center gap-3 text-xs font-bold text-emerald-950">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{bidSuccessMessage}</span>
              </div>
            )}

            <form onSubmit={handlePlaceBid} className="space-y-5">
              {/* Commodity Selection */}
              <div>
                <label className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-2">
                  పంట ఎంపిక (Commodity)
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setBidCommodity('Guntur Teja Mirchi')}
                    className={`p-3.5 rounded-2xl border-2 text-left font-black text-xs transition-all ${
                      bidCommodity === 'Guntur Teja Mirchi'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-xs'
                        : 'border-gray-200 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <div className="text-lg mb-1">🌶️</div>
                    <div>Guntur Teja Mirchi</div>
                    <div className="text-[11px] text-gray-500 font-medium mt-0.5">మొడల్ ధర: ₹21,800/Qtl</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setBidCommodity('Shankar-6 Cotton')}
                    className={`p-3.5 rounded-2xl border-2 text-left font-black text-xs transition-all ${
                      bidCommodity === 'Shankar-6 Cotton'
                        ? 'border-sky-600 bg-sky-50 text-sky-950 shadow-xs'
                        : 'border-gray-200 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <div className="text-lg mb-1">☁️</div>
                    <div>Shankar-6 Cotton</div>
                    <div className="text-[11px] text-gray-500 font-medium mt-0.5">మొడల్ ధర: ₹7,450/Qtl</div>
                  </button>
                </div>
              </div>

              {/* Demand Quantity in Quintals */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-1.5">
                    డిమాండ్ పరిమాణం (Quintals)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min={1}
                      max={500}
                      value={bidDemandQtl}
                      onChange={(e) => setBidDemandQtl(Math.max(1, Number(e.target.value)))}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl text-sm font-black text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    />
                    <span className="absolute right-3 top-3.5 text-xs font-bold text-gray-400">
                      క్వింటాళ్లు ({bidDemandQtl * 100} kg)
                    </span>
                  </div>
                </div>

                {/* Bid Price per Quintal */}
                <div>
                  <label className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-1.5">
                    బిడ్ ధర (Rs. per Quintal)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min={1000}
                      step={50}
                      value={bidPricePerQtl}
                      onChange={(e) => setBidPricePerQtl(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl text-sm font-black text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    />
                    <span className="absolute right-3 top-3.5 text-xs font-bold text-gray-400">
                      ₹ / Qtl
                    </span>
                  </div>
                </div>
              </div>

              {/* Delivery Hub Location */}
              <div>
                <label className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-1.5">
                  డెలివరీ పాయింట్ / హబ్ (Delivery Hub)
                </label>
                <select
                  value={bidDeliveryHub}
                  onChange={(e) => setBidDeliveryHub(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl text-xs font-black text-gray-900 focus:bg-white focus:outline-none"
                >
                  <option value="Guntur APMC Yard Hub">Guntur APMC Yard Hub (Main Market Yard)</option>
                  <option value="Guntur Cold Storage Cluster">Guntur Cold Storage Cluster (Budge Budge Road)</option>
                  <option value="Vijayawada Auto Nagar Yard">Vijayawada Auto Nagar Yard (Krishna District)</option>
                </select>
              </div>

              {/* Submit Bid Button */}
              <button
                type="submit"
                className="w-full py-4 px-6 rounded-2xl bg-sky-700 hover:bg-sky-800 text-white font-black text-base flex items-center justify-center gap-3 shadow-md hover:shadow-lg transition-all active:scale-98"
              >
                <span>డబుల్-ఆక్షన్ బిడ్ సమర్పించండి (Submit Bid)</span>
                <ArrowRight className="w-5 h-5 text-sky-200" />
              </button>
            </form>
          </div>

          {/* Right Summary Card */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-4">
              <h4 className="text-sm font-black text-gray-900 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                బిడ్ ఆర్థిక గణన (Estimated Financials)
              </h4>

              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200 space-y-2.5 text-xs">
                <div className="flex justify-between text-gray-600">
                  <span>మొత్తం బరువు:</span>
                  <strong className="text-gray-900">{bidDemandQtl * 100} kg ({bidDemandQtl} క్వింటాళ్లు)</strong>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>బిడ్ రేటు:</span>
                  <strong className="text-sky-800">₹{bidPricePerQtl.toLocaleString('en-IN')}/Qtl</strong>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>గరిష్ట చెల్లింపు విలువ:</span>
                  <strong className="text-gray-900 font-black">
                    ₹{(bidDemandQtl * bidPricePerQtl).toLocaleString('en-IN')}
                  </strong>
                </div>
                <div className="border-t border-gray-200 pt-2 flex justify-between text-emerald-800 font-bold">
                  <span>ఎస్క్రో రక్షణ:</span>
                  <span>100% NPCI Zero-Cash Guaranteed</span>
                </div>
              </div>

              <div className="p-4 bg-sky-50 rounded-2xl border border-sky-200 text-xs text-sky-950 space-y-1.5">
                <div className="font-black flex items-center gap-1.5 text-sky-900">
                  <Sparkles className="w-4 h-4 text-sky-600" />
                  ఆటోమేటిక్ డబుల్-ఆక్షన్ క్లియరింగ్
                </div>
                <p className="text-[11px] leading-relaxed text-sky-800 font-medium">
                  మీ బిడ్ ధర రైతు ఆస్క్ ధర కంటే సమానంగా లేదా ఎక్కువగా ఉన్నప్పుడు, క్లియరింగ్ ధర = (Bid + Ask) / 2 సూత్రం ద్వారా ఒప్పందం ఖరారవుతుంది. మిగులు మొత్తం (Surplus) నేరుగా మీకు ఆదా అవుతుంది!
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 3: MY BIDS & CONTRACTS */}
      {/* =================================================================== */}
      {activeTab === 'my_contracts' && (
        <div className="space-y-6">
          {/* Summary KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-2xs">
              <div className="text-xs font-bold text-gray-500 uppercase">ఖరారైన ఒప్పందాలు</div>
              <div className="text-2xl font-black text-gray-900 mt-1">{myContracts.length} లాట్లు</div>
              <div className="text-[11px] text-emerald-700 font-bold mt-1">100% APMC కంప్లైంట్</div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-2xs">
              <div className="text-xs font-bold text-gray-500 uppercase">మొత్తం సేకరించిన విలువ</div>
              <div className="text-2xl font-black text-sky-800 mt-1">
                ₹{myContracts.reduce((sum, c) => sum + c.total_cleared_value, 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[11px] text-gray-500 font-medium mt-1">
                {myContracts.reduce((sum, c) => sum + c.weight_kg, 0)} kg సరుకు
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-2xs">
              <div className="text-xs font-bold text-gray-500 uppercase">కొనుగోలుదారు మిగులు (Savings)</div>
              <div className="text-2xl font-black text-emerald-800 mt-1">
                +₹{myContracts.reduce((sum, c) => sum + c.buyer_surplus, 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[11px] text-emerald-700 font-bold mt-1">డబుల్-ఆక్షన్ ద్వారా ఆదా</div>
            </div>
          </div>

          {/* Matched Contracts Table */}
          <div className="bg-white rounded-3xl border border-gray-200 shadow-2xs overflow-hidden">
            <div className="p-5 border-b border-gray-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-black text-gray-900">
                  ఖరారైన కొనుగోలు ఒప్పందాలు (Executed Contracts)
                </h3>
                <p className="text-xs text-gray-500 font-medium">
                  {activeBuyer?.business_name} ఖాతాకు కేటాయించబడిన రైతుల లాట్లు
                </p>
              </div>
            </div>

            {myContracts.length === 0 ? (
              <div className="p-12 text-center text-gray-500 text-xs">
                ప్రస్తుతం ఎటువంటి ఖరారైన ఒప్పందాలు లేవు. "కొత్త బిడ్ దాఖలు చేయండి" ట్యాబ్ లో బిడ్ సమర్పించండి.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-gray-50 text-gray-500 font-bold border-b border-gray-200 uppercase text-[10px]">
                    <tr>
                      <th className="px-4 py-3">ఒప్పందం ID</th>
                      <th className="px-4 py-3">రైతు & గ్రామం</th>
                      <th className="px-4 py-3">పంట</th>
                      <th className="px-4 py-3">బరువు (KG)</th>
                      <th className="px-4 py-3">ఎస్క్రో స్థితి (Escrow)</th>
                      <th className="px-4 py-3">మొత్తం విలువ</th>
                      <th className="px-4 py-3">చర్య / రశీదు</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {myContracts.map((c) => {
                      const escrowStatus = c.escrow_status || 'DELIVERED';
                      return (
                        <tr key={c.contract_id} className="hover:bg-gray-50">
                          <td className="px-4 py-3 font-mono font-bold text-sky-800">
                            {c.contract_id}
                          </td>
                          <td className="px-4 py-3">
                            <strong className="text-gray-900 block">{c.farmer_name}</strong>
                            <span className="text-gray-500 text-[11px]">{c.village} ({c.vle_id})</span>
                          </td>
                          <td className="px-4 py-3 font-semibold text-gray-800">
                            {c.commodity}
                          </td>
                          <td className="px-4 py-3 font-black text-gray-900">
                            {c.weight_kg} kg
                          </td>
                          <td className="px-4 py-3">
                            {escrowStatus === 'LOCKED' && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-800 border border-gray-200">
                                🔒 LOCKED
                              </span>
                            )}
                            {escrowStatus === 'IN_TRANSIT' && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                                🚚 IN_TRANSIT
                              </span>
                            )}
                            {escrowStatus === 'DELIVERED' && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                                📦 DELIVERED
                              </span>
                            )}
                            {escrowStatus === 'SETTLED' && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                ✅ SETTLED
                              </span>
                            )}
                            {escrowStatus === 'DISPUTED' && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800 border border-red-200">
                                ⚠️ DISPUTED
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 font-black text-gray-900">
                            ₹{c.total_cleared_value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex flex-wrap items-center gap-1.5">
                              {escrowStatus === 'DELIVERED' && (
                                <button
                                  onClick={() => {
                                    setMfaContractId(c.contract_id);
                                    setMfaModalOpen(true);
                                  }}
                                  className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold shadow-xs"
                                >
                                  Release Funds
                                </button>
                              )}
                              <button
                                onClick={() => {
                                  setGrievanceContract(c);
                                }}
                                className="px-2 py-1 rounded bg-amber-50 hover:bg-amber-100 text-amber-800 text-[11px] font-bold border border-amber-300"
                                title="Raise grievance on this contract"
                              >
                                సమస్య (Dispute)
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 4: INCOMING DELIVERIES & LOGISTICS */}
      {/* =================================================================== */}
      {activeTab === 'deliveries' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-black text-gray-900">
                హబ్ వైపు వస్తున్న 2-టన్నుల LCV వాహనాల రూటింగ్
              </h3>
              <p className="text-xs text-gray-500 font-medium">
                {activeBuyer?.hub_name} వైపు బయలుదేరిన వాహనాలు మరియు రవాణా స్థితి
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
              ● GPS లైవ్ మానిటరింగ్
            </span>
          </div>

          <FoliumRoutingMap
            lcvVehicles={lcvVehicles}
            poolingRadiusKm={poolingRadiusKm}
            allAsks={matchedContracts}
          />
        </div>
      )}

      {/* =================================================================== */}
      {/* TAB 5: MARKET ANALYTICS */}
      {/* =================================================================== */}
      {activeTab === 'market_analytics' && (
        <div className="space-y-6">
          <PriceDiscoveryChart
            data={priceData}
            commodity={commodity}
            onCommodityChange={onCommodityChange}
          />

          <DoubleAuctionConsole
            matchedContracts={matchedContracts}
            asks={geofilteredAsks}
            bids={buyerBids}
            commodity={commodity}
            onAddAsk={() => {}}
            onAddBid={onAddBid}
          />
        </div>
      )}

      {/* Step-Up Auth (MFA) Modal for Escrow Release */}
      {mfaModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 border-2 border-emerald-500 shadow-2xl space-y-4">
            <div className="text-center space-y-2 mb-2">
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-3xl shrink-0 mx-auto">
                🛡️
              </div>
              <h3 className="text-lg font-black text-gray-900">
                Step-Up Authentication
              </h3>
              <p className="text-xs text-gray-500 font-medium">
                You are about to release funds from the NPCI Escrow to the farmer's bank account for Contract {mfaContractId}. This is an irreversible financial action.
              </p>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-bold text-gray-700 text-center">
                Enter 6-digit TOTP / SMS Code sent to your registered mobile
              </label>
              <input
                type="text"
                placeholder="• • • • • •"
                maxLength={6}
                value={mfaCode}
                onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, ''))}
                className="w-full text-center tracking-[0.5em] text-2xl px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl font-black text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setMfaModalOpen(false);
                  setMfaCode('');
                }}
                className="flex-1 px-4 py-3 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (mfaCode.length === 6) {
                    alert(`Funds released successfully! Contract ${mfaContractId} is now SETTLED. Split payout executed via API Gateway.`);
                    setMfaModalOpen(false);
                    setMfaCode('');
                  } else {
                    alert('Please enter a valid 6-digit code.');
                  }
                }}
                className="flex-1 px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-xs"
              >
                Release Funds
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Grievance Modal */}
      {grievanceContract && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border-2 border-gray-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <h3 className="text-base font-black text-gray-900 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-amber-600" />
                ఒప్పందంపై సమస్య నమోదు (Raise Grievance)
              </h3>
              <button
                onClick={() => setGrievanceContract(null)}
                className="text-gray-400 hover:text-gray-600 font-black text-lg"
              >
                ✕
              </button>
            </div>

            {grievanceSubmitted ? (
              <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-300 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <h4 className="text-sm font-black text-emerald-950">సమస్య విజయవంతంగా నమోదైంది!</h4>
                <p className="text-xs text-emerald-800">
                  APMC ఆడిట్ టీమ్ మరియు CSC ఆపరేటర్ 2 గంటల్లో విచారణ జరిపి పరిష్కరిస్తారు.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitGrievance} className="space-y-3.5 text-xs">
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 space-y-1">
                  <div>ఒప్పందం: <strong>{grievanceContract.contract_id}</strong></div>
                  <div>రైతు: <strong>{grievanceContract.farmer_name} ({grievanceContract.village})</strong></div>
                  <div>పరిమాణం: <strong>{grievanceContract.weight_kg} kg</strong></div>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">సమస్య రకం (Category)</label>
                  <select
                    value={grievanceCategory}
                    onChange={(e: any) => setGrievanceCategory(e.target.value)}
                    className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-xl font-semibold"
                  >
                    <option value="quality_dispute">నాణ్యత / తేమ శాతం వివాదం (Quality/Moisture Dispute)</option>
                    <option value="weighment">తూకం వ్యత్యాసం (Weighment Discrepancy)</option>
                    <option value="driver_issue">వాహన డెలివరీ ఆలస్యం (Delivery Delay)</option>
                    <option value="payment_delay">చెల్లింపు సమస్య (Escrow Issue)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-1">వివరాలు (Description)</label>
                  <textarea
                    rows={3}
                    value={grievanceDesc}
                    onChange={(e) => setGrievanceDesc(e.target.value)}
                    placeholder="సమస్య వివరాలను ఇక్కడ రాయండి..."
                    className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-xl font-medium focus:bg-white focus:outline-none"
                    required
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setGrievanceContract(null)}
                    className="px-4 py-2 rounded-xl bg-gray-100 text-gray-700 font-bold"
                  >
                    రద్దు చేయండి
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-black"
                  >
                    సమర్పించండి
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
