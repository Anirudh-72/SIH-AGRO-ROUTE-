# AgroRoute Kisan Setu — Smart India Hackathon 2024

**Zero-Cash Direct-to-Farmer APMC Platform · Guntur, Andhra Pradesh**

---

## Quick Start (Run Locally)

### Prerequisites

Install one of the following:
- **Node.js** v18+ from https://nodejs.org  
- **Bun** from https://bun.sh  

### Install & Run

```bash
# Using npm (if Node.js installed)
npm install
npm run dev

# Using bun (faster)
bun install
bun run dev
```

Then open **http://localhost:3000** in your browser.

---

## How to Use the App

### App Flow
1. **Splash Screen** — AgroRoute logo loads for ~2.5 seconds
2. **Mode Selection** — Choose your role (clean vertical list)
3. **Your Portal** — Full portal loads in selected mode

### Language Settings
- Select **Telugu / हिंदी / English** on the Mode Selection screen
- The **entire app** switches to that language — no mixed language content
- Language selector also available in Kisan ATM header and Operator Portal burger menu

---

## Portal Modes

### Kisan Mode (Farmer)
- Book doorstep truck pickup for any crop
- View today's guaranteed APMC market rates (16 crops)
- Check bank deposit receipt (Aadhaar DBT)
- View order history (new!)

### Operator Mode (VLE / CSC)
**Demo Login:** ID: `VLE-GNT-402` | PIN: `1234` (or 1-Click Demo Login)

#### Aadhaar Search Flow (New!)
1. Enter 12-digit Aadhaar number in search box
2. System searches farmer database
3. If found → confirm identity (name + village + phone last 4)
4. If verified → proceed to order form (pre-filled)
5. If not registered → fill signup form → save to database → proceed

**Demo Aadhaar numbers to try:**
- `987600004012` — K. Venkateswara Rao, Tadikonda
- `876500008834` — V. Sambasiva Rao, Tadikonda  
- `765400001902` — K. Venkata Reddy, Mangalagiri
- Any other 12-digit number → triggers new farmer registration

#### Navigation
- Click the **hamburger menu** (≡) top-left to navigate between sections
- Sections: Order Entry | Order History | Crop Prices | Logistics Engine

### Buyer Mode (APMC Trader)
- Place bids on farmer produce lots
- View matched contracts and live price discovery

### IVR Mode (Feature Phone)
- Simulates SMS/IVRS booking for farmers without smartphones

### Admin Mode (District Collector)
- District-level analytics and grievance management

---

## Features Added in v2

| Feature | Status |
|---------|--------|
| Splash screen with animated logo | ✅ |
| Strict language enforcement (no mixing) | ✅ |
| Burger/hamburger side drawer in Operator | ✅ |
| Farmer Aadhaar search (12-digit) | ✅ |
| Identity confirmation questions | ✅ |
| New farmer registration flow | ✅ |
| Farmer database (localStorage) | ✅ |
| Order history — Operator view | ✅ |
| Order history — Kisan ATM view | ✅ |
| Removed all graphs/charts from farmer UI | ✅ |
| Clean mode selection (no bullet points) | ✅ |
| Removed unnecessary emojis | ✅ |
| Vertical card layout (no side-by-side) | ✅ |

---

## Tech Stack

- **React 18** + **TypeScript** + **Vite**
- **Tailwind CSS** for styling
- **Firebase / Firestore** for real-time data sync
- **Lucide React** for icons
- **canvas-confetti** for success animations
- Farmer database: **localStorage** with seed data for demo

---

## Environment Setup (Optional Firebase)

Copy `.env.example` to `.env` and fill in your Firebase config:

```bash
cp .env.example .env
```

The app works offline without Firebase (falls back to localStorage).

---

## Project Structure

```
src/
├── App.tsx                    # Main router + state
├── components/
│   ├── SplashScreen.tsx       # NEW: animated logo splash
│   ├── ModeSelectionScreen.tsx # Rebuilt: clean vertical list
│   ├── KisanAtmView.tsx       # Rebuilt: ATM UI, history screen
│   ├── OperatorPortal.tsx     # Rebuilt: burger menu, Aadhaar search
│   └── ...
├── data/
│   ├── farmerDatabase.ts      # NEW: farmer profile DB
│   ├── translations.ts        # Updated: all new keys (te/hi/en)
│   ├── farmerActivityData.ts  # Updated: aadhaarFull field
│   └── cropsAndUnits.ts       # 16 APMC crops with prices
└── utils/
    └── speechUtils.ts         # Vernacular TTS (voice output)
```

---

*Built for Smart India Hackathon 2024 · Team AgroRoute · Govt. of Andhra Pradesh APMC Digitization Initiative*
