import React, { useState } from 'react';
import { FarmerAsk, BuyerBid, MatchedContract } from '../types';
import { Scale, CheckCircle, ArrowRight, UserPlus, Coins, ShieldAlert } from 'lucide-react';

interface DoubleAuctionConsoleProps {
  matchedContracts: MatchedContract[];
  asks: FarmerAsk[];
  bids: BuyerBid[];
  commodity: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton';
  onAddAsk: (ask: FarmerAsk) => void;
  onAddBid: (bid: BuyerBid) => void;
}

export const DoubleAuctionConsole: React.FC<DoubleAuctionConsoleProps> = ({
  matchedContracts,
  asks,
  bids,
  commodity,
  onAddAsk,
  onAddBid,
}) => {
  const [activeTab, setActiveTab] = useState<'matched' | 'asks' | 'bids'>('matched');
  const [showAddModal, setShowAddModal] = useState(false);
  const [modalType, setModalType] = useState<'ask' | 'bid'>('ask');

  // Form State
  const [name, setName] = useState('');
  const [villageOrHub, setVillageOrHub] = useState('');
  const [weightKg, setWeightKg] = useState('500');
  const [pricePerQtl, setPricePerQtl] = useState(commodity === 'Guntur Teja Mirchi' ? '21700' : '7450');

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (modalType === 'ask') {
      const newAsk: FarmerAsk = {
        farmer_id: `F-AP-${Math.floor(100 + Math.random() * 900)}`,
        name: name || 'New Farmer Seller',
        village: villageOrHub || 'Guntur Mandal',
        commodity,
        weight_kg: parseFloat(weightKg) || 400,
        ask_price_per_qtl: parseFloat(pricePerQtl) || 21500,
        lat: 16.32 + (Math.random() - 0.5) * 0.1,
        lon: 80.45 + (Math.random() - 0.5) * 0.1,
        vle_id: 'VLE-GNT-02',
        contact: '99887*****',
      };
      onAddAsk(newAsk);
    } else {
      const newBid: BuyerBid = {
        bid_id: `B-CORP-${Math.floor(100 + Math.random() * 900)}`,
        buyer_name: name || 'Agri Export Corporation',
        hub_name: villageOrHub || 'Guntur APMC Yard Hub',
        commodity,
        demand_weight_kg: parseFloat(weightKg) || 1500,
        bid_price_per_qtl: parseFloat(pricePerQtl) || 22200,
        lat: 16.3067,
        lon: 80.4365,
      };
      onAddBid(newBid);
    }
    setShowAddModal(false);
    setName('');
    setVillageOrHub('');
  };

  const totalClearedWeight = matchedContracts.reduce((acc, c) => acc + c.weight_kg, 0);
  const totalClearedValue = matchedContracts.reduce((acc, c) => acc + c.total_cleared_value, 0);
  const totalFarmerSurplus = matchedContracts.reduce((acc, c) => acc + c.farmer_surplus, 0);
  const totalBuyerSurplus = matchedContracts.reduce((acc, c) => acc + c.buyer_surplus, 0);

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="p-5 border-b border-gray-100 flex flex-wrap items-center justify-between gap-4 bg-gray-50/70">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1 bg-emerald-100 text-emerald-700 rounded-md">
              <Scale className="w-4 h-4" />
            </span>
            <h3 className="text-base font-bold text-gray-900">
              Continuous Double-Auction Clearing Engine
            </h3>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-sky-50 text-sky-700 border border-sky-200">
              {commodity}
            </span>
          </div>
          <p className="text-xs text-gray-500">
            Deterministic mid-point price clearing rule: <code className="bg-gray-100 px-1.5 py-0.5 rounded text-gray-800 font-mono font-bold">P_clearing = (Bid + Ask) / 2</code> whenever <code className="text-emerald-700 font-bold">Bid ≥ Ask</code>.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setModalType('ask');
              setPricePerQtl(commodity === 'Guntur Teja Mirchi' ? '21600' : '7400');
              setShowAddModal(true);
            }}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <UserPlus className="w-3.5 h-3.5" />
            + Submit Farmer Ask
          </button>
          <button
            onClick={() => {
              setModalType('bid');
              setPricePerQtl(commodity === 'Guntur Teja Mirchi' ? '22300' : '7650');
              setShowAddModal(true);
            }}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-sky-600 hover:bg-sky-700 text-white flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Coins className="w-3.5 h-3.5" />
            + Submit Buyer Bid
          </button>
        </div>
      </div>

      {/* Clearing Summary Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 border-b border-gray-100 bg-gray-50/40">
        <div className="bg-white p-3 rounded-lg border border-gray-200">
          <div className="text-[11px] font-semibold text-gray-500 uppercase">Cleared Volume</div>
          <div className="text-lg font-bold text-gray-900">
            {totalClearedWeight.toLocaleString('en-IN')} <span className="text-xs font-normal">kg</span>
          </div>
          <div className="text-xs text-emerald-600 font-medium">{matchedContracts.length} lots traded</div>
        </div>

        <div className="bg-white p-3 rounded-lg border border-gray-200">
          <div className="text-[11px] font-semibold text-gray-500 uppercase">Gross Cleared Value</div>
          <div className="text-lg font-bold text-emerald-700">
            ₹{totalClearedValue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-gray-500">Zero broker commissions</div>
        </div>

        <div className="bg-white p-3 rounded-lg border border-gray-200">
          <div className="text-[11px] font-semibold text-gray-500 uppercase">Farmer Economic Surplus</div>
          <div className="text-lg font-bold text-sky-700">
            +₹{totalFarmerSurplus.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-sky-600">Direct gain above ask</div>
        </div>

        <div className="bg-white p-3 rounded-lg border border-gray-200">
          <div className="text-[11px] font-semibold text-gray-500 uppercase">Buyer Economic Surplus</div>
          <div className="text-lg font-bold text-indigo-700">
            +₹{totalBuyerSurplus.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-xs text-indigo-600">Savings below max bid</div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200 px-5 flex gap-6 bg-white">
        <button
          onClick={() => setActiveTab('matched')}
          className={`py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'matched'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-gray-500 hover:text-gray-900'
          }`}
        >
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          Matched Contracts ({matchedContracts.length})
        </button>
        <button
          onClick={() => setActiveTab('asks')}
          className={`py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'asks'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-gray-500 hover:text-gray-900'
          }`}
        >
          👨‍🌾 Active Farmer Asks ({asks.filter((a) => a.commodity === commodity).length})
        </button>
        <button
          onClick={() => setActiveTab('bids')}
          className={`py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'bids'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-gray-500 hover:text-gray-900'
          }`}
        >
          🏢 Buyer Bids ({bids.filter((b) => b.commodity === commodity).length})
        </button>
      </div>

      {/* Tab Contents */}
      <div className="p-4 overflow-x-auto">
        {activeTab === 'matched' && (
          <div>
            {matchedContracts.length === 0 ? (
              <div className="text-center py-10 text-gray-400 text-sm">
                No matching bids and asks found for {commodity} within the spatial geofence.
              </div>
            ) : (
              <table className="w-full text-left text-xs text-gray-600">
                <thead className="text-[11px] font-bold text-gray-500 uppercase bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="py-2.5 px-3">Contract ID</th>
                    <th className="py-2.5 px-3">Farmer & Village</th>
                    <th className="py-2.5 px-3">Matched Buyer</th>
                    <th className="py-2.5 px-3 text-right">Cleared Qty</th>
                    <th className="py-2.5 px-3 text-right">Ask / Bid Rate</th>
                    <th className="py-2.5 px-3 text-right">Clearing Rate (₹/qtl)</th>
                    <th className="py-2.5 px-3 text-right">Net Value</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {matchedContracts.map((c) => (
                    <tr key={c.contract_id} className="hover:bg-gray-50/80 transition-colors">
                      <td className="py-2.5 px-3 font-mono font-bold text-emerald-700">{c.contract_id}</td>
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-gray-900">{c.farmer_name}</div>
                        <div className="text-[11px] text-gray-500">{c.village} ({c.vle_id})</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-medium text-gray-800">{c.buyer_name}</div>
                        <div className="text-[11px] text-gray-500">{c.buyer_id}</div>
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-gray-900">
                        {c.weight_kg} kg
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-[11px]">
                        <span className="text-gray-500">₹{c.farmer_ask_qtl}</span> /{' '}
                        <span className="text-sky-600 font-semibold">₹{c.buyer_bid_qtl}</span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <span className="inline-block px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold font-mono">
                          ₹{c.clearing_price_qtl}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-gray-900">
                        ₹{c.total_cleared_value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-800">
                          MATCHED
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {activeTab === 'asks' && (
          <table className="w-full text-left text-xs text-gray-600">
            <thead className="text-[11px] font-bold text-gray-500 uppercase bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="py-2.5 px-3">Farmer ID</th>
                <th className="py-2.5 px-3">Farmer Name</th>
                <th className="py-2.5 px-3">Village</th>
                <th className="py-2.5 px-3 text-right">Lot Weight</th>
                <th className="py-2.5 px-3 text-right">Ask Price (₹/qtl)</th>
                <th className="py-2.5 px-3 text-right">Hub Distance</th>
                <th className="py-2.5 px-3 text-center">Haversine Filter</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {asks
                .filter((a) => a.commodity === commodity)
                .map((a) => (
                  <tr key={a.farmer_id} className="hover:bg-gray-50/80 transition-colors">
                    <td className="py-2.5 px-3 font-mono font-medium text-gray-800">{a.farmer_id}</td>
                    <td className="py-2.5 px-3 font-bold text-gray-900">{a.name}</td>
                    <td className="py-2.5 px-3">{a.village}</td>
                    <td className="py-2.5 px-3 text-right font-semibold">{a.weight_kg} kg</td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-700">₹{a.ask_price_per_qtl}</td>
                    <td className="py-2.5 px-3 text-right font-mono">{a.distance_to_hub_km ?? '--'} km</td>
                    <td className="py-2.5 px-3 text-center">
                      {a.within_pooling_radius ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          POOLABLE (≤8km)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                          OUTSIDE RADIUS
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        )}

        {activeTab === 'bids' && (
          <table className="w-full text-left text-xs text-gray-600">
            <thead className="text-[11px] font-bold text-gray-500 uppercase bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="py-2.5 px-3">Bid ID</th>
                <th className="py-2.5 px-3">Buyer Enterprise</th>
                <th className="py-2.5 px-3">Receiving Terminal</th>
                <th className="py-2.5 px-3 text-right">Demand Capacity</th>
                <th className="py-2.5 px-3 text-right">Max Willingness to Pay</th>
                <th className="py-2.5 px-3 text-center">Escrow Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {bids
                .filter((b) => b.commodity === commodity)
                .map((b) => (
                  <tr key={b.bid_id} className="hover:bg-gray-50/80 transition-colors">
                    <td className="py-2.5 px-3 font-mono font-medium text-gray-800">{b.bid_id}</td>
                    <td className="py-2.5 px-3 font-bold text-gray-900">{b.buyer_name}</td>
                    <td className="py-2.5 px-3">{b.hub_name}</td>
                    <td className="py-2.5 px-3 text-right font-semibold">{b.demand_weight_kg} kg</td>
                    <td className="py-2.5 px-3 text-right font-bold text-sky-700">₹{b.bid_price_per_qtl} / qtl</td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800">
                        ESCROW FUNDED
                      </span>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal to add Ask/Bid */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-5 border border-gray-200 animate-in fade-in zoom-in-95">
            <h4 className="text-base font-bold text-gray-900 mb-1">
              {modalType === 'ask' ? '👨‍🌾 Submit Farmer Sell Ask' : '🏢 Submit Institutional Buyer Bid'}
            </h4>
            <p className="text-xs text-gray-500 mb-4">
              Enter test parameters. The continuous double-auction matcher clears orders deterministically in real-time.
            </p>

            <form onSubmit={handleCreateOrder} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {modalType === 'ask' ? 'Farmer Name' : 'Company Name'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={modalType === 'ask' ? 'e.g., K. Rama Mohan Rao' : 'e.g., Godrej Agrovet Ltd'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full text-xs p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {modalType === 'ask' ? 'Mandal / Village (near Guntur/Vijayawada)' : 'Receiving Yard'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={modalType === 'ask' ? 'e.g., Mangalagiri Rural' : 'e.g., Guntur APMC Hub Yard'}
                  value={villageOrHub}
                  onChange={(e) => setVillageOrHub(e.target.value)}
                  className="w-full text-xs p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    min="50"
                    max="5000"
                    required
                    value={weightKg}
                    onChange={(e) => setWeightKg(e.target.value)}
                    className="w-full text-xs p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Rate (₹ / Quintal)</label>
                  <input
                    type="number"
                    min="1000"
                    max="50000"
                    required
                    value={pricePerQtl}
                    onChange={(e) => setPricePerQtl(e.target.value)}
                    className="w-full text-xs p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3.5 py-1.5 text-xs font-medium text-gray-600 hover:text-gray-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs"
                >
                  Confirm & Clear Auction
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
