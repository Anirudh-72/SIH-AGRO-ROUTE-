import React, { useState } from 'react';
import { SupportedLanguage, TRANSLATIONS } from '../data/translations';
import { ALL_CROPS, INDIAN_WEIGHT_UNITS } from '../data/cropsAndUnits';
import { FarmerOrderRecord, INITIAL_FARMER_ORDERS } from '../data/farmerActivityData';
import {
  findFarmerByAadhaar,
  registerFarmer,
  FarmerRegistrationRecord,
} from '../data/farmerDatabase';
import {
  Menu,
  X,
  Building2,
  UserCheck,
  Search,
  PlusCircle,
  FileText,
  TrendingUp,
  Truck,
  CheckCircle2,
  Printer,
  LogOut,
  AlertCircle,
  ShieldCheck,
  Sparkles,
  Globe,
  ArrowLeft,
  User,
  AlertTriangle,
  Clock,
  History,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface OperatorPortalProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onReturnToModeSelection: () => void;
  onSwitchToKisanMode: () => void;
  renderEngineTab?: () => React.ReactNode;
}

type Tab = 'order_entry' | 'farmer_activity' | 'crop_prices' | 'logistics_engine';

// Farmer identity confirmation state
type SearchState = 'idle' | 'found' | 'not_found' | 'confirming' | 'confirmed' | 'failed' | 'registering';

export const OperatorPortal: React.FC<OperatorPortalProps> = ({
  language,
  onLanguageChange,
  onReturnToModeSelection,
  onSwitchToKisanMode,
  renderEngineTab,
}) => {
  const t = TRANSLATIONS[language];

  // Auth
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [vleId, setVleId] = useState('VLE-GNT-402');
  const [vlePin, setVlePin] = useState('1234');
  const [centerName, setCenterName] = useState('Tadikonda Gram Panchayat CSC #402');
  const [loginError, setLoginError] = useState('');

  // Burger menu
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('order_entry');

  // Farmer orders
  const [orders, setOrders] = useState<FarmerOrderRecord[]>(INITIAL_FARMER_ORDERS);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedOrderForSlip, setSelectedOrderForSlip] = useState<FarmerOrderRecord | null>(null);

  // Aadhaar search
  const [aadhaarInput, setAadhaarInput] = useState('');
  const [searchState, setSearchState] = useState<SearchState>('idle');
  const [foundFarmer, setFoundFarmer] = useState<FarmerRegistrationRecord | null>(null);
  const [confirmName, setConfirmName] = useState('');
  const [confirmVillage, setConfirmVillage] = useState('');
  const [confirmPhone4, setConfirmPhone4] = useState('');
  const [farmerForOrder, setFarmerForOrder] = useState<FarmerRegistrationRecord | null>(null);

  // New farmer registration form
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regVillage, setRegVillage] = useState('Tadikonda');
  const [regBank, setRegBank] = useState('State Bank of India (SBI)');
  const [regAccount4, setRegAccount4] = useState('');
  const [regLang, setRegLang] = useState<'te' | 'hi' | 'en'>(language);

  // Order form (shown after farmer confirmed)
  const [formCropId, setFormCropId] = useState('chilli');
  const [formQuantity, setFormQuantity] = useState(12);
  const [formUnitId, setFormUnitId] = useState('quintal');
  const [formSurveyNo, setFormSurveyNo] = useState('');
  const [formSuccessMessage, setFormSuccessMessage] = useState('');

  // Farmer history view
  const [historyFarmerAadhaar, setHistoryFarmerAadhaar] = useState('');
  const [historySearchInput, setHistorySearchInput] = useState('');

  const activeCrop = ALL_CROPS.find((c) => c.id === formCropId) || ALL_CROPS[0];
  const activeUnit = INDIAN_WEIGHT_UNITS.find((u) => u.id === formUnitId) || INDIAN_WEIGHT_UNITS[0];
  const netWeightKg = Math.max(0, Math.round((formQuantity || 0) * activeUnit.kgMultiplier * 100) / 100);
  const netWeightQtl = (netWeightKg / 100).toFixed(2);
  const ratePerQtl = activeCrop.pricePerQtl;
  const ratePerKg = Math.round(ratePerQtl / 100);
  const totalClearedVal = Math.round(netWeightKg * (ratePerQtl / 100));
  const vleCommission = Math.round(totalClearedVal * 0.0075);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vleId.trim() || !vlePin.trim()) {
      setLoginError(language === 'te' ? 'దయచేసి ID మరియు PIN నమోదు చేయండి.' : language === 'hi' ? 'ID और PIN दर्ज करें।' : 'Please enter Operator ID and PIN.');
      return;
    }
    if (vlePin === '1234' || vlePin.length >= 4) {
      setIsAuthenticated(true);
      setLoginError('');
    } else {
      setLoginError('Invalid PIN. Demo PIN: 1234');
    }
  };

  const handleDemoLogin = () => {
    setVleId('VLE-GNT-402');
    setVlePin('1234');
    setCenterName('Tadikonda Gram Panchayat CSC #402');
    setIsAuthenticated(true);
  };

  // Aadhaar search
  const handleAadhaarSearch = () => {
    const clean = aadhaarInput.replace(/\s+/g, '');
    if (clean.length !== 12) return;
    const farmer = findFarmerByAadhaar(clean);
    if (farmer) {
      setFoundFarmer(farmer);
      setSearchState('found');
    } else {
      setFoundFarmer(null);
      setSearchState('not_found');
    }
  };

  // Confirm identity
  const handleConfirmIdentity = () => {
    if (!foundFarmer) return;
    const nameOk = confirmName.trim().toLowerCase() === foundFarmer.name.toLowerCase();
    const villageOk = confirmVillage.trim().toLowerCase() === foundFarmer.village.toLowerCase();
    const phone4 = foundFarmer.phone.replace(/\s+/g, '').slice(-4);
    const phoneOk = confirmPhone4.trim() === phone4;
    if (nameOk && villageOk && phoneOk) {
      setFarmerForOrder(foundFarmer);
      setSearchState('confirmed');
    } else {
      setSearchState('failed');
    }
  };

  // Register new farmer
  const handleRegisterFarmer = () => {
    if (!regName.trim() || !regPhone.trim()) return;
    const clean = aadhaarInput.replace(/\s+/g, '');
    const newFarmer: FarmerRegistrationRecord = {
      aadhaarFull: clean,
      aadhaarLast4: clean.slice(-4),
      name: regName,
      phone: regPhone,
      village: regVillage,
      bankName: regBank,
      accountLast4: regAccount4 || '0000',
      preferredLanguage: regLang,
      registeredAt: new Date().toISOString(),
      registeredByVleId: vleId,
    };
    registerFarmer(newFarmer);
    setFarmerForOrder(newFarmer);
    setFoundFarmer(newFarmer);
    setSearchState('confirmed');
    setFormSuccessMessage(t.farmerRegistered);
  };

  // Place order
  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!farmerForOrder || formQuantity <= 0) return;
    const newOrderId = `ORD-APMC-${Math.floor(8900 + Math.random() * 200)}`;
    const newRecord: FarmerOrderRecord = {
      orderId: newOrderId,
      farmerName: farmerForOrder.name,
      phone: farmerForOrder.phone,
      aadhaarLast4: farmerForOrder.aadhaarLast4,
      aadhaarFull: farmerForOrder.aadhaarFull,
      village: farmerForOrder.village,
      cropId: activeCrop.id,
      cropName: activeCrop.name[language],
      yieldQuantity: formQuantity,
      unit: activeUnit.shortCode,
      netWeightKg,
      ratePerQtl,
      totalPayout: totalClearedVal,
      bookingTime: 'Just Now',
      status: 'SCHEDULED',
      vehicleId: 'AP 07 TJ 3401 (2-Ton LCV-01)',
      driverName: 'G. Venkatesh',
      driverPhone: '94401 55667',
      bankName: farmerForOrder.bankName,
      accountLast4: farmerForOrder.accountLast4,
    };
    setOrders([newRecord, ...orders]);
    setFormSuccessMessage(`Order placed! Token: ${newOrderId}`);
    try {
      confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 }, colors: ['#0284C7', '#10B981'] });
    } catch (_) {}
    setTimeout(() => setSelectedOrderForSlip(newRecord), 600);
  };

  // History filter
  const historyOrders = historySearchInput
    ? orders.filter((o) =>
        o.aadhaarFull === historySearchInput.replace(/\s+/g, '') ||
        o.aadhaarLast4 === historySearchInput.slice(-4) ||
        o.farmerName.toLowerCase().includes(historySearchInput.toLowerCase())
      )
    : orders;

  const filteredOrders = orders.filter((o) => {
    const matchSearch =
      o.farmerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.phone.includes(searchTerm) ||
      o.orderId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.village.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'ALL' || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusBadge = (status: string) => {
    const base = 'px-2.5 py-1 rounded-full font-bold text-[11px]';
    switch (status) {
      case 'IN_TRANSIT': return <span className={`${base} bg-amber-100 text-amber-800`}>{t.statusInTransit}</span>;
      case 'WEIGHED_AT_APMC': return <span className={`${base} bg-purple-100 text-purple-800`}>{t.statusWeighed}</span>;
      case 'DBT_PAID': return <span className={`${base} bg-emerald-100 text-emerald-800`}>{t.statusPaid}</span>;
      default: return <span className={`${base} bg-blue-100 text-blue-800`}>{t.statusScheduled}</span>;
    }
  };

  const navItems: { tab: Tab; label: string; icon: React.ReactNode }[] = [
    { tab: 'order_entry', label: t.proceedToOrder, icon: <PlusCircle className="w-5 h-5" /> },
    { tab: 'farmer_activity', label: t.orderHistory, icon: <History className="w-5 h-5" /> },
    { tab: 'crop_prices', label: language === 'te' ? 'పంటల ధరలు' : language === 'hi' ? 'फसल भाव' : 'Crop Prices', icon: <TrendingUp className="w-5 h-5" /> },
    { tab: 'logistics_engine', label: language === 'te' ? 'లాజిస్టిక్స్ ఇంజిన్' : language === 'hi' ? 'लॉजिस्टिक्स' : 'Logistics Engine', icon: <Truck className="w-5 h-5" /> },
  ];

  // =========================================================================
  // LOGIN SCREEN
  // =========================================================================
  if (!isAuthenticated) {
    return (
      <div className="min-h-[85vh] flex flex-col justify-center items-center px-4 py-8">
        <div className="max-w-sm w-full bg-white rounded-3xl border-2 border-sky-400 shadow-xl p-6 sm:p-8 space-y-5">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-sky-700 flex items-center justify-center mx-auto">
              <Building2 className="w-7 h-7 text-white" />
            </div>
            <h2 className="text-xl font-black text-gray-900">
              {language === 'te' ? 'ఆపరేటర్ లాగిన్' : language === 'hi' ? 'ऑपरेटर लॉगिन' : 'CSC Operator Login'}
            </h2>
          </div>

          {/* Language switcher on login screen too */}
          <div className="flex items-center justify-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200">
            <Globe className="w-3.5 h-3.5 text-gray-400 ml-1" />
            {(['te', 'hi', 'en'] as SupportedLanguage[]).map((lang) => (
              <button
                key={lang}
                onClick={() => onLanguageChange(lang)}
                className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${
                  language === lang ? 'bg-sky-600 text-white' : 'text-gray-600'
                }`}
              >
                {lang === 'te' ? 'తెలుగు' : lang === 'hi' ? 'हिंदी' : 'EN'}
              </button>
            ))}
          </div>

          {loginError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {loginError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1">
                {language === 'te' ? 'ఆపరేటర్ ID' : language === 'hi' ? 'ऑपरेटर ID' : 'Operator ID'}
              </label>
              <input
                type="text"
                value={vleId}
                onChange={(e) => setVleId(e.target.value)}
                placeholder="VLE-GNT-402"
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 font-bold text-sm bg-gray-50 focus:bg-white focus:ring-2 focus:ring-sky-400"
                required
              />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1">
                {language === 'te' ? 'PIN (Demo: 1234)' : language === 'hi' ? 'PIN (Demo: 1234)' : 'Security PIN (Demo: 1234)'}
              </label>
              <input
                type="password"
                value={vlePin}
                onChange={(e) => setVlePin(e.target.value)}
                placeholder="••••"
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 font-bold text-sm bg-gray-50 focus:bg-white focus:ring-2 focus:ring-sky-400"
                required
              />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1">
                {language === 'te' ? 'CSC కేంద్రం' : language === 'hi' ? 'CSC केंद्र' : 'CSC Centre'}
              </label>
              <input
                type="text"
                value={centerName}
                onChange={(e) => setCenterName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm bg-gray-50"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-black text-sm flex items-center justify-center gap-2 shadow-md"
            >
              <UserCheck className="w-4 h-4" />
              {language === 'te' ? 'లోపలికి వెళ్ళండి' : language === 'hi' ? 'प्रवेश करें' : 'Login'}
            </button>
          </form>

          <button
            type="button"
            onClick={handleDemoLogin}
            className="w-full py-2.5 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-300 text-sky-800 font-black text-xs flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            {language === 'te' ? '1-క్లిక్ డెమో లాగిన్' : language === 'hi' ? '1-क्लिक डेमो लॉगिन' : '1-Click Demo Login'}
          </button>

          <div className="flex items-center justify-between text-xs font-bold text-gray-400 pt-1">
            <button onClick={onReturnToModeSelection} className="hover:text-gray-900 underline">
              {t.back}
            </button>
            <button onClick={onSwitchToKisanMode} className="text-emerald-700 hover:text-emerald-900 underline">
              {t.kisanMode}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // AUTHENTICATED PORTAL
  // =========================================================================
  return (
    <div className="max-w-5xl mx-auto w-full">
      {/* Top Bar with Burger Menu */}
      <div className="bg-white rounded-2xl border border-gray-200 p-4 mb-4 shadow-sm flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {/* Hamburger */}
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="w-10 h-10 rounded-xl bg-sky-700 text-white flex items-center justify-center shadow-sm hover:bg-sky-800 shrink-0"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div>
            <div className="font-black text-gray-900 text-sm">
              {language === 'te' ? 'ఆపరేటర్ పోర్టల్' : language === 'hi' ? 'ऑपरेटर पोर्टल' : 'Operator Portal'}
            </div>
            <p className="text-xs text-gray-500">
              {vleId} · {centerName}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            {language === 'te' ? 'ఆన్‌లైన్' : language === 'hi' ? 'ऑनलाइन' : 'Online'}
          </span>
          <button
            type="button"
            onClick={() => setIsAuthenticated(false)}
            className="px-3 py-1.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 text-xs font-black flex items-center gap-1"
          >
            <LogOut className="w-3.5 h-3.5" />
            {language === 'te' ? 'లాగౌట్' : language === 'hi' ? 'लॉगआउट' : 'Logout'}
          </button>
        </div>
      </div>

      {/* Side Drawer Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setMenuOpen(false)}
          />
          {/* Drawer */}
          <div className="relative w-72 bg-white h-full shadow-2xl flex flex-col">
            <div className="p-5 border-b border-gray-200 flex items-center justify-between">
              <div>
                <div className="font-black text-gray-900">AgroRoute</div>
                <div className="text-xs text-gray-500">{t.operatorMode}</div>
              </div>
              <button onClick={() => setMenuOpen(false)} className="p-1.5 rounded-lg hover:bg-gray-100">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Nav items */}
            <nav className="flex-1 p-3 space-y-1">
              {navItems.map(({ tab, label, icon }) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => { setActiveTab(tab); setMenuOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-left transition-all ${
                    activeTab === tab
                      ? 'bg-sky-700 text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {icon}
                  {label}
                </button>
              ))}
            </nav>

            {/* Language + bottom controls */}
            <div className="p-4 border-t border-gray-200 space-y-3">
              <div>
                <p className="text-xs font-bold text-gray-500 mb-2">{t.switchLanguage}</p>
                <div className="flex gap-1">
                  {(['te', 'hi', 'en'] as SupportedLanguage[]).map((lang) => (
                    <button
                      key={lang}
                      onClick={() => onLanguageChange(lang)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-black transition-all ${
                        language === lang ? 'bg-sky-600 text-white' : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {lang === 'te' ? 'తెలుగు' : lang === 'hi' ? 'हिंदी' : 'EN'}
                    </button>
                  ))}
                </div>
              </div>
              <button onClick={onSwitchToKisanMode} className="w-full py-2 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-black">
                {t.kisanMode}
              </button>
              <button onClick={onReturnToModeSelection} className="w-full py-2 rounded-xl bg-gray-100 text-gray-700 text-xs font-bold">
                {t.back}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active tab label */}
      <div className="mb-4 flex items-center gap-3">
        {navItems.find((n) => n.tab === activeTab)?.icon}
        <h2 className="text-lg font-black text-gray-900">
          {navItems.find((n) => n.tab === activeTab)?.label}
        </h2>
      </div>

      {/* ================================================================== */}
      {/* TAB 1: AADHAAR SEARCH → CONFIRM → ORDER ENTRY */}
      {/* ================================================================== */}
      {activeTab === 'order_entry' && (
        <div className="space-y-5">
          {/* Order slip modal */}
          {selectedOrderForSlip && (
            <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
              <div className="bg-white rounded-3xl border-2 border-emerald-500 p-6 w-full max-w-md shadow-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-black text-gray-900 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    {language === 'te' ? 'ఆర్డర్ నిర్ధారించబడింది' : language === 'hi' ? 'ऑर्डर पुष्टि' : 'Order Confirmed'}
                  </h3>
                  <button onClick={() => setSelectedOrderForSlip(null)} className="p-1.5 rounded-lg hover:bg-gray-100">
                    <X className="w-5 h-5 text-gray-500" />
                  </button>
                </div>
                <div className="bg-gray-50 rounded-2xl p-4 space-y-2 text-sm font-medium">
                  <div className="flex justify-between"><span className="text-gray-500">{t.orderId}</span><span className="font-black">{selectedOrderForSlip.orderId}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">{t.farmerName}</span><span className="font-bold">{selectedOrderForSlip.farmerName}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">{t.farmerVillage}</span><span className="font-bold">{selectedOrderForSlip.village}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">{t.cropName}</span><span className="font-bold">{selectedOrderForSlip.cropName}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">{t.quantity}</span><span className="font-bold">{selectedOrderForSlip.yieldQuantity} {selectedOrderForSlip.unit}</span></div>
                  <div className="flex justify-between border-t pt-2 mt-1"><span className="text-gray-700 font-bold">{t.totalPayout}</span><span className="font-black text-emerald-700 text-base">₹{selectedOrderForSlip.totalPayout.toLocaleString('en-IN')}</span></div>
                </div>
                <button
                  onClick={() => { setSelectedOrderForSlip(null); setActiveTab('farmer_activity'); }}
                  className="w-full py-3 rounded-xl bg-emerald-700 text-white font-black text-sm flex items-center justify-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  {language === 'te' ? 'లెడ్జర్‌లో చూడండి' : language === 'hi' ? 'लेजर में देखें' : 'View in Ledger'}
                </button>
              </div>
            </div>
          )}

          {/* STEP 1: Aadhaar Search */}
          {(searchState === 'idle' || searchState === 'not_found' || searchState === 'failed') && (
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm space-y-5">
              <div>
                <h3 className="text-base font-black text-gray-900">{t.searchByAadhaar}</h3>
                <p className="text-xs text-gray-500 mt-0.5">{t.enterAadhaarPrompt}</p>
              </div>

              {searchState === 'not_found' && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-xs font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  {t.farmerNotFound} — {t.registerNewFarmer}
                </div>
              )}
              {searchState === 'failed' && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {t.identityFailed}
                </div>
              )}

              <div className="flex gap-3">
                <input
                  type="text"
                  value={aadhaarInput}
                  onChange={(e) => setAadhaarInput(e.target.value)}
                  placeholder={t.aadhaarPlaceholder}
                  maxLength={14}
                  className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-300 font-bold text-sm bg-gray-50 focus:bg-white focus:border-sky-400"
                />
                <button
                  type="button"
                  onClick={handleAadhaarSearch}
                  disabled={aadhaarInput.replace(/\s+/g, '').length !== 12}
                  className="px-5 py-3 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-black text-sm flex items-center gap-2 disabled:opacity-50"
                >
                  <Search className="w-4 h-4" />
                  {t.searchBtn}
                </button>
              </div>

              {/* Quick demo hint */}
              <p className="text-xs text-gray-400 font-medium">
                {language === 'te' ? 'డెమో: 987600004012 ప్రయత్నించండి' : language === 'hi' ? 'डेमो: 987600004012 आज़माएं' : 'Demo: Try 987600004012'}
              </p>
            </div>
          )}

          {/* STEP 2: Farmer found — confirm identity */}
          {searchState === 'found' && foundFarmer && (
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
                  <User className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <div className="font-black text-gray-900">{t.farmerFound}</div>
                  <div className="text-xs text-gray-500">{t.confirmIdentity}</div>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-sm space-y-1">
                <div><span className="text-gray-500 text-xs">{t.farmerName}:</span> <span className="font-bold">{foundFarmer.name}</span></div>
                <div><span className="text-gray-500 text-xs">{t.farmerVillage}:</span> <span className="font-bold">{foundFarmer.village}</span></div>
                <div><span className="text-gray-500 text-xs">{t.farmerPhone}:</span> <span className="font-bold">••••{foundFarmer.phone.slice(-4)}</span></div>
              </div>

              <div className="space-y-3">
                <p className="text-xs font-bold text-gray-700">{t.confirmIdentity} — {t.confirmNamePrompt}</p>
                <input
                  type="text"
                  value={confirmName}
                  onChange={(e) => setConfirmName(e.target.value)}
                  placeholder={t.confirmNamePrompt}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50 focus:bg-white"
                />
                <input
                  type="text"
                  value={confirmVillage}
                  onChange={(e) => setConfirmVillage(e.target.value)}
                  placeholder={t.confirmVillagePrompt}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50 focus:bg-white"
                />
                <input
                  type="text"
                  value={confirmPhone4}
                  onChange={(e) => setConfirmPhone4(e.target.value)}
                  placeholder={t.confirmPhonePrompt}
                  maxLength={4}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50 focus:bg-white"
                />
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setSearchState('idle')}
                  className="px-4 py-2.5 rounded-xl border border-gray-300 text-gray-700 font-bold text-sm"
                >
                  {t.back}
                </button>
                <button
                  type="button"
                  onClick={handleConfirmIdentity}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-sm flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  {t.confirmIdentity}
                </button>
              </div>
            </div>
          )}

          {/* STEP 2b: New farmer signup */}
          {searchState === 'not_found' && (
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm space-y-4">
              <div>
                <h3 className="text-base font-black text-gray-900">{t.registerNewFarmer}</h3>
                <p className="text-xs text-gray-500">
                  {t.aadhaarLabel}: ••••••••{aadhaarInput.replace(/\s/g, '').slice(-4)}
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-600 block mb-1">{t.farmerName}</label>
                  <input type="text" value={regName} onChange={(e) => setRegName(e.target.value)} placeholder="Full name" className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50 focus:bg-white" required />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 block mb-1">{t.farmerPhone}</label>
                  <input type="tel" value={regPhone} onChange={(e) => setRegPhone(e.target.value)} placeholder="98480 XXXXX" className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50 focus:bg-white" required />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 block mb-1">{t.farmerVillage}</label>
                  <select value={regVillage} onChange={(e) => setRegVillage(e.target.value)} className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50">
                    {['Tadikonda', 'Mangalagiri', 'Pedakakani', 'Chebrolu', 'Amaravati Rural', 'Tenali Rural'].map((v) => <option key={v}>{v}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 block mb-1">{t.farmerBank}</label>
                  <select value={regBank} onChange={(e) => setRegBank(e.target.value)} className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50">
                    {['State Bank of India (SBI)', 'Andhra Pragathi Grameena Bank', 'Union Bank of India', 'Canara Bank', 'Indian Bank'].map((b) => <option key={b}>{b}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 block mb-1">{t.farmerAccountLast4}</label>
                  <input type="text" value={regAccount4} onChange={(e) => setRegAccount4(e.target.value)} placeholder="••••" maxLength={4} className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50 focus:bg-white" />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 block mb-1">{t.farmerLanguage}</label>
                  <select value={regLang} onChange={(e) => setRegLang(e.target.value as 'te' | 'hi' | 'en')} className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold bg-gray-50">
                    <option value="te">తెలుగు</option>
                    <option value="hi">हिंदी</option>
                    <option value="en">English</option>
                  </select>
                </div>
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setSearchState('idle')} className="px-4 py-2.5 rounded-xl border border-gray-300 text-gray-700 font-bold text-sm">{t.back}</button>
                <button type="button" onClick={handleRegisterFarmer} disabled={!regName.trim() || !regPhone.trim()} className="flex-1 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-sm disabled:opacity-50">
                  {t.saveAndRegister}
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Confirmed — Order form */}
          {searchState === 'confirmed' && farmerForOrder && (
            <div className="space-y-4">
              {formSuccessMessage && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  {formSuccessMessage}
                </div>
              )}

              {/* Farmer identity badge */}
              <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-700 flex items-center justify-center">
                  <UserCheck className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <div className="font-black text-gray-900 text-sm">{farmerForOrder.name}</div>
                  <div className="text-xs text-gray-500">{farmerForOrder.village} · ••••{farmerForOrder.aadhaarLast4} · {farmerForOrder.phone}</div>
                </div>
                <button
                  type="button"
                  onClick={() => { setSearchState('idle'); setFarmerForOrder(null); setFormSuccessMessage(''); setAadhaarInput(''); }}
                  className="text-xs text-gray-500 hover:text-gray-900 underline"
                >
                  {language === 'te' ? 'మార్చండి' : language === 'hi' ? 'बदलें' : 'Change'}
                </button>
              </div>

              {/* Order form */}
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="font-black text-gray-900 mb-4">
                  {language === 'te' ? 'పంట వివరాలు' : language === 'hi' ? 'फसल विवरण' : 'Crop & Harvest Details'}
                </h3>
                <form onSubmit={handlePlaceOrder} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-600 block mb-1">
                      {language === 'te' ? 'పంట ఎంపిక' : language === 'hi' ? 'फसल चुनें' : 'Select Crop'}
                    </label>
                    <select
                      value={formCropId}
                      onChange={(e) => setFormCropId(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border-2 border-sky-300 font-bold text-sm bg-sky-50 focus:bg-white"
                    >
                      {ALL_CROPS.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name[language]} — ₹{c.pricePerQtl.toLocaleString('en-IN')}/Qtl
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-gray-600 block mb-1">
                        {language === 'te' ? 'పరిమాణం' : language === 'hi' ? 'मात्रा' : 'Quantity'}
                      </label>
                      <input
                        type="number"
                        min={1}
                        step="any"
                        value={formQuantity}
                        onChange={(e) => setFormQuantity(parseFloat(e.target.value) || 0)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 font-black text-base bg-gray-50 focus:bg-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-600 block mb-1">
                        {language === 'te' ? 'యూనిట్' : language === 'hi' ? 'इकाई' : 'Unit'}
                      </label>
                      <select
                        value={formUnitId}
                        onChange={(e) => setFormUnitId(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 font-bold text-sm bg-gray-50 focus:bg-white"
                      >
                        {INDIAN_WEIGHT_UNITS.map((u) => (
                          <option key={u.id} value={u.id}>
                            {u.name[language]} ({u.shortCode})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Calculated summary */}
                  <div className="bg-sky-950 text-white rounded-xl p-4 space-y-1">
                    <div className="flex justify-between text-xs font-bold text-sky-300">
                      <span>{language === 'te' ? 'నికర బరువు' : language === 'hi' ? 'शुद्ध वजन' : 'Net Weight'}</span>
                      <span>{netWeightKg.toLocaleString('en-IN')} kg ({netWeightQtl} Qtl)</span>
                    </div>
                    <div className="flex justify-between text-xs font-bold text-sky-300">
                      <span>{language === 'te' ? 'ధర' : language === 'hi' ? 'भाव' : 'Rate'}</span>
                      <span>₹{ratePerQtl.toLocaleString('en-IN')}/Qtl (₹{ratePerKg}/kg)</span>
                    </div>
                    <div className="flex justify-between text-base font-black text-emerald-400 border-t border-white/10 pt-2 mt-1">
                      <span>{language === 'te' ? 'రైతుకు చెల్లింపు' : language === 'hi' ? 'किसान को भुगतान' : 'Farmer Payout'}</span>
                      <span>₹{totalClearedVal.toLocaleString('en-IN')}</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-2xl bg-sky-700 hover:bg-sky-800 text-white font-black text-sm flex items-center justify-center gap-2 shadow-md"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    {language === 'te' ? 'ఆర్డర్ సమర్పించండి' : language === 'hi' ? 'ऑर्डर दर्ज करें' : 'Submit Order'}
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================================================================== */}
      {/* TAB 2: ORDER HISTORY / FARMER LEDGER */}
      {/* ================================================================== */}
      {activeTab === 'farmer_activity' && (
        <div className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm space-y-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="font-black text-gray-900">{t.orderHistory}</h3>
              <p className="text-xs text-gray-500 mt-0.5">
                {language === 'te' ? 'ఆధార్ లేదా పేరు తో వెతకండి' : language === 'hi' ? 'आधार या नाम से खोजें' : 'Search by Aadhaar or farmer name'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('order_entry')}
              className="px-3 py-2 rounded-xl bg-sky-700 text-white text-xs font-black flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              {language === 'te' ? 'కొత్త ఆర్డర్' : language === 'hi' ? 'नया ऑर्डर' : 'New Order'}
            </button>
          </div>

          {/* Search */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={language === 'te' ? 'ఆధార్, పేరు లేదా టోకెన్' : language === 'hi' ? 'आधार, नाम या टोकन' : 'Aadhaar, name or order token'}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-300 text-xs font-bold bg-gray-50 focus:bg-white"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-gray-300 text-xs font-black bg-gray-50"
            >
              <option value="ALL">{language === 'te' ? 'అన్ని' : language === 'hi' ? 'सभी' : 'All'}</option>
              <option value="SCHEDULED">{t.statusScheduled}</option>
              <option value="IN_TRANSIT">{t.statusInTransit}</option>
              <option value="WEIGHED_AT_APMC">{t.statusWeighed}</option>
              <option value="DBT_PAID">{t.statusPaid}</option>
            </select>
          </div>

          {/* Table */}
          <div className="overflow-x-auto rounded-xl border border-gray-200">
            <table className="w-full text-left text-xs">
              <thead className="bg-gray-100 text-gray-600 uppercase font-bold tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">{t.orderId}</th>
                  <th className="py-3 px-4">{t.farmerName}</th>
                  <th className="py-3 px-4">{t.farmerVillage}</th>
                  <th className="py-3 px-4">{t.cropName}</th>
                  <th className="py-3 px-4">{t.totalPayout}</th>
                  <th className="py-3 px-4">{t.status}</th>
                  <th className="py-3 px-4 text-right">{t.viewSlip}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 font-medium">
                {filteredOrders.map((ord) => (
                  <tr key={ord.orderId} className="hover:bg-gray-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-black text-gray-900 text-[11px]">{ord.orderId}</div>
                      <div className="text-gray-400 text-[10px] flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" />{ord.bookingTime}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold">{ord.farmerName}</div>
                      <div className="text-gray-400 text-[10px]">{ord.phone}</div>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{ord.village}</td>
                    <td className="py-3 px-4">
                      <div className="font-bold">{ord.cropName}</div>
                      <div className="text-gray-400 text-[10px]">{ord.yieldQuantity} {ord.unit} · {ord.netWeightKg} kg</div>
                    </td>
                    <td className="py-3 px-4 font-black text-emerald-700">₹{ord.totalPayout.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4">{statusBadge(ord.status)}</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => setSelectedOrderForSlip(ord)}
                        className="px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-sky-100 text-gray-700 hover:text-sky-800 font-bold text-[11px]"
                      >
                        {t.viewSlip}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredOrders.length === 0 && (
              <div className="text-center py-10 text-gray-400 font-medium text-sm">{t.noOrdersYet}</div>
            )}
          </div>
        </div>
      )}

      {/* ================================================================== */}
      {/* TAB 3: CROP PRICES */}
      {/* ================================================================== */}
      {activeTab === 'crop_prices' && (
        <div className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm">
          <h3 className="font-black text-gray-900 mb-4">
            {language === 'te' ? 'నేటి APMC మార్కెట్ ధరలు' : language === 'hi' ? 'आज की APMC मंडी दरें' : "Today's APMC Market Rates"}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {ALL_CROPS.map((crop) => (
              <div key={crop.id} className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 bg-gray-50">
                <span className="text-2xl">{crop.icon}</span>
                <div className="flex-1">
                  <div className="font-bold text-gray-900 text-sm">{crop.name[language]}</div>
                  <div className="text-xs text-gray-500">{crop.category}</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-emerald-700">₹{Math.round(crop.pricePerQtl / 100)}/kg</div>
                  <div className="text-[11px] text-gray-500">₹{crop.pricePerQtl.toLocaleString('en-IN')}/Qtl</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================================================================== */}
      {/* TAB 4: LOGISTICS ENGINE */}
      {/* ================================================================== */}
      {activeTab === 'logistics_engine' && renderEngineTab && (
        <div>{renderEngineTab()}</div>
      )}
    </div>
  );
};
