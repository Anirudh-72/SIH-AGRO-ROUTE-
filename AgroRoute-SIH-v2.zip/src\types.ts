export interface FarmerAsk {
  farmer_id: string;
  name: string;
  village: string;
  commodity: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton';
  weight_kg: number;
  ask_price_per_qtl: number;
  lat: number;
  lon: number;
  vle_id: string;
  contact: string;
  distance_to_hub_km?: number;
  within_pooling_radius?: boolean;
  channel?: 'touch' | 'ivr_simulated' | 'operator_assisted';
  created_at?: string;
}

export interface BuyerBid {
  bid_id: string;
  buyer_name: string;
  hub_name: string;
  commodity: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton';
  demand_weight_kg: number;
  bid_price_per_qtl: number;
  lat: number;
  lon: number;
  buyer_email?: string;
  created_at?: string;
}

export interface BuyerProfile {
  buyer_id: string;
  business_name: string;
  trader_license: string;
  gstin: string;
  phone: string;
  email: string;
  verified: boolean;
  hub_name: string;
  lat: number;
  lon: number;
  commodities: ('Guntur Teja Mirchi' | 'Shankar-6 Cotton')[];
}

export interface OperatorProfile {
  vle_id: string;
  center_name: string;
  operator_name: string;
  phone: string;
  email: string;
  role: 'VLE' | 'Panchayat Officer' | 'District Admin';
}

export interface FarmerProfile {
  phone: string;
  name: string;
  village: string;
  preferred_language: 'te' | 'hi' | 'en';
  bank_account_or_upi: string;
  aadhaar_ref?: string;
}

export interface GrievanceRecord {
  grievance_id: string;
  contract_id: string;
  raised_by: 'farmer' | 'buyer';
  party_name: string;
  phone: string;
  category: 'weighment' | 'payment_delay' | 'driver_issue' | 'quality_dispute' | 'other';
  description: string;
  status: 'Investigating' | 'Resolved' | 'Action Scheduled';
  resolution_note?: string;
  timestamp: string;
}

export interface MatchedContract {
  contract_id: string;
  farmer_id: string;
  farmer_name: string;
  village: string;
  lat: number;
  lon: number;
  vle_id: string;
  buyer_id: string;
  buyer_name: string;
  commodity: string;
  weight_kg: number;
  farmer_ask_qtl: number;
  buyer_bid_qtl: number;
  clearing_price_qtl: number;
  total_cleared_value: number;
  farmer_surplus: number;
  buyer_surplus: number;
  timestamp: string;
  status?: 'Scheduled' | 'In Transit' | 'Delivered' | 'DBT Paid' | 'Dispute Raised';
  escrow_status?: 'LOCKED' | 'IN_TRANSIT' | 'DELIVERED' | 'DISPUTED' | 'SETTLED';
  assigned_vehicle_id?: string;
  grievance_raised?: boolean;
}

export interface LcvVehicle {
  vehicle_id: string;
  driver_name: string;
  vehicle_reg: string;
  capacity_kg: number;
  current_load_kg: number;
  utilization_pct: number;
  lot_count: number;
  total_val: number;
  lots: MatchedContract[];
}

export interface PricePoint {
  date: string;
  daily_modal_price: number;
  rolling_avg_7d: number;
  distress_floor: number;
}

export interface VleLedgerRow {
  txn_ref: string;
  timestamp: string;
  vle_id: string;
  farmer_name: string;
  village: string;
  commodity: string;
  net_cleared: number;
  vle_fee: number;
  target_upi: string;
  npci_utr: string;
  status: string;
}
