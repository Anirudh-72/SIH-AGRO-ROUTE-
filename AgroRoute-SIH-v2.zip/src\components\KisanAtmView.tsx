import React, { useState } from 'react';
import { SupportedLanguage, TRANSLATIONS } from '../data/translations';
import { ALL_CROPS, INDIAN_WEIGHT_UNITS } from '../data/cropsAndUnits';
import { INITIAL_FARMER_ORDERS, FarmerOrderRecord } from '../data/farmerActivityData';
import { speakVernacularText, stopSpeech } from '../utils/speechUtils';
import { MatchedContract } from '../types';
import {
  Truck,
  CheckCircle2,
  ShieldCheck,
  Plus,
  Minus,
  PhoneCall,
  Volume2,
  VolumeX,
  ArrowRight,
  ArrowLeft,
  Clock,
  FileText,
  RotateCcw,
  HelpCircle,
  CreditCard,
  Printer,
  ChevronRight,
  History,
  Sprout,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface KisanAtmViewProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  latestContract?: MatchedContract;
  onOpenAiAssistant: () => void;
  onSwitchToOperator: () => void;
  onReturnToModeSelection: () => void;
  onOrderCreated?: (order: any) => void;
}

type Screen = 'menu' | 'wizard' | 'rates' | 'passbook' | 'history';

export const KisanAtmView: React.FC<KisanAtmViewProps> = ({
  language,
  onLanguageChange,
  latestContract,
  onOpenAiAssistant,
  onSwitchToOperator,
  onReturnToModeSelection,
  onOrderCreated,
}) => {
  const t = TRANSLATIONS[language];

  const [currentScreen, setCurrentScreen] = useState<Screen>('menu');
  const [wizardStep, setWizardStep] = useState(1);
  const [speaking, setSpeaking] = useState(false);

  // Booking form state
  const [selectedCropId, setSelectedCropId] = useState('chilli');
  const [yieldQuantity, setYieldQuantity] = useState(10);
  const [selectedUnitId, setSelectedUnitId] = useState('quintal');
  const [selectedVillage, setSelectedVillage] = useState('Tadikonda');
  const [farmerPhone] = useState('98480 12345');
  const [lastBookingId, setLastBookingId] = useState('ORD-APMC-8891');

  // Session orders (start with seed data for demo)
  const [sessionOrders] = useState<FarmerOrderRecord[]>(INITIAL_FARMER_ORDERS);

  const selectedCrop = ALL_CROPS.find((c) => c.id === selectedCropId) || ALL_CROPS[0];
  const selectedUnit = INDIAN_WEIGHT_UNITS.find((u) => u.id === selectedUnitId) || INDIAN_WEIGHT_UNITS[0];

  const totalWeightKg = Math.max(0, Math.round((yieldQuantity || 0) * selectedUnit.kgMultiplier * 100) / 100);
  const totalWeightQtl = (totalWeightKg / 100).toFixed(2);
  const pricePerQtl = selectedCrop.pricePerQtl;
  const pricePerKg = Math.round(pricePerQtl / 100);
  const rawTotalPayout = Math.round(totalWeightKg * (pricePerQtl / 100));
  const estimatedTotalPayout = rawTotalPayout.toLocaleString('en-IN');

  const villages = [
    { name: 'Tadikonda', label: language === 'te' ? 'తాడికొండ' : language === 'hi' ? 'ताडिकोंडा' : 'Tadikonda', time: '15 mins' },
    { name: 'Mangalagiri', label: language === 'te' ? 'మంగళగిరి' : language === 'hi' ? 'मंगलगिरि' : 'Mangalagiri', time: '20 mins' },
    { name: 'Pedakakani', label: language === 'te' ? 'పెదకాకాని' : language === 'hi' ? 'पेदाकाकानी' : 'Pedakakani', time: '25 mins' },
    { name: 'Chebrolu', label: language === 'te' ? 'చేబ్రోలు' : language === 'hi' ? 'चेब्रोलू' : 'Chebrolu', time: '30 mins' },
    { name: 'Amaravati Rural', label: language === 'te' ? 'అమరావతి' : language === 'hi' ? 'अमरावती' : 'Amaravati', time: '35 mins' },
  ];

  const handleSpeak = (text: string) => {
    if (speaking) { stopSpeech(); setSpeaking(false); return; }
    setSpeaking(true);
    speakVernacularText(text, language, () => setSpeaking(true), () => setSpeaking(false), () => setSpeaking(false));
  };

  const handleConfirmBooking = () => {
    try {
      confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 }, colors: ['#059669', '#10B981', '#34D399', '#38BDF8'] });
    } catch (_) {}
    const newOrderId = `ORD-APMC-${Math.floor(8800 + Math.random() * 200)}`;
    setLastBookingId(newOrderId);
    if (onOrderCreated) {
      onOrderCreated({
        orderId: newOrderId, farmerName: 'K. Venkateswara Rao', phone: farmerPhone,
        aadhaarLast4: '4012', village: selectedVillage, cropId: selectedCrop.id,
        cropName: selectedCrop.name[language], yieldQuantity, unit: selectedUnit.shortCode,
        netWeightKg: totalWeightKg, ratePerQtl: pricePerQtl, totalPayout: rawTotalPayout,
        bookingTime: 'Just Now', status: 'SCHEDULED',
        vehicleId: 'AP 07 TJ 3401 (2-Ton LCV-01)', driverName: 'G. Venkatesh',
        driverPhone: '94401 55667', bankName: 'State Bank of India (SBI)', accountLast4: '4012',
      });
    }
    setWizardStep(5);
    handleSpeak(
      language === 'te'
        ? `అభినందనలు! లారీ బుకింగ్ విజయవంతమైంది. టోకెన్ ${newOrderId}. రూ. ${estimatedTotalPayout} మీ బ్యాంక్ ఖాతాలో జమ అవుతుంది.`
        : language === 'hi'
        ? `बधाई हो! गाड़ी बुक हो गई। टोकन ${newOrderId}। ₹${estimatedTotalPayout} आपके बैंक खाते में जमा होगा।`
        : `Congratulations! Truck booked. Token ${newOrderId}. Rs. ${estimatedTotalPayout} will be credited to your bank.`
    );
  };

  const statusLabel = (status: string) => {
    switch (status) {
      case 'IN_TRANSIT': return t.statusInTransit;
      case 'WEIGHED_AT_APMC': return t.statusWeighed;
      case 'DBT_PAID': return t.statusPaid;
      default: return t.statusScheduled;
    }
  };

  const statusColor = (status: string) => {
    switch (status) {
      case 'IN_TRANSIT': return 'bg-amber-100 text-amber-800';
      case 'WEIGHED_AT_APMC': return 'bg-purple-100 text-purple-800';
      case 'DBT_PAID': return 'bg-emerald-100 text-emerald-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <div className="max-w-4xl mx-auto w-full">
      <div className="bg-white rounded-3xl border-2 border-emerald-600 shadow-xl overflow-hidden flex flex-col min-h-[580px]">

        {/* ATM Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white p-4 flex flex-wrap items-center justify-between gap-3 border-b-4 border-emerald-500">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center">
              <Sprout className="w-6 h-6 text-emerald-800" />
            </div>
            <div>
              <div className="text-base font-black">
                {language === 'te' ? 'రైతు సేవా ఏటీఎం' : language === 'hi' ? 'किसान सेवा ATM' : 'Kisan Seva ATM'}
              </div>
              <div className="text-xs text-emerald-200">
                {language === 'te' ? 'గుంటూరు APMC మార్కెట్' : language === 'hi' ? 'गुंटूर APMC मंडी' : 'Guntur APMC Market'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Voice button */}
            <button
              onClick={() => handleSpeak(
                language === 'te' ? 'నమస్కారం రైతు సోదరా! కిసాన్ ఏటీఎంకు స్వాగతం.' :
                language === 'hi' ? 'नमस्ते किसान भाई! किसान एटीएम में स्वागत है।' :
                'Welcome respected farmer! Welcome to Kisan ATM.'
              )}
              className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 ${speaking ? 'bg-amber-400 text-emerald-950 animate-pulse' : 'bg-emerald-900/80 hover:bg-emerald-900 text-white border border-emerald-500'}`}
            >
              {speaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-300" />}
              <span>{speaking ? (language === 'te' ? 'ఆపండి' : 'Stop') : (language === 'te' ? 'వినండి' : language === 'hi' ? 'सुनें' : 'Listen')}</span>
            </button>

            {/* Language switcher */}
            <div className="flex items-center bg-emerald-950/70 p-0.5 rounded-xl border border-emerald-600 text-xs font-bold">
              {(['te', 'hi', 'en'] as SupportedLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => onLanguageChange(lang)}
                  className={`px-2.5 py-1.5 rounded-lg ${language === lang ? 'bg-white text-emerald-900 shadow-sm' : 'text-emerald-200'}`}
                >
                  {lang === 'te' ? 'తె' : lang === 'hi' ? 'हि' : 'EN'}
                </button>
              ))}
            </div>

            {/* Exit */}
            <button
              onClick={onReturnToModeSelection}
              className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-black flex items-center gap-1.5 border border-slate-700"
            >
              <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
              <span>{language === 'te' ? 'మోడ్ మార్చు' : language === 'hi' ? 'मोड बदलें' : 'Exit'}</span>
            </button>
          </div>
        </div>

        {/* Screen Content */}
        <div className="flex-1 p-4 sm:p-6 bg-[#FAFCFB] flex flex-col justify-between">

          {/* ======================================================= */}
          {/* SCREEN: MAIN MENU */}
          {/* ======================================================= */}
          {currentScreen === 'menu' && (
            <div className="space-y-4">
              {/* Welcome banner */}
              <div className="bg-white rounded-2xl p-4 border border-emerald-200 flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-3xl shrink-0">
                  🙏
                </div>
                <div>
                  <h2 className="text-lg font-black text-gray-900">
                    {language === 'te' ? 'నమస్కారం రైతు సోదరా!' : language === 'hi' ? 'नमस्ते किसान भाई!' : 'Welcome Respected Farmer!'}
                  </h2>
                  <p className="text-sm font-bold text-emerald-800 mt-0.5">
                    {language === 'te' ? 'మీరు ఏం చేయాలనుకుంటున్నారు?' : language === 'hi' ? 'आप क्या करना चाहते हैं?' : 'What would you like to do?'}
                  </p>
                </div>
              </div>

              {/* 4 ATM Big Buttons — stacked as 2x2 grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* 1. Sell Crop */}
                <button
                  id="atm-sell-crop-launch-btn"
                  onClick={() => { setWizardStep(1); setCurrentScreen('wizard'); }}
                  className="bg-gradient-to-br from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-2xl p-5 border-2 border-emerald-400 shadow-md hover:shadow-lg transition-all text-left flex items-center justify-between gap-4 active:scale-98"
                >
                  <div className="space-y-1">
                    <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center mb-2">
                      <Truck className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-lg font-black text-white leading-snug">
                      {language === 'te' ? 'పంట అమ్మండి & లారీ బుక్ చేయండి' : language === 'hi' ? 'फसल बेचें और गाड़ी बुक करें' : 'Sell Crop & Book Truck'}
                    </h3>
                    <p className="text-xs text-emerald-100 font-medium">
                      {language === 'te' ? 'ఉచిత లారీ · నేరుగా బ్యాంక్ పైకం' : language === 'hi' ? 'मुफ्त गाड़ी · सीधा बैंक भुगतान' : 'Free truck · Direct bank credit'}
                    </p>
                  </div>
                  <ArrowRight className="w-6 h-6 text-white/70 shrink-0" />
                </button>

                {/* 2. Check Rates */}
                <button
                  id="atm-check-rates-btn"
                  onClick={() => setCurrentScreen('rates')}
                  className="bg-white hover:bg-sky-50 text-gray-900 rounded-2xl p-5 border-2 border-sky-400 shadow-sm hover:shadow-md transition-all text-left flex items-center justify-between gap-4 active:scale-98"
                >
                  <div className="space-y-1">
                    <div className="w-10 h-10 rounded-xl bg-sky-100 flex items-center justify-center mb-2">
                      <CreditCard className="w-5 h-5 text-sky-700" />
                    </div>
                    <h3 className="text-lg font-black text-gray-900 leading-snug">
                      {language === 'te' ? 'నేటి మార్కెట్ ధరలు' : language === 'hi' ? 'आज का मंडी भाव' : 'Check Market Rates'}
                    </h3>
                    <p className="text-xs text-gray-500 font-medium">
                      {language === 'te' ? '16 పంటల గ్యారంటీ ధరలు' : language === 'hi' ? '16 फसलों के गारंटीकृत भाव' : 'Guaranteed rates for all 16 crops'}
                    </p>
                  </div>
                  <ArrowRight className="w-6 h-6 text-sky-500 shrink-0" />
                </button>

                {/* 3. Bank Receipt */}
                <button
                  id="atm-check-passbook-btn"
                  onClick={() => setCurrentScreen('passbook')}
                  className="bg-white hover:bg-purple-50 text-gray-900 rounded-2xl p-5 border-2 border-purple-400 shadow-sm hover:shadow-md transition-all text-left flex items-center justify-between gap-4 active:scale-98"
                >
                  <div className="space-y-1">
                    <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center mb-2">
                      <FileText className="w-5 h-5 text-purple-700" />
                    </div>
                    <h3 className="text-lg font-black text-gray-900 leading-snug">
                      {language === 'te' ? 'నా బ్యాంక్ జమ రశీదు' : language === 'hi' ? 'बैंक जमा रसीद' : 'My Bank Deposit Receipt'}
                    </h3>
                    <p className="text-xs text-gray-500 font-medium">
                      {language === 'te' ? 'DBT స్టేటస్ · UTR నంబర్' : language === 'hi' ? 'DBT स्टेटस · UTR नंबर' : 'DBT status · UTR reference'}
                    </p>
                  </div>
                  <ArrowRight className="w-6 h-6 text-purple-500 shrink-0" />
                </button>

                {/* 4. My Order History */}
                <button
                  id="atm-my-orders-btn"
                  onClick={() => setCurrentScreen('history')}
                  className="bg-white hover:bg-amber-50 text-gray-900 rounded-2xl p-5 border-2 border-amber-400 shadow-sm hover:shadow-md transition-all text-left flex items-center justify-between gap-4 active:scale-98"
                >
                  <div className="space-y-1">
                    <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center mb-2">
                      <History className="w-5 h-5 text-amber-700" />
                    </div>
                    <h3 className="text-lg font-black text-gray-900 leading-snug">
                      {t.myOrders}
                    </h3>
                    <p className="text-xs text-gray-500 font-medium">
                      {language === 'te' ? 'మీ అన్ని పంట ఆర్డర్లు' : language === 'hi' ? 'आपके सभी ऑर्डर' : 'All your crop orders'}
                    </p>
                  </div>
                  <ArrowRight className="w-6 h-6 text-amber-500 shrink-0" />
                </button>
              </div>

              {/* Zero middlemen strip */}
              <div className="bg-emerald-50 rounded-xl p-3 border border-emerald-200 flex items-center gap-3 text-xs font-bold text-emerald-900">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0" />
                <span>
                  {language === 'te' ? 'దళారీ కమిషన్లు లేవు · ప్రభుత్వ కనీస ధర హామీ · డిజిటల్ తూకం'
                    : language === 'hi' ? 'कोई बिचौलिया नहीं · सरकारी न्यूनतम मूल्य गारंटी · डिजिटल तौल'
                    : 'Zero middlemen · Govt floor price guarantee · Digital weighment'}
                </span>
              </div>
            </div>
          )}

          {/* ======================================================= */}
          {/* SCREEN: WIZARD (STEPS 1-5) */}
          {/* ======================================================= */}
          {currentScreen === 'wizard' && (
            <div className="space-y-5">
              {/* Step progress */}
              {wizardStep < 5 && (
                <div className="bg-white p-3 rounded-2xl border border-gray-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black text-emerald-800">
                      {language === 'te' ? `అంచె ${wizardStep}/4` : language === 'hi' ? `चरण ${wizardStep}/4` : `Step ${wizardStep} of 4`}
                    </span>
                    <button onClick={() => setCurrentScreen('menu')} className="text-xs text-gray-500 hover:text-gray-900 underline">
                      {t.home}
                    </button>
                  </div>
                  <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-600 h-full transition-all duration-300" style={{ width: `${(wizardStep / 4) * 100}%` }} />
                  </div>
                </div>
              )}

              {/* STEP 1: Select Crop */}
              {wizardStep === 1 && (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-black text-gray-900">
                      {language === 'te' ? '1. మీరు ఏ పంటను అమ్మదలిచారు?' : language === 'hi' ? '1. कौन सी फसल बेचना चाहते हैं?' : '1. Which crop do you want to sell?'}
                    </h3>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {ALL_CROPS.map((crop) => {
                      const isSelected = selectedCropId === crop.id;
                      return (
                        <button
                          key={crop.id}
                          type="button"
                          onClick={() => { setSelectedCropId(crop.id); setSelectedUnitId(crop.defaultUnit); }}
                          className={`p-4 rounded-2xl border-2 text-left flex flex-col gap-2 transition-all active:scale-95 ${isSelected ? 'bg-emerald-50 border-emerald-600 shadow-md ring-2 ring-emerald-400' : 'bg-white border-gray-200 hover:border-emerald-300'}`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-3xl">{crop.icon}</span>
                            {isSelected && <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black">✓</span>}
                          </div>
                          <div className="text-sm font-black text-gray-900">{crop.name[language]}</div>
                          <div className="text-xs font-bold text-emerald-700">₹{pricePerKg}/kg</div>
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                    <button onClick={() => setCurrentScreen('menu')} className="py-2.5 px-5 rounded-xl border border-gray-300 text-gray-700 font-bold text-sm flex items-center gap-2">
                      <ArrowLeft className="w-4 h-4" /> {t.back}
                    </button>
                    <button onClick={() => setWizardStep(2)} className="py-3 px-7 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm flex items-center gap-2 shadow-md">
                      {language === 'te' ? 'తదుపరి' : language === 'hi' ? 'अगला' : 'Next'}
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: Quantity */}
              {wizardStep === 2 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-black text-gray-900">
                    {language === 'te' ? '2. మీ వద్ద ఎంత దిగుబడి ఉంది?' : language === 'hi' ? '2. कितनी उपज है?' : '2. How much harvest do you have?'}
                  </h3>

                  {/* Selected crop summary */}
                  <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{selectedCrop.icon}</span>
                      <span className="font-bold text-gray-900 text-sm">{selectedCrop.name[language]}</span>
                    </div>
                    <span className="font-black text-emerald-700 text-sm">₹{pricePerKg}/kg</span>
                  </div>

                  {/* Unit selector */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {INDIAN_WEIGHT_UNITS.slice(0, 4).map((unit) => (
                      <button
                        key={unit.id}
                        type="button"
                        onClick={() => setSelectedUnitId(unit.id)}
                        className={`p-3 rounded-xl border-2 text-center font-bold text-xs transition-all ${selectedUnitId === unit.id ? 'bg-emerald-600 text-white border-emerald-700' : 'bg-white text-gray-800 border-gray-300 hover:border-emerald-400'}`}
                      >
                        <div className="font-black text-sm">{unit.name[language]}</div>
                        <div className={`text-[11px] ${selectedUnitId === unit.id ? 'text-emerald-100' : 'text-gray-500'}`}>{unit.shortCode}</div>
                      </button>
                    ))}
                  </div>

                  {/* Stepper */}
                  <div className="bg-white p-4 rounded-2xl border-2 border-emerald-300 space-y-3">
                    <div className="flex items-center justify-center gap-4">
                      <button type="button" onClick={() => setYieldQuantity((p) => Math.max(1, Math.round((p - 1) * 10) / 10))} className="w-14 h-14 rounded-2xl bg-gray-100 hover:bg-gray-200 border-2 border-gray-300 text-gray-800 flex items-center justify-center text-xl font-black active:scale-90">
                        <Minus className="w-6 h-6" />
                      </button>
                      <div className="text-center">
                        <input
                          type="number"
                          value={yieldQuantity === 0 ? '' : yieldQuantity}
                          onChange={(e) => { const v = parseFloat(e.target.value); setYieldQuantity(isNaN(v) ? 0 : Math.max(0, v)); }}
                          className="w-32 py-2 text-center text-4xl font-black bg-emerald-50/50 border-2 border-emerald-400 rounded-2xl text-emerald-950 focus:ring-4 focus:ring-emerald-300"
                        />
                        <div className="text-xs font-black text-gray-500 mt-1">{selectedUnit.name[language]}</div>
                      </div>
                      <button type="button" onClick={() => setYieldQuantity((p) => Math.round((p + 1) * 10) / 10)} className="w-14 h-14 rounded-2xl bg-gray-100 hover:bg-gray-200 border-2 border-gray-300 text-gray-800 flex items-center justify-center text-xl font-black active:scale-90">
                        <Plus className="w-6 h-6" />
                      </button>
                    </div>
                    {/* Quick add */}
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      {[1, 5, 10, 20].map((n) => (
                        <button key={n} type="button" onClick={() => setYieldQuantity((p) => (p || 0) + n)} className="px-3 py-1.5 rounded-xl bg-gray-100 hover:bg-emerald-100 text-gray-800 text-xs font-black border border-gray-300">+{n}</button>
                      ))}
                    </div>
                  </div>

                  {/* Payout display */}
                  <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white p-4 rounded-2xl flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-emerald-300">{t.totalCalculatedWeight}</div>
                      <div className="text-xl font-black">{totalWeightKg.toLocaleString('en-IN')} kg</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-emerald-300">{t.estimatedPayout}</div>
                      <div className="text-2xl font-black text-emerald-400">₹{estimatedTotalPayout}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                    <button onClick={() => setWizardStep(1)} className="py-2.5 px-5 rounded-xl border border-gray-300 text-gray-700 font-bold text-sm flex items-center gap-2">
                      <ArrowLeft className="w-4 h-4" /> {t.back}
                    </button>
                    <button onClick={() => setWizardStep(3)} className="py-3 px-7 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm flex items-center gap-2 shadow-md">
                      {language === 'te' ? 'తదుపరి' : language === 'hi' ? 'अगला' : 'Next'} <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: Village */}
              {wizardStep === 3 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-black text-gray-900">
                    {language === 'te' ? '3. మీ గ్రామం ఎంచుకోండి' : language === 'hi' ? '3. अपना गांव चुनें' : '3. Select Your Village'}
                  </h3>
                  <div className="space-y-2">
                    {villages.map((v) => {
                      const isSelected = selectedVillage === v.name;
                      return (
                        <button
                          key={v.name}
                          type="button"
                          onClick={() => setSelectedVillage(v.name)}
                          className={`w-full p-4 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${isSelected ? 'bg-emerald-50 border-emerald-600 ring-2 ring-emerald-400' : 'bg-white border-gray-200 hover:border-emerald-300'}`}
                        >
                          <div>
                            <div className="font-black text-gray-900">{v.label}</div>
                            <div className="text-xs text-emerald-700 font-bold flex items-center gap-1 mt-0.5">
                              <Truck className="w-3 h-3" />
                              {language === 'te' ? `లారీ ${v.time} లో వస్తుంది` : language === 'hi' ? `गाड़ी ${v.time} में` : `Truck arrives in ${v.time}`}
                            </div>
                          </div>
                          {isSelected && <span className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center text-sm font-black">✓</span>}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                    <button onClick={() => setWizardStep(2)} className="py-2.5 px-5 rounded-xl border border-gray-300 text-gray-700 font-bold text-sm flex items-center gap-2">
                      <ArrowLeft className="w-4 h-4" /> {t.back}
                    </button>
                    <button onClick={() => setWizardStep(4)} className="py-3 px-7 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm flex items-center gap-2 shadow-md">
                      {language === 'te' ? 'రశీదు చూడండి' : language === 'hi' ? 'रसीद देखें' : 'Review Slip'} <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 4: Confirm Slip */}
              {wizardStep === 4 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-black text-gray-900">
                    {language === 'te' ? '4. రశీదు నిర్ధారణ' : language === 'hi' ? '4. पर्ची की पुष्टि' : '4. Confirm Your Slip'}
                  </h3>

                  {/* Thermal slip */}
                  <div className="bg-white border-2 border-dashed border-gray-400 rounded-3xl p-5 max-w-md mx-auto shadow-sm space-y-3">
                    <div className="text-center border-b pb-3 border-gray-200">
                      <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                        {language === 'te' ? 'ఆంధ్రప్రదేశ్ ప్రభుత్వం · APMC గుంటూరు' : 'Govt. of Andhra Pradesh · APMC Guntur'}
                      </div>
                      <div className="text-base font-black text-gray-900 mt-1">
                        {language === 'te' ? 'డిజిటల్ రవాణా రశీదు' : language === 'hi' ? 'डिजिटल पिकअप रसीद' : 'Digital Pickup Slip'}
                      </div>
                    </div>
                    <div className="space-y-2 text-xs font-bold">
                      {[
                        [language === 'te' ? 'పంట' : language === 'hi' ? 'फसल' : 'Crop', selectedCrop.name[language]],
                        [language === 'te' ? 'పరిమాణం' : language === 'hi' ? 'मात्रा' : 'Quantity', `${yieldQuantity} ${selectedUnit.shortCode} (${totalWeightKg} kg)`],
                        [language === 'te' ? 'ధర' : language === 'hi' ? 'भाव' : 'Rate', `₹${pricePerKg}/kg (₹${pricePerQtl.toLocaleString('en-IN')}/Qtl)`],
                        [language === 'te' ? 'గ్రామం' : language === 'hi' ? 'गांव' : 'Village', selectedVillage],
                        [language === 'te' ? 'వాహనం' : language === 'hi' ? 'वाहन' : 'Vehicle', '2-Ton LCV-01 (AP 07 TJ 3401)'],
                        [language === 'te' ? 'చెల్లింపు' : language === 'hi' ? 'भुगतान' : 'Payment', language === 'te' ? 'ఆధార్ DBT · నేరుగా బ్యాంక్' : language === 'hi' ? 'आधार DBT · सीधे बैंक' : 'Aadhaar DBT · Direct Bank'],
                      ].map(([k, v]) => (
                        <div key={k} className="flex justify-between py-1 border-b border-gray-100">
                          <span className="text-gray-500">{k}:</span>
                          <span className="font-black text-gray-900 text-right max-w-[55%]">{v}</span>
                        </div>
                      ))}
                      <div className="flex justify-between items-baseline pt-2 border-t-2 border-gray-800">
                        <span className="font-black text-gray-900 uppercase text-sm">
                          {language === 'te' ? 'మొత్తం చెల్లింపు' : language === 'hi' ? 'कुल भुगतान' : 'Total Payout'}
                        </span>
                        <span className="text-2xl font-black text-emerald-700">₹{estimatedTotalPayout}</span>
                      </div>
                    </div>
                  </div>

                  <div className="max-w-md mx-auto space-y-3">
                    <button
                      id="atm-confirm-and-dispatch-btn"
                      type="button"
                      onClick={handleConfirmBooking}
                      className="w-full py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-lg flex items-center justify-center gap-3 shadow-lg active:scale-98"
                    >
                      <CheckCircle2 className="w-6 h-6" />
                      {language === 'te' ? 'అవును, లారీని పంపండి' : language === 'hi' ? 'हाँ, गाड़ी भेजें' : 'Confirm & Dispatch Truck'}
                    </button>
                    <button type="button" onClick={() => setWizardStep(2)} className="w-full py-3 px-6 rounded-2xl border-2 border-gray-300 text-gray-700 font-bold text-sm flex items-center justify-center gap-2 hover:bg-gray-100">
                      <ArrowLeft className="w-4 h-4" />
                      {language === 'te' ? 'వివరాలు మార్చండి' : language === 'hi' ? 'विवरण बदलें' : 'Change Details'}
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 5: Success */}
              {wizardStep === 5 && (
                <div className="space-y-5 text-center max-w-lg mx-auto py-4">
                  <div className="w-20 h-20 rounded-full bg-emerald-100 border-4 border-emerald-300 flex items-center justify-center text-4xl mx-auto">
                    ✓
                  </div>
                  <div>
                    <span className="text-xs font-black uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full">
                      {language === 'te' ? 'బుకింగ్ విజయవంతమైంది' : language === 'hi' ? 'बुकिंग सफल' : 'Booking Successful'} · {lastBookingId}
                    </span>
                    <h2 className="text-2xl font-black text-gray-900 mt-3">
                      {language === 'te' ? 'మీ గ్రామానికి లారీ బయలుదేరింది!' : language === 'hi' ? 'आपके गांव के लिए गाड़ी रवाना!' : 'Truck Dispatched to Your Village!'}
                    </h2>
                    <p className="text-sm text-gray-600 font-medium mt-1">
                      {language === 'te'
                        ? `G. వెంకటేశ్ (AP 07 TJ 3401) ${selectedVillage} చేరుకుంటారు.`
                        : language === 'hi'
                        ? `G. वेंकटेश (AP 07 TJ 3401) ${selectedVillage} पहुंचेंगे।`
                        : `G. Venkatesh (AP 07 TJ 3401) will arrive at ${selectedVillage}.`}
                    </p>
                  </div>
                  <div className="bg-emerald-50 border-2 border-emerald-300 p-4 rounded-2xl text-left space-y-2 text-sm font-bold text-emerald-950">
                    <div className="flex justify-between">
                      <span className="text-gray-500">{language === 'te' ? 'పంట' : language === 'hi' ? 'फसल' : 'Crop'}</span>
                      <span className="font-black">{selectedCrop.name[language]} ({totalWeightKg} kg)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">{language === 'te' ? 'బ్యాంక్ లో జమ' : language === 'hi' ? 'बैंक में जमा' : 'Bank Credit'}</span>
                      <span className="font-black text-emerald-700 text-base">₹{estimatedTotalPayout}</span>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button onClick={() => handleSpeak(language === 'te' ? `లారీ బుకింగ్ విజయవంతమైంది. రూ. ${estimatedTotalPayout} బ్యాంక్ లో పడుతుంది.` : `Truck booked. Rs. ${estimatedTotalPayout} credited to bank.`)} className="flex-1 py-3 rounded-xl bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-2">
                      <Volume2 className="w-4 h-4" /> {language === 'te' ? 'వినండి' : language === 'hi' ? 'सुनें' : 'Listen'}
                    </button>
                    <button onClick={() => window.print()} className="flex-1 py-3 rounded-xl border-2 border-emerald-600 text-emerald-800 font-black text-xs flex items-center justify-center gap-2 hover:bg-emerald-50">
                      <Printer className="w-4 h-4" /> {language === 'te' ? 'ప్రింట్' : language === 'hi' ? 'प्रिंट' : 'Print'}
                    </button>
                    <button onClick={() => { setCurrentScreen('menu'); setWizardStep(1); }} className="flex-1 py-3 rounded-xl bg-gray-900 text-white font-black text-xs flex items-center justify-center gap-2">
                      {t.home}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ======================================================= */}
          {/* SCREEN: RATES */}
          {/* ======================================================= */}
          {currentScreen === 'rates' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-black text-gray-900">
                  {language === 'te' ? 'నేటి మార్కెట్ గ్యారంటీ ధరలు' : language === 'hi' ? 'आज की गारंटीकृत मंडी दरें' : "Today's Guaranteed Market Rates"}
                </h3>
                <button onClick={() => setCurrentScreen('menu')} className="py-2 px-4 rounded-xl border border-gray-300 text-xs font-black text-gray-700 hover:bg-gray-100 flex items-center gap-1">
                  <ArrowLeft className="w-3.5 h-3.5" /> {t.back}
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[440px] overflow-y-auto pr-1">
                {ALL_CROPS.map((crop) => {
                  const perKg = Math.round(crop.pricePerQtl / 100);
                  return (
                    <div key={crop.id} className="bg-white p-4 rounded-2xl border-2 border-emerald-200 flex items-center gap-3 hover:border-emerald-500 transition-all">
                      <span className="text-3xl shrink-0">{crop.icon}</span>
                      <div className="flex-1">
                        <div className="font-black text-gray-900 text-sm">{crop.name[language]}</div>
                        <div className="text-xs text-gray-500">{crop.category}</div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-black text-emerald-700 text-lg">₹{perKg}/kg</div>
                        <div className="text-[11px] text-gray-500">₹{crop.pricePerQtl.toLocaleString('en-IN')}/Qtl</div>
                      </div>
                      <button type="button" onClick={() => { setSelectedCropId(crop.id); setSelectedUnitId(crop.defaultUnit); setWizardStep(2); setCurrentScreen('wizard'); }} className="ml-2 w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 hover:bg-emerald-700">
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ======================================================= */}
          {/* SCREEN: PASSBOOK / BANK RECEIPT */}
          {/* ======================================================= */}
          {currentScreen === 'passbook' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-black text-gray-900">
                  {language === 'te' ? 'నా బ్యాంక్ జమ రశీదు' : language === 'hi' ? 'मेरी बैंक जमा रसीद' : 'My Bank Deposit Receipt'}
                </h3>
                <button onClick={() => setCurrentScreen('menu')} className="py-2 px-4 rounded-xl border border-gray-300 text-xs font-black text-gray-700 hover:bg-gray-100 flex items-center gap-1">
                  <ArrowLeft className="w-3.5 h-3.5" /> {t.back}
                </button>
              </div>

              {/* Main balance card */}
              <div className="bg-gradient-to-br from-emerald-950 via-slate-900 to-teal-950 text-white p-6 rounded-3xl shadow-md space-y-4 max-w-md mx-auto">
                <div className="flex items-center justify-between border-b border-white/15 pb-3">
                  <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
                    {language === 'te' ? 'ఆధార్ DBT · NPCI ఎస్క్రో' : 'Aadhaar DBT · NPCI Escrow'}
                  </span>
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="text-xs text-gray-400 font-bold uppercase">{language === 'te' ? 'ఖాతాలో జమ అయిన మొత్తం' : language === 'hi' ? 'खाते में जमा राशि' : 'Amount Credited'}</div>
                  <div className="text-4xl font-black text-white mt-1">
                    ₹{latestContract ? latestContract.total_cleared_value.toLocaleString('en-IN') : '91,560'}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs font-medium border-t border-white/10 pt-3">
                  <div><span className="text-gray-400 block">{t.depositedTo}</span><span className="text-white font-bold">State Bank of India</span></div>
                  <div><span className="text-gray-400 block">{t.accountEnding}</span><span className="text-white font-bold">•••• 4012</span></div>
                  <div className="col-span-2 font-mono text-[11px] text-emerald-300/90">NPCI UTR: UTR-202609099412</div>
                </div>
              </div>

              {/* 4-step tracker */}
              <div className="bg-white p-4 rounded-2xl border border-gray-200">
                <div className="text-xs font-black text-gray-700 uppercase mb-3">{t.produceTrackerTitle}</div>
                <div className="space-y-2">
                  {[
                    { label: t.step1, sub: t.step1Sub, done: true },
                    { label: t.step2, sub: t.step2Sub, done: true },
                    { label: t.step3, sub: t.step3Sub, done: true },
                    { label: t.step4, sub: t.step4Sub, done: true, last: true },
                  ].map((step, i) => (
                    <div key={i} className={`flex items-center gap-3 p-3 rounded-xl ${step.last ? 'bg-emerald-600 text-white' : 'bg-emerald-50 border border-emerald-200'}`}>
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center font-black text-xs shrink-0 ${step.last ? 'bg-white text-emerald-700' : 'bg-emerald-600 text-white'}`}>{i + 1}</div>
                      <div>
                        <div className={`font-black text-sm ${step.last ? 'text-white' : 'text-emerald-900'}`}>{step.label}</div>
                        <div className={`text-xs ${step.last ? 'text-emerald-100' : 'text-gray-500'}`}>{step.sub}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ======================================================= */}
          {/* SCREEN: MY ORDER HISTORY */}
          {/* ======================================================= */}
          {currentScreen === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-black text-gray-900">{t.myOrders}</h3>
                <button onClick={() => setCurrentScreen('menu')} className="py-2 px-4 rounded-xl border border-gray-300 text-xs font-black text-gray-700 hover:bg-gray-100 flex items-center gap-1">
                  <ArrowLeft className="w-3.5 h-3.5" /> {t.back}
                </button>
              </div>

              {sessionOrders.length === 0 ? (
                <div className="text-center py-10 text-gray-400 font-medium">{t.noOrdersYet}</div>
              ) : (
                <div className="space-y-3 max-h-[440px] overflow-y-auto pr-1">
                  {sessionOrders.map((order) => (
                    <div key={order.orderId} className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm">
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <div>
                          <div className="font-black text-gray-900 text-sm">{order.orderId}</div>
                          <div className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                            <Clock className="w-3 h-3" /> {order.bookingTime}
                          </div>
                        </div>
                        <span className={`px-2.5 py-1 rounded-full font-bold text-[11px] shrink-0 ${
                          order.status === 'DBT_PAID' ? 'bg-emerald-100 text-emerald-800' :
                          order.status === 'IN_TRANSIT' ? 'bg-amber-100 text-amber-800' :
                          order.status === 'WEIGHED_AT_APMC' ? 'bg-purple-100 text-purple-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {order.status === 'DBT_PAID' ? t.statusPaid :
                           order.status === 'IN_TRANSIT' ? t.statusInTransit :
                           order.status === 'WEIGHED_AT_APMC' ? t.statusWeighed :
                           t.statusScheduled}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs font-medium text-gray-600">
                        <div><span className="text-gray-400">{t.cropName}: </span>{order.cropName}</div>
                        <div><span className="text-gray-400">{t.quantity}: </span>{order.yieldQuantity} {order.unit}</div>
                        <div><span className="text-gray-400">{t.farmerVillage ?? 'Village'}: </span>{order.village}</div>
                        <div className="font-black text-emerald-700"><span className="text-gray-400 font-medium">{t.totalPayout}: </span>₹{order.totalPayout.toLocaleString('en-IN')}</div>
                      </div>
                      {order.utrNumber && (
                        <div className="mt-2 pt-2 border-t border-gray-100 text-[11px] font-mono text-gray-500">{order.utrNumber}</div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* ATM Footer */}
        <div className="bg-gray-100 border-t border-gray-200 p-3 flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-gray-600">
          <div className="flex items-center gap-2">
            <PhoneCall className="w-4 h-4 text-emerald-700" />
            <span>1800-425-1515</span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={onOpenAiAssistant} className="text-emerald-800 hover:text-emerald-900 underline">
              {language === 'te' ? 'AI మిత్ర' : language === 'hi' ? 'AI साथी' : 'AI Saathi'}
            </button>
            <span className="text-gray-300">|</span>
            <button onClick={onSwitchToOperator} className="text-sky-800 hover:text-sky-900 underline">
              {t.operatorMode}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
