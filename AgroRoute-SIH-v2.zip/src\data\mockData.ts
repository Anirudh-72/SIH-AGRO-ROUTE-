import { FarmerAsk, BuyerBid, MatchedContract, LcvVehicle, PricePoint, VleLedgerRow } from '../types';

export const GUNTUR_APMC_LAT = 16.3067;
export const GUNTUR_APMC_LON = 80.4365;

export const VIJAYAWADA_HUB_LAT = 16.5062;
export const VIJAYAWADA_HUB_LON = 80.6480;

export const INITIAL_FARMER_ASKS: FarmerAsk[] = [
  {
    farmer_id: 'F-AP-101',
    name: 'V. Sambasiva Rao',
    village: 'Tadikonda',
    commodity: 'Guntur Teja Mirchi',
    weight_kg: 420,
    ask_price_per_qtl: 21800,
    lat: 16.4258,
    lon: 80.4619,
    vle_id: 'VLE-GNT-01',
    contact: '98480*****',
  },
  {
    farmer_id: 'F-AP-102',
    name: 'K. Venkata Reddy',
    village: 'Mangalagiri',
    commodity: 'Guntur Teja Mirchi',
    weight_kg: 550,
    ask_price_per_qtl: 21500,
    lat: 16.4357,
    lon: 80.5594,
    vle_id: 'VLE-GNT-02',
    contact: '98491*****',
  },
  {
    farmer_id: 'F-AP-103',
    name: 'M. Subrahmanyam',
    village: 'Pedakakani',
    commodity: 'Guntur Teja Mirchi',
    weight_kg: 680,
    ask_price_per_qtl: 21700,
    lat: 16.3456,
    lon: 80.4952,
    vle_id: 'VLE-GNT-01',
    contact: '94402*****',
  },
  {
    farmer_id: 'F-AP-104',
    name: 'P. Nageswara Rao',
    village: 'Amaravati Rural',
    commodity: 'Shankar-6 Cotton',
    weight_kg: 850,
    ask_price_per_qtl: 7450,
    lat: 16.5735,
    lon: 80.3575,
    vle_id: 'VLE-GNT-03',
    contact: '99890*****',
  },
  {
    farmer_id: 'F-AP-105',
    name: 'B. Anjaneyulu',
    village: 'Chebrolu',
    commodity: 'Guntur Teja Mirchi',
    weight_kg: 350,
    ask_price_per_qtl: 21900,
    lat: 16.1969,
    lon: 80.5317,
    vle_id: 'VLE-GNT-04',
    contact: '94901*****',
  },
  {
    farmer_id: 'F-AP-106',
    name: 'Ch. Srinivasa Rao',
    village: 'Tenali Rural',
    commodity: 'Shankar-6 Cotton',
    weight_kg: 920,
    ask_price_per_qtl: 7400,
    lat: 16.2435,
    lon: 80.6400,
    vle_id: 'VLE-KRI-01',
    contact: '98665*****',
  },
  {
    farmer_id: 'F-AP-107',
    name: 'G. Koteswara Rao',
    village: 'Kanchikacherla',
    commodity: 'Shankar-6 Cotton',
    weight_kg: 700,
    ask_price_per_qtl: 7500,
    lat: 16.6397,
    lon: 80.3854,
    vle_id: 'VLE-KRI-02',
    contact: '97012*****',
  },
  {
    farmer_id: 'F-AP-108',
    name: 'D. Ramanjaneyulu',
    village: 'Prathipadu',
    commodity: 'Guntur Teja Mirchi',
    weight_kg: 480,
    ask_price_per_qtl: 21650,
    lat: 16.1833,
    lon: 80.3500,
    vle_id: 'VLE-GNT-04',
    contact: '91773*****',
  },
  {
    farmer_id: 'F-AP-109',
    name: 'T. Appa Rao',
    village: 'Ibrahimpatnam',
    commodity: 'Guntur Teja Mirchi',
    weight_kg: 620,
    ask_price_per_qtl: 21600,
    lat: 16.5892,
    lon: 80.5217,
    vle_id: 'VLE-KRI-03',
    contact: '98485*****',
  },
];

export const INITIAL_BUYER_BIDS: BuyerBid[] = [
  {
    bid_id: 'B-ITC-901',
    buyer_name: 'ITC Agri-Business Division',
    hub_name: 'Guntur APMC Yard Hub',
    commodity: 'Guntur Teja Mirchi',
    demand_weight_kg: 2500,
    bid_price_per_qtl: 22400,
    lat: GUNTUR_APMC_LAT,
    lon: GUNTUR_APMC_LON,
  },
  {
    bid_id: 'B-MDH-902',
    buyer_name: 'Mahashian Spices Procurement',
    hub_name: 'Guntur Cold Storage Cluster',
    commodity: 'Guntur Teja Mirchi',
    demand_weight_kg: 1800,
    bid_price_per_qtl: 22100,
    lat: 16.3200,
    lon: 80.4500,
  },
  {
    bid_id: 'B-TEX-903',
    buyer_name: 'Coastal Andhra Spinning Mills',
    hub_name: 'Vijayawada Auto Nagar Yard',
    commodity: 'Shankar-6 Cotton',
    demand_weight_kg: 3000,
    bid_price_per_qtl: 7650,
    lat: VIJAYAWADA_HUB_LAT,
    lon: VIJAYAWADA_HUB_LON,
  },
];

/**
 * Haversine formula to compute great-circle distance between two GPS coordinates in kilometers.
 */
export function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371.0; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Filter farmer asks within the specified Haversine radius from target hub.
 */
export function filterAsksByHaversine(
  asks: FarmerAsk[],
  hubLat: number,
  hubLon: number,
  radiusKm: number = 8.0
): FarmerAsk[] {
  return asks.map((ask) => {
    const dist = haversineDistance(ask.lat, ask.lon, hubLat, hubLon);
    return {
      ...ask,
      distance_to_hub_km: Math.round(dist * 10) / 10,
      within_pooling_radius: dist <= radiusKm,
    };
  });
}

/**
 * Deterministic Continuous Double Auction Matcher.
 * Matches when Bid >= Ask.
 * Clearing Price = (Bid + Ask) / 2
 */
export function runContinuousDoubleAuction(
  asks: FarmerAsk[],
  bids: BuyerBid[],
  commodity: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton'
): { matched: MatchedContract[]; remainingAsks: FarmerAsk[]; remainingBids: BuyerBid[] } {
  // Filter for commodity and clone to preserve immutability
  const filteredAsks = asks
    .filter((a) => a.commodity === commodity && (a.within_pooling_radius ?? true))
    .map((a) => ({ ...a }));
  const filteredBids = bids.filter((b) => b.commodity === commodity).map((b) => ({ ...b }));

  // Sort asks ascending by price, then descending by weight
  filteredAsks.sort((a, b) => a.ask_price_per_qtl - b.ask_price_per_qtl || b.weight_kg - a.weight_kg);

  // Sort bids descending by price, then descending by weight
  filteredBids.sort((a, b) => b.bid_price_per_qtl - a.bid_price_per_qtl || b.demand_weight_kg - a.demand_weight_kg);

  const matched: MatchedContract[] = [];
  let aIdx = 0;
  let bIdx = 0;

  while (aIdx < filteredAsks.length && bIdx < filteredBids.length) {
    const ask = filteredAsks[aIdx];
    const bid = filteredBids[bIdx];

    if (bid.bid_price_per_qtl >= ask.ask_price_per_qtl) {
      const clearedQty = Math.min(ask.weight_kg, bid.demand_weight_kg);
      const clearingPrice = (bid.bid_price_per_qtl + ask.ask_price_per_qtl) / 2;
      const clearedVal = (clearedQty / 100) * clearingPrice;
      const fSurplus = (clearingPrice - ask.ask_price_per_qtl) * (clearedQty / 100);
      const bSurplus = (bid.bid_price_per_qtl - clearingPrice) * (clearedQty / 100);

      matched.push({
        contract_id: `TXN-AUC-${matched.length + 101}`,
        farmer_id: ask.farmer_id,
        farmer_name: ask.name,
        village: ask.village,
        lat: ask.lat,
        lon: ask.lon,
        vle_id: ask.vle_id,
        buyer_id: bid.bid_id,
        buyer_name: bid.buyer_name,
        commodity: commodity,
        weight_kg: clearedQty,
        farmer_ask_qtl: ask.ask_price_per_qtl,
        buyer_bid_qtl: bid.bid_price_per_qtl,
        clearing_price_qtl: Math.round(clearingPrice * 100) / 100,
        total_cleared_value: Math.round(clearedVal * 100) / 100,
        farmer_surplus: Math.round(fSurplus * 100) / 100,
        buyer_surplus: Math.round(bSurplus * 100) / 100,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      });

      ask.weight_kg -= clearedQty;
      bid.demand_weight_kg -= clearedQty;

      if (ask.weight_kg <= 0) aIdx++;
      if (bid.demand_weight_kg <= 0) bIdx++;
    } else {
      break;
    }
  }

  return { matched, remainingAsks: filteredAsks, remainingBids: filteredBids };
}

/**
 * Greedy Bin-Packing Algorithm for 2-Ton (2000 kg) LCVs (First-Fit Decreasing).
 */
export function runGreedyBinPacking(
  matchedLots: MatchedContract[],
  lcvCapacityKg: number = 2000.0
): LcvVehicle[] {
  if (matchedLots.length === 0) return [];

  // Sort lots by weight descending
  const sorted = [...matchedLots].sort((a, b) => b.weight_kg - a.weight_kg);
  const vehicles: LcvVehicle[] = [];

  const driverNames = ['G. Venkatesh', 'K. Rama Rao', 'B. Mastan Vali', 'T. Govinda Rao'];

  for (const lot of sorted) {
    let packed = false;
    for (const v of vehicles) {
      if (v.current_load_kg + lot.weight_kg <= lcvCapacityKg) {
        v.current_load_kg += lot.weight_kg;
        v.lots.push(lot);
        packed = true;
        break;
      }
    }

    if (!packed) {
      const idx = vehicles.length;
      vehicles.push({
        vehicle_id: `LCV-AP-0${idx + 1}`,
        driver_name: driverNames[idx % driverNames.length],
        vehicle_reg: `AP 07 TJ ${3401 + idx}`,
        capacity_kg: lcvCapacityKg,
        current_load_kg: lot.weight_kg,
        utilization_pct: 0,
        lot_count: 0,
        total_val: 0,
        lots: [lot],
      });
    }
  }

  // Calculate stats
  vehicles.forEach((v) => {
    v.utilization_pct = Math.round((v.current_load_kg / v.capacity_kg) * 1000) / 10;
    v.lot_count = v.lots.length;
    v.total_val = Math.round(v.lots.reduce((acc, l) => acc + l.total_cleared_value, 0) * 100) / 100;
  });

  return vehicles;
}

/**
 * Generate 30 days of Agmarknet modal prices with 7-day rolling average
 * and distress protection floor.
 */
export function generateAgmarknetHistoricalData(
  commodity: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton'
): PricePoint[] {
  const basePrice = commodity === 'Guntur Teja Mirchi' ? 21300 : 7350;
  const points: PricePoint[] = [];

  // 30 days data
  const rawModal: number[] = [
    basePrice - 200,
    basePrice - 150,
    basePrice + 50,
    basePrice + 120,
    basePrice - 80,
    basePrice + 160,
    basePrice + 240,
    basePrice + 180,
    basePrice + 290,
    basePrice + 210,
    basePrice + 320,
    basePrice + 390,
    basePrice + 280,
    basePrice + 190,
    basePrice + 230,
    basePrice + 310,
    basePrice + 420,
    basePrice + 380,
    basePrice + 450,
    basePrice + 520,
    basePrice + 480,
    basePrice + 590,
    basePrice + 510,
    basePrice + 620,
    basePrice + 680,
    basePrice + 610,
    basePrice + 720,
    basePrice + 790,
    basePrice + 740,
    basePrice + 850,
  ];

  const now = new Date();

  for (let i = 0; i < 30; i++) {
    const d = new Date(now.getTime() - (29 - i) * 24 * 60 * 60 * 1000);
    const dateStr = d.toISOString().split('T')[0];

    // Compute 7-day rolling window
    const startWindow = Math.max(0, i - 6);
    const windowSlice = rawModal.slice(startWindow, i + 1);
    const avg7 = windowSlice.reduce((a, b) => a + b, 0) / windowSlice.length;
    const floor = avg7 * 0.93; // 93% distress floor

    points.push({
      date: dateStr.substring(5), // MM-DD
      daily_modal_price: rawModal[i],
      rolling_avg_7d: Math.round(avg7),
      distress_floor: Math.round(floor),
    });
  }

  return points;
}

/**
 * Generate simulated SHA-256 hash
 */
export function generateHash(input: string): string {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return `0x9a8f4c2e${hex}7b1d6f43e20a816c${hex.split('').reverse().join('')}`;
}

export function generateSmsPayload(contract: MatchedContract): {
  smsEn: string;
  smsTe: string;
  txHash: string;
} {
  const signature = `${contract.contract_id}|${contract.farmer_id}|${contract.weight_kg}|${contract.clearing_price_qtl}|${contract.total_cleared_value}|${contract.vle_id}`;
  const txHash = generateHash(signature);

  const smsEn = `[KRISHI-SETU GOVT NPCI ESCROW]
Dear ${contract.farmer_name},
Your ${contract.commodity} weighment of ${contract.weight_kg} KG is verified at ${contract.village} Gate.
Clearing Rate: Rs.${contract.clearing_price_qtl.toLocaleString('en-IN')}/Qtl (Auction #${contract.contract_id}).
Total Credit: Rs.${contract.total_cleared_value.toLocaleString('en-IN', { minimumFractionDigits: 2 })} initiated directly to your Aadhaar-seeded Bank A/C via Direct Benefit Transfer.
VLE Ref: ${contract.vle_id} | Zero-Cash Protocol.
SHA256 Sig: ${txHash.substring(0, 18)}...`;

  const smsTe = `[కృషి-సేతు నేషనల్ అగ్రికల్చరల్ ఎస్క్రో]
గౌరవనీయులైన ${contract.farmer_name} గారికి,
మీ ${contract.village} కేంద్రం వద్ద ${contract.commodity} తూకం ${contract.weight_kg} కేజీలు ధృవీకరించబడింది.
ధర: క్వింటాల్ కు రూ. ${contract.clearing_price_qtl.toLocaleString('en-IN')}.
మొత్తం చెల్లింపు: రూ. ${contract.total_cleared_value.toLocaleString('en-IN', { minimumFractionDigits: 2 })} నేరుగా మీ ఆధార్ లింక్డ్ బ్యాంక్ ఖాతాకు జమచేయబడుతుంది.
క్యాష్ రహిత డిజిటల్ రశీదు కోడ్: ${txHash.substring(0, 18)}...`;

  return { smsEn, smsTe, txHash };
}

export function generateVleLedger(contracts: MatchedContract[]): VleLedgerRow[] {
  return contracts.map((c, idx) => {
    const fee = Math.round(c.total_cleared_value * 0.0075 * 100) / 100;
    return {
      txn_ref: c.contract_id,
      timestamp: c.timestamp,
      vle_id: c.vle_id,
      farmer_name: c.farmer_name,
      village: c.village,
      commodity: c.commodity,
      net_cleared: c.total_cleared_value,
      vle_fee: fee,
      target_upi: `${c.vle_id.toLowerCase()}@sbi`,
      npci_utr: `UTR-20260909${90000 + idx}`,
      status: 'SETTLED_VIA_UPI',
    };
  });
}
