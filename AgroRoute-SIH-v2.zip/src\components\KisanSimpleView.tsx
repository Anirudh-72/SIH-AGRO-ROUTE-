import React, { useState } from 'react';
import { SupportedLanguage, TRANSLATIONS } from '../data/translations';
import { ALL_CROPS, INDIAN_WEIGHT_UNITS } from '../data/cropsAndUnits';
import { speakVernacularText, stopSpeech } from '../utils/speechUtils';
import { MatchedContract } from '../types';
import {
  Volume2,
  VolumeX,
  Truck,
  CheckCircle2,
  Landmark,
  ShieldCheck,
  Package,
  Plus,
  Minus,
  Sparkles,
  PhoneCall,
  MessageSquare,
  Bot,
  ArrowRight,
  Clock,
  MapPin,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface KisanSimpleViewProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  commodity: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton';
  latestContract?: MatchedContract;
  onOpenAiAssistant: () => void;
  onOpenWhatsAppDrawer: () => void;
  onSwitchToOperator: () => void;
}

export const KisanSimpleView: React.FC<KisanSimpleViewProps> = ({
  language,
  onLanguageChange,
  commodity,
  latestContract,
  onOpenAiAssistant,
  onOpenWhatsAppDrawer,
  onSwitchToOperator,
}) => {
  const t = TRANSLATIONS[language];

  // Audio speaking state
  const [speakingSection, setSpeakingSection] = useState<string | null>(null);

  // Doorstep Pickup Form State
  const initialCropId = commodity === 'Shankar-6 Cotton' ? 'cotton' : 'chilli';
  const [selectedCropId, setSelectedCropId] = useState<string>(initialCropId);
  const [yieldQuantity, setYieldQuantity] = useState<number>(10);
  const [selectedUnitId, setSelectedUnitId] = useState<string>('quintal');
  const [selectedVillage, setSelectedVillage] = useState<string>('Tadikonda');
  const [bookingSuccess, setBookingSuccess] = useState<boolean>(false);

  // Crop & Weight Unit resolution
  const selectedCrop = ALL_CROPS.find((c) => c.id === selectedCropId) || ALL_CROPS[0];
  const selectedUnit =
    INDIAN_WEIGHT_UNITS.find((u) => u.id === selectedUnitId) || INDIAN_WEIGHT_UNITS[0];

  // Dynamic calculations based on farmer yield and Indian weight units
  const totalWeightKg = Math.max(0, Math.round((yieldQuantity || 0) * selectedUnit.kgMultiplier * 100) / 100);
  const totalWeightQtl = (totalWeightKg / 100).toFixed(2);

  const pricePerQtl = selectedCrop.pricePerQtl;
  const pricePerKg = Math.round(pricePerQtl / 100);
  const rawTotalPayout = Math.round(totalWeightKg * (pricePerQtl / 100));
  const estimatedTotalPayout = rawTotalPayout.toLocaleString('en-IN');
  const distressDiff = selectedCrop.pricePerQtl - selectedCrop.distressFloor;
  const distressDiffKg = Math.round(distressDiff / 100);

  const villages = [
    'Tadikonda',
    'Mangalagiri',
    'Pedakakani',
    'Chebrolu',
    'Amaravati Rural',
    'Tenali Rural',
  ];

  // Audio Playback Handler
  const handleListen = (sectionKey: string, textToSpeak: string) => {
    if (speakingSection === sectionKey) {
      stopSpeech();
      setSpeakingSection(null);
      return;
    }

    setSpeakingSection(sectionKey);
    speakVernacularText(
      textToSpeak,
      language,
      () => setSpeakingSection(sectionKey),
      () => setSpeakingSection(null),
      () => setSpeakingSection(null)
    );
  };

  // 1-Click Doorstep Pickup Booking
  const handleBookPickup = () => {
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // Ignore if confetti fails
    }

    setBookingSuccess(true);

    const cropName = selectedCrop.name[language];
    const unitName = selectedUnit.name[language];

    // Speak audio confirmation in chosen language with exact crop, weight, and unit
    const confirmationSpeech =
      language === 'te'
        ? `లారీ బుకింగ్ విజయవంతమైంది! మీ ${selectedVillage} గ్రామానికి LCV-01 బయలుదేరింది. ${yieldQuantity} ${unitName} (${totalWeightKg.toLocaleString('en-IN')} కేజీల) ${cropName} దిగుబడికి సుమారు రూ. ${estimatedTotalPayout} మీ బ్యాంక్ ఖాతాలో జమ అవుతుంది.`
        : language === 'hi'
        ? `पिकअप गाड़ी सफलतापूर्वक बुक हो गई है! आपके गांव ${selectedVillage} के लिए गाड़ी रवाना हो चुकी है। ${yieldQuantity} ${unitName} (${totalWeightKg.toLocaleString('en-IN')} किलो) ${cropName} की कुल उपज का अनुमानित भुगतान ₹${estimatedTotalPayout} आपके बैंक खाते में जमा होगा।`
        : `Pickup vehicle booked successfully! 2-Ton vehicle dispatched to ${selectedVillage}. For ${yieldQuantity} ${selectedUnit.shortCode} (${totalWeightKg.toLocaleString('en-IN')} kg) of ${cropName}, estimated payout of Rs. ${estimatedTotalPayout} will be credited to your bank account.`;

    handleListen('booking', confirmationSpeech);

    setTimeout(() => {
      setBookingSuccess(false);
    }, 9000);
  };

  // Text strings for price speech
  const currentCropName = selectedCrop.name[language];
  const priceSpeechText =
    language === 'te'
      ? `నమస్కారం రైతు సోదరులారా! ఈరోజు గుంటూరు మార్కెట్ యార్డ్ వద్ద ${currentCropName} గ్యారంటీ ధర కేజీకి రూ. ${pricePerKg}, క్వింటాల్ కు రూ. ${pricePerQtl.toLocaleString('en-IN')}. ఇది ప్రభుత్వ కనీస రక్షణ ధర కంటే రూ. ${distressDiffKg} ఎక్కువ. నేడు మీ పంట అమ్మడం రైతులకు చాలా లాభదాయకం.`
      : language === 'hi'
      ? `नमस्कार किसान भाइयों! आज गुंटूर मंडी में ${currentCropName} का गारंटीकृत भाव ₹${pricePerKg} प्रति किलो है, यानी ₹${pricePerQtl.toLocaleString('en-IN')} प्रति क्विंटल। यह सरकारी सुरक्षा मूल्य से ₹${distressDiffKg} अधिक है। आज अपनी फसल बेचना सुरक्षित और फायदेमंद है।`
      : `Hello respected farmers! Today's guaranteed mandi price for ${currentCropName} is Rs. ${pricePerKg} per kg, or Rs. ${pricePerQtl.toLocaleString('en-IN')} per quintal. This is Rs. ${distressDiffKg} above the government distress floor. It is safe and profitable to sell today.`;

  const paymentSpeechText =
    language === 'te'
      ? `మీ పంట సొమ్ము రూ. 91,560 స్టేట్ బ్యాంక్ ఆఫ్ ఇండియా ఖాతా నంబర్ 4012 కు నేరుగా జమ చేయబడింది. ఎటువంటి దళారీ కమీషన్ లేదా తూకం కటింగ్స్ లేవు.`
      : language === 'hi'
      ? `आपकी फसल का पूरा भुगतान ₹91,560 भारतीय स्टेट बैंक खाता 4012 में सीधे जमा कर दिया गया है। बिना किसी बिचौलिए या कमीशन कटौती के।`
      : `Your produce payout of Rs. 91,560 has been directly credited to your State Bank of India account ending in 4012 via Direct Benefit Transfer. Zero deductions.`;

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Top Welcome & Language Selection Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-900 to-emerald-950 text-white rounded-2xl p-5 md:p-6 shadow-md border border-emerald-700/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5">
              <span className="px-2.5 py-1 rounded-full text-xs font-black bg-amber-400 text-emerald-950 uppercase tracking-wide">
                🌾 {t.farmerMode}
              </span>
              <span className="text-xs text-emerald-200 font-semibold">
                APMC Guntur • Zero Middlemen
              </span>
            </div>
            <h2 className="text-2xl md:text-3xl font-black tracking-tight">{t.appName}</h2>
            <p className="text-xs md:text-sm text-emerald-100/90 max-w-xl">{t.subTitle}</p>
          </div>

          {/* Quick Controls: Language Switcher & Operator View */}
          <div className="flex flex-wrap items-center gap-2.5 bg-white/10 backdrop-blur-xs p-2 rounded-xl border border-white/15">
            <span className="text-xs font-bold text-emerald-200 pl-1">{t.switchLanguage}</span>
            <div className="flex items-center bg-black/30 p-1 rounded-lg">
              <button
                onClick={() => onLanguageChange('te')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                  language === 'te'
                    ? 'bg-emerald-500 text-white shadow-xs'
                    : 'text-gray-300 hover:text-white'
                }`}
              >
                తెలుగు
              </button>
              <button
                onClick={() => onLanguageChange('hi')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                  language === 'hi'
                    ? 'bg-emerald-500 text-white shadow-xs'
                    : 'text-gray-300 hover:text-white'
                }`}
              >
                हिंदी
              </button>
              <button
                onClick={() => onLanguageChange('en')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                  language === 'en'
                    ? 'bg-emerald-500 text-white shadow-xs'
                    : 'text-gray-300 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
            <button
              onClick={onSwitchToOperator}
              className="px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-600 text-white text-xs font-bold rounded-lg transition-colors border border-emerald-400/30"
            >
              ⚙️ {t.operatorMode}
            </button>
          </div>
        </div>

        {/* Quick Help & Vernacular AI Assistant Trigger Banner */}
        <div className="mt-4 pt-4 border-t border-emerald-700/50 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-emerald-100">
            <PhoneCall className="w-4 h-4 text-amber-300" />
            <span>{t.callHelpdesk}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenWhatsAppDrawer}
              className="px-3.5 py-1.5 bg-[#25D366] hover:bg-[#20bd5a] text-emerald-950 font-bold rounded-lg flex items-center gap-1.5 transition-all shadow-xs"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp Voice</span>
            </button>
            <button
              onClick={onOpenAiAssistant}
              className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold rounded-lg flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Bot className="w-4 h-4" />
              <span>{t.aiAssistantTitle}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3 GIANT TACTILE CARDS (HIGH-CRAFT, ZERO-JARGON FOR FARMERS) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* CARD 1: TODAY'S GUARANTEED MANDI PRICE */}
        <div className="bg-white rounded-2xl p-6 border-2 border-emerald-500 shadow-sm flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-emerald-500 text-white px-3 py-1 text-[11px] font-black uppercase tracking-wider rounded-bl-xl">
            Live Mandi Rate
          </div>

          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-2xl">{selectedCrop.icon}</span>
              <div>
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider block">
                  {t.todayMandiPrice}
                </span>
                <span className="text-sm font-black text-emerald-900 leading-tight block">
                  {selectedCrop.name[language]}
                </span>
              </div>
            </div>

            {/* Huge Tactile Numbers: Both Per KG and Per Quintal */}
            <div className="my-3 bg-emerald-50/80 p-4 rounded-xl border border-emerald-100">
              <div className="text-4xl md:text-5xl font-black text-emerald-900 tracking-tight">
                ₹{pricePerKg} <span className="text-lg font-bold text-gray-600">{t.perKg}</span>
              </div>
              <div className="text-sm font-semibold text-emerald-700 mt-1 flex items-center justify-between">
                <span>(₹{pricePerQtl.toLocaleString('en-IN')} {t.perQuintal})</span>
                <span className="text-xs px-2 py-0.5 bg-emerald-100 rounded-full font-bold text-emerald-800">
                  {selectedCrop.category}
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2 text-xs font-semibold text-emerald-800 bg-emerald-100/70 p-2.5 rounded-lg mb-4">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
              <span>
                +₹{distressDiffKg}/kg (+₹{distressDiff.toLocaleString('en-IN')}/Qtl) {t.floorProtected}
              </span>
            </div>
          </div>

          {/* Large Audio Read-Aloud Button */}
          <button
            id="kisan-listen-price-btn"
            onClick={() => handleListen('price', priceSpeechText)}
            className={`w-full py-3 px-4 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all shadow-xs ${
              speakingSection === 'price'
                ? 'bg-amber-500 text-emerald-950 animate-pulse'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white'
            }`}
          >
            {speakingSection === 'price' ? (
              <>
                <VolumeX className="w-5 h-5" />
                <span>{t.stopAudio}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-5 h-5" />
                <span>🔊 {t.listenAudio}</span>
              </>
            )}
          </button>
        </div>

        {/* CARD 2: 1-CLICK DOORSTEP PICKUP BOOKING */}
        <div className="bg-white rounded-2xl p-6 border-2 border-sky-500 shadow-sm flex flex-col justify-between">
          <div className="space-y-3.5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                  {t.bookPickupTitle}
                </div>
                <p className="text-[11px] text-gray-600 mt-0.5">{t.bookPickupSubtitle}</p>
              </div>
              <span className="p-1.5 bg-sky-100 text-sky-700 rounded-md shrink-0">
                <Truck className="w-4 h-4" />
              </span>
            </div>

            {/* SECTION 1: ALL CROPS DROPDOWN & QUICK SELECT */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="kisan-crop-dropdown" className="text-xs font-bold text-gray-800 flex items-center gap-1">
                  <span>🌾 {t.allCropsDropdownLabel}</span>
                </label>
                <span className="text-[11px] font-semibold text-sky-700">
                  {ALL_CROPS.length} Crops Available
                </span>
              </div>

              {/* Comprehensive All-Crops Dropdown */}
              <select
                id="kisan-crop-dropdown"
                value={selectedCropId}
                onChange={(e) => {
                  const newCropId = e.target.value;
                  setSelectedCropId(newCropId);
                  const crop = ALL_CROPS.find((c) => c.id === newCropId);
                  if (crop) {
                    setSelectedUnitId(crop.defaultUnit);
                  }
                }}
                className="w-full text-xs font-bold py-2.5 px-3 bg-sky-50/60 border border-sky-300 rounded-xl text-gray-900 focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all shadow-xs"
              >
                {/* Spices */}
                <optgroup label="Spices & Commercial">
                  {ALL_CROPS.filter((c) => c.category === 'Spices' || c.category === 'Commercial').map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.icon} {c.name[language]} — ₹{c.pricePerQtl.toLocaleString('en-IN')}/Qtl
                    </option>
                  ))}
                </optgroup>
                {/* Fibre & Cereals */}
                <optgroup label="Fibre & Cereals">
                  {ALL_CROPS.filter((c) => c.category === 'Fibre' || c.category === 'Cereals').map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.icon} {c.name[language]} — ₹{c.pricePerQtl.toLocaleString('en-IN')}/Qtl
                    </option>
                  ))}
                </optgroup>
                {/* Pulses & Oilseeds */}
                <optgroup label="Pulses & Oilseeds">
                  {ALL_CROPS.filter((c) => c.category === 'Pulses' || c.category === 'Oilseeds').map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.icon} {c.name[language]} — ₹{c.pricePerQtl.toLocaleString('en-IN')}/Qtl
                    </option>
                  ))}
                </optgroup>
                {/* Vegetables */}
                <optgroup label="Vegetables">
                  {ALL_CROPS.filter((c) => c.category === 'Vegetables').map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.icon} {c.name[language]} — ₹{c.pricePerQtl.toLocaleString('en-IN')}/Qtl
                    </option>
                  ))}
                </optgroup>
              </select>

              {/* Quick Select Buttons for Key APMC Commodities */}
              <div className="mt-2">
                <div className="text-[10px] font-bold text-gray-500 mb-1 flex items-center justify-between">
                  <span>{t.quickSelectCrop}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { id: 'chilli', label: '🌶️ Mirchi' },
                    { id: 'cotton', label: '🌾 Cotton' },
                    { id: 'turmeric', label: '🟡 Turmeric' },
                    { id: 'paddy', label: '🌾 Paddy' },
                    { id: 'maize', label: '🌽 Maize' },
                    { id: 'bengal_gram', label: '🟤 Chana' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setSelectedCropId(item.id);
                        const c = ALL_CROPS.find((cr) => cr.id === item.id);
                        if (c) setSelectedUnitId(c.defaultUnit);
                      }}
                      className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-all ${
                        selectedCropId === item.id
                          ? 'bg-sky-600 text-white shadow-xs scale-102'
                          : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* SECTION 2: MANUAL YIELD QUANTITY & INDIAN WEIGHT UNITS DROPDOWN */}
            <div className="bg-gray-50/80 p-3 rounded-xl border border-gray-200 space-y-2.5">
              {/* Unit Dropdown */}
              <div>
                <label htmlFor="kisan-unit-dropdown" className="text-xs font-bold text-gray-800 block mb-1">
                  ⚖️ {t.selectWeightUnit}
                </label>
                <select
                  id="kisan-unit-dropdown"
                  value={selectedUnitId}
                  onChange={(e) => setSelectedUnitId(e.target.value)}
                  className="w-full text-xs font-bold py-2 px-2.5 bg-white border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-sky-500 shadow-2xs"
                >
                  {INDIAN_WEIGHT_UNITS.map((unit) => (
                    <option key={unit.id} value={unit.id}>
                      {unit.name[language]} [{unit.shortCode}]
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-gray-500 mt-0.5">
                  ℹ️ {selectedUnit.description[language]}
                </p>
              </div>

              {/* Yield Quantity Input Field with Tactile Controls */}
              <div>
                <label htmlFor="kisan-yield-input" className="text-xs font-bold text-gray-800 block mb-1">
                  📦 {t.enterYieldQuantity}
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setYieldQuantity((prev) => Math.max(1, Math.round((prev - 1) * 10) / 10))}
                    className="w-10 h-10 rounded-lg bg-white border border-gray-300 flex items-center justify-center font-black text-lg text-gray-700 hover:bg-gray-100 active:scale-95 shadow-2xs shrink-0"
                    title="Decrease Yield"
                  >
                    <Minus className="w-4 h-4" />
                  </button>

                  <div className="relative flex-1">
                    <input
                      id="kisan-yield-input"
                      type="number"
                      min="0.1"
                      step="any"
                      value={yieldQuantity === 0 ? '' : yieldQuantity}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        setYieldQuantity(isNaN(val) ? 0 : Math.max(0, val));
                      }}
                      placeholder="e.g. 10"
                      className="w-full py-2 px-3 text-center text-xl font-black bg-white border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-sky-500"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => setYieldQuantity((prev) => Math.round((prev + 1) * 10) / 10)}
                    className="w-10 h-10 rounded-lg bg-white border border-gray-300 flex items-center justify-center font-black text-lg text-gray-700 hover:bg-gray-100 active:scale-95 shadow-2xs shrink-0"
                    title="Increase Yield"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                {/* Quick Add Increment Pills */}
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span className="text-[10px] font-bold text-gray-400">Add:</span>
                  {[1, 5, 10, 25].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setYieldQuantity((prev) => (prev || 0) + amt)}
                      className="px-2 py-0.5 rounded-md bg-white border border-gray-200 text-[10px] font-bold text-gray-600 hover:bg-gray-100 active:scale-95"
                    >
                      +{amt} {selectedUnit.shortCode}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setYieldQuantity(10)}
                    className="ml-auto text-[10px] font-bold text-gray-400 hover:text-gray-700 underline"
                  >
                    Reset (10)
                  </button>
                </div>
              </div>

              {/* Live Weight & Payout Metric Banner */}
              <div className="bg-sky-100/80 border border-sky-200 rounded-lg p-2.5 flex items-center justify-between">
                <div>
                  <div className="text-[10px] uppercase font-bold text-sky-800 tracking-wider">
                    {t.totalCalculatedWeight}
                  </div>
                  <div className="text-sm font-black text-sky-950">
                    {totalWeightKg.toLocaleString('en-IN')} kg{' '}
                    <span className="text-xs font-semibold text-sky-700">
                      ({totalWeightQtl} Qtl)
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-sky-800 tracking-wider">
                    {t.estimatedPayout}
                  </div>
                  <div className="text-sm font-black text-emerald-700">
                    ₹{estimatedTotalPayout}
                  </div>
                </div>
              </div>
            </div>

            {/* Village Selector */}
            <div>
              <label htmlFor="kisan-village-select" className="text-xs font-bold text-gray-700 block mb-1">
                📍 {t.selectVillage}
              </label>
              <select
                id="kisan-village-select"
                value={selectedVillage}
                onChange={(e) => setSelectedVillage(e.target.value)}
                className="w-full text-xs font-bold py-2 px-3 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-sky-500"
              >
                {villages.map((v) => (
                  <option key={v} value={v}>
                    📍 {v}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 1-Click Large Button */}
          <div className="mt-4">
            {bookingSuccess ? (
              <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-xl text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-bounce">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{t.bookingSuccess}</span>
              </div>
            ) : (
              <button
                id="kisan-book-pickup-submit-btn"
                type="button"
                onClick={handleBookPickup}
                className="w-full py-3 px-4 rounded-xl font-black text-sm bg-sky-600 hover:bg-sky-700 text-white flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-98"
              >
                <Truck className="w-5 h-5" />
                <span>{t.bookPickupBtn}</span>
              </button>
            )}
          </div>
        </div>

        {/* CARD 3: WHERE IS MY MONEY? (LIVE ZERO-CASH DBT STATUS) */}
        <div className="bg-white rounded-2xl p-6 border-2 border-purple-500 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                {t.myMoneyTitle}
              </div>
              <span className="p-1 bg-purple-100 text-purple-700 rounded-md">
                <Landmark className="w-4 h-4" />
              </span>
            </div>
            <p className="text-xs text-gray-600 mb-3">{t.myMoneySubtitle}</p>

            {/* Big Green Credit Card Box */}
            <div className="bg-gradient-to-br from-emerald-900 to-teal-950 text-white p-4 rounded-xl shadow-xs space-y-2 mb-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] uppercase tracking-wider text-emerald-300 font-bold">
                  {t.dbtTransferDone}
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>

              <div className="text-3xl font-black text-white">
                ₹{latestContract ? latestContract.total_cleared_value.toLocaleString('en-IN') : '91,560'}
              </div>

              <div className="text-xs text-emerald-100 font-medium">
                {t.depositedTo}
                <br />
                <span className="text-white font-bold">{t.accountEnding}</span>
              </div>

              <div className="text-[10px] font-mono text-emerald-300/80 pt-1 border-t border-white/10">
                {t.utrNumber}
              </div>
            </div>

            <div className="text-xs text-purple-900 bg-purple-50 p-2.5 rounded-lg border border-purple-200 font-medium mb-4">
              🛡️ {t.zeroCashNotice}
            </div>
          </div>

          {/* Listen to Payment Receipt Audio */}
          <button
            onClick={() => handleListen('payment', paymentSpeechText)}
            className={`w-full py-3 px-4 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all shadow-xs ${
              speakingSection === 'payment'
                ? 'bg-amber-500 text-emerald-950 animate-pulse'
                : 'bg-purple-700 hover:bg-purple-800 text-white'
            }`}
          >
            {speakingSection === 'payment' ? (
              <>
                <VolumeX className="w-5 h-5" />
                <span>{t.stopAudio}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-5 h-5" />
                <span>🔊 {t.listenAudio}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* VISUAL PRODUCE JOURNEY TRACKER (SWIGGY-STYLE TIMELINE) */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-6 pb-3 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-emerald-100 text-emerald-800 rounded-lg">
              <Clock className="w-4 h-4" />
            </span>
            <h3 className="text-base font-bold text-gray-900">{t.produceTrackerTitle}</h3>
          </div>
          <span className="text-xs font-bold px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full">
            Active Batch #AP-2026-402
          </span>
        </div>

        {/* 4-Stage Visual Progress Steps */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative">
          {/* Step 1 */}
          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-300 relative">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                ✓
              </span>
              <span className="text-xs font-black text-emerald-900">{t.step1}</span>
            </div>
            <p className="text-xs text-gray-600">{t.step1Sub}</p>
            <div className="text-[10px] text-gray-400 font-mono mt-2">08:30 AM • Completed</div>
          </div>

          {/* Step 2 */}
          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-300 relative">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                ✓
              </span>
              <span className="text-xs font-black text-emerald-900">{t.step2}</span>
            </div>
            <p className="text-xs text-gray-600">{t.step2Sub}</p>
            <div className="text-[10px] text-gray-400 font-mono mt-2">10:15 AM • Picked Up</div>
          </div>

          {/* Step 3 */}
          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-300 relative">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                ✓
              </span>
              <span className="text-xs font-black text-emerald-900">{t.step3}</span>
            </div>
            <p className="text-xs text-gray-600">{t.step3Sub}</p>
            <div className="text-[10px] text-gray-400 font-mono mt-2">11:40 AM • Gate Verified</div>
          </div>

          {/* Step 4: Final DBT */}
          <div className="p-4 bg-emerald-600 text-white rounded-xl shadow-xs border border-emerald-700 relative">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-6 h-6 rounded-full bg-white text-emerald-800 flex items-center justify-center text-xs font-black">
                ✓
              </span>
              <span className="text-xs font-black">{t.step4}</span>
            </div>
            <p className="text-xs text-emerald-100">{t.step4Sub}</p>
            <div className="text-[10px] text-emerald-200 font-mono mt-2">12:05 PM • NPCI Confirmed</div>
          </div>
        </div>
      </div>
    </div>
  );
};
