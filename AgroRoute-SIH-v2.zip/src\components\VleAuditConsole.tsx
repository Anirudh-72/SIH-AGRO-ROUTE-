import React, { useState } from 'react';
import { MatchedContract } from '../types';
import { generateSmsPayload, generateVleLedger } from '../data/mockData';
import { ShieldAlert, Smartphone, QrCode, Check, Copy, ArrowRight, Lock, Landmark } from 'lucide-react';

interface VleAuditConsoleProps {
  matchedContracts: MatchedContract[];
}

export const VleAuditConsole: React.FC<VleAuditConsoleProps> = ({ matchedContracts }) => {
  const [selectedContractId, setSelectedContractId] = useState<string>(
    matchedContracts[0]?.contract_id || ''
  );
  const [copiedLang, setCopiedLang] = useState<'en' | 'te' | null>(null);

  const selectedContract =
    matchedContracts.find((c) => c.contract_id === selectedContractId) || matchedContracts[0];

  const smsData = selectedContract ? generateSmsPayload(selectedContract) : null;
  const ledgerRows = generateVleLedger(matchedContracts);

  const totalVleCommissions = ledgerRows.reduce((acc, row) => acc + row.vle_fee, 0);

  const handleCopy = (text: string, lang: 'en' | 'te') => {
    navigator.clipboard.writeText(text);
    setCopiedLang(lang);
    setTimeout(() => setCopiedLang(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-gray-900 text-white rounded-xl p-6 shadow-md border border-emerald-700/40">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1 bg-emerald-500/20 text-emerald-300 rounded-md border border-emerald-500/40">
                <Lock className="w-4 h-4" />
              </span>
              <h3 className="text-lg font-bold">VLE Anti-Corruption Execution & Zero-Cash Shield</h3>
              <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/30 text-emerald-200 border border-emerald-400/40">
                SIH26033 Auditable Escrow
              </span>
            </div>
            <p className="text-xs text-emerald-100/80 max-w-2xl leading-relaxed">
              Eliminating predatory weighbridge tampering and cash under-invoicing. Farmers receive direct Aadhaar-linked
              DBT transfers, while Village Level Entrepreneurs (VLEs) are remunerated automatically via digital UPI NPCI micro-settlements.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xs px-4 py-3 rounded-lg border border-white/10 text-right">
            <div className="text-[11px] uppercase tracking-wider text-emerald-200 font-semibold">
              Zero-Cash Settlement Volume
            </div>
            <div className="text-xl font-black text-white">
              ₹{matchedContracts.reduce((a, b) => a + b.total_cleared_value, 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-emerald-300">100% Non-Custodial Escrow</div>
          </div>
        </div>
      </div>

      {/* Contract Selector */}
      {matchedContracts.length > 0 && (
        <div className="flex items-center gap-3 bg-white p-3 rounded-lg border border-gray-200 shadow-xs">
          <span className="text-xs font-bold text-gray-700 whitespace-nowrap">
            Audit Selected Contract:
          </span>
          <select
            value={selectedContractId}
            onChange={(e) => setSelectedContractId(e.target.value)}
            className="text-xs font-semibold py-1.5 px-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500 bg-gray-50 text-gray-900"
          >
            {matchedContracts.map((c) => (
              <option key={c.contract_id} value={c.contract_id}>
                {c.contract_id} — {c.farmer_name} ({c.village}) • {c.weight_kg}kg {c.commodity} • ₹{c.total_cleared_value.toLocaleString('en-IN')}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* SMS Receipts: Dual English & Telugu Mockups */}
      {smsData && selectedContract && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* English SMS Receipt */}
          <div className="bg-[#18212F] text-gray-100 rounded-2xl p-5 border-l-4 border-emerald-500 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-gray-800 mb-4">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-mono font-bold tracking-wider text-gray-400 uppercase">
                    BSNL-GOVT NPCI GATEWAY (SMS)
                  </span>
                </div>
                <button
                  onClick={() => handleCopy(smsData.smsEn, 'en')}
                  className="px-2.5 py-1 text-[11px] rounded bg-gray-800 hover:bg-gray-700 text-gray-300 flex items-center gap-1 transition-colors"
                >
                  {copiedLang === 'en' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedLang === 'en' ? 'Copied' : 'Copy SMS'}
                </button>
              </div>

              <div className="bg-[#111827] p-4 rounded-xl font-mono text-xs text-emerald-200 leading-relaxed space-y-2 border border-gray-800">
                <p className="text-gray-400 font-bold">[KRISHI-SETU GOVT NPCI ESCROW]</p>
                <p>
                  Dear <span className="text-white font-bold">{selectedContract.farmer_name}</span>,
                </p>
                <p>
                  Your <strong className="text-emerald-300">{selectedContract.commodity}</strong> weighment of{' '}
                  <strong className="text-white">{selectedContract.weight_kg} KG</strong> is verified at{' '}
                  <strong className="text-white">{selectedContract.village} Gate</strong>.
                </p>
                <p>
                  Clearing Rate: <strong className="text-sky-300">Rs.{selectedContract.clearing_price_qtl}/Qtl</strong>{' '}
                  (Auction #{selectedContract.contract_id}).
                </p>
                <p className="text-amber-300 font-semibold">
                  Total Credit: Rs.{selectedContract.total_cleared_value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}{' '}
                  initiated directly to your Aadhaar-seeded Bank A/C via Direct Benefit Transfer.
                </p>
                <p className="text-gray-400 text-[11px]">
                  VLE Ref: <span className="text-gray-300">{selectedContract.vle_id}</span> | Zero-Cash Protocol.
                </p>
              </div>
            </div>

            {/* Cryptographic Hash Verification Stamp */}
            <div className="mt-4 pt-3 border-t border-gray-800/80 flex items-center justify-between text-[11px] font-mono">
              <div className="space-y-0.5">
                <span className="text-gray-500 uppercase text-[10px] font-semibold">
                  SHA-256 Tamper-Proof Audit Digest:
                </span>
                <div className="text-emerald-400 break-all">{smsData.txHash}</div>
              </div>
              <div className="p-1.5 bg-white rounded-md shrink-0 ml-3">
                {/* Simulated QR Code SVG */}
                <svg width="40" height="40" viewBox="0 0 24 24" fill="#1F2937">
                  <path d="M2 2h8v8H2V2zm2 2v4h4V4H4zm10-2h8v8h-8V2zm2 2v4h4V4h-4zM2 14h8v8H2v-8zm2 2v4h4v-4H4zm14 0h4v4h-4v-4zm-4 4h4v4h-4v-4zm0-4h4v-4h-4v4z" />
                </svg>
              </div>
            </div>
          </div>

          {/* Telugu SMS Receipt (Vernacular Smallholder Accessibility) */}
          <div className="bg-[#18212F] text-gray-100 rounded-2xl p-5 border-l-4 border-sky-500 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-gray-800 mb-4">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-mono font-bold tracking-wider text-gray-400 uppercase">
                    ఆంధ్రప్రదేశ్ రైతు డిజిటల్ రశీదు (TELUGU)
                  </span>
                </div>
                <button
                  onClick={() => handleCopy(smsData.smsTe, 'te')}
                  className="px-2.5 py-1 text-[11px] rounded bg-gray-800 hover:bg-gray-700 text-gray-300 flex items-center gap-1 transition-colors"
                >
                  {copiedLang === 'te' ? <Check className="w-3 h-3 text-sky-400" /> : <Copy className="w-3 h-3" />}
                  {copiedLang === 'te' ? 'Copied' : 'Copy Telugu'}
                </button>
              </div>

              <div className="bg-[#111827] p-4 rounded-xl font-mono text-xs text-sky-200 leading-relaxed space-y-2 border border-gray-800">
                <p className="text-gray-400 font-bold">[కృషి-సేతు నేషనల్ అగ్రికల్చరల్ ఎస్క్రో]</p>
                <p>
                  గౌరవనీయులైన <span className="text-white font-bold">{selectedContract.farmer_name}</span> గారికి,
                </p>
                <p>
                  మీ <strong className="text-white">{selectedContract.village}</strong> కేంద్రం వద్ద{' '}
                  <strong className="text-emerald-300">{selectedContract.commodity}</strong> తూకం{' '}
                  <strong className="text-white">{selectedContract.weight_kg} కేజీలు</strong> ధృవీకరించబడింది.
                </p>
                <p>
                  ధర: క్వింటాల్ కు <strong className="text-sky-300">రూ. {selectedContract.clearing_price_qtl}</strong> (వేలం #{selectedContract.contract_id}).
                </p>
                <p className="text-amber-300 font-semibold">
                  మొత్తం చెల్లింపు: రూ. {selectedContract.total_cleared_value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}{' '}
                  నేరుగా మీ ఆధార్ లింక్డ్ బ్యాంక్ ఖాతాకు జమచేయబడుతుంది.
                </p>
                <p className="text-gray-400 text-[11px]">
                  క్యాష్ రహిత డిజిటల్ రశీదు కోడ్: <span className="text-gray-300">{smsData.txHash.substring(0, 18)}...</span>
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-gray-800/80 flex items-center justify-between text-[11px] font-mono">
              <div className="space-y-0.5">
                <span className="text-gray-500 uppercase text-[10px] font-semibold">
                  డిజిటల్ రక్షణ స్టాంప్:
                </span>
                <div className="text-sky-400 break-all">{smsData.txHash}</div>
              </div>
              <div className="p-1.5 bg-white rounded-md shrink-0 ml-3">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="#1F2937">
                  <path d="M2 2h8v8H2V2zm2 2v4h4V4H4zm10-2h8v8h-8V2zm2 2v4h4V4h-4zM2 14h8v8H2v-8zm2 2v4h4v-4H4zm14 0h4v4h-4v-4zm-4 4h4v4h-4v-4zm0-4h4v-4h-4v4z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Automated VLE UPI Commission Ledger Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex flex-wrap items-center justify-between gap-4 bg-gray-50/70">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-sky-100 text-sky-700 rounded-md">
              <Landmark className="w-4 h-4" />
            </span>
            <div>
              <h4 className="text-sm font-bold text-gray-900">
                Automated VLE UPI Commission Ledger (Zero Cash Settlement)
              </h4>
              <p className="text-xs text-gray-500">
                Fixed 0.75% procurement fee credited via NPCI UPI Rails directly to Village Entrepreneur accounts.
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-gray-500 mr-2">Disbursed VLE Commissions:</span>
            <span className="text-sm font-bold text-emerald-700">
              ₹{totalVleCommissions.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-gray-600">
            <thead className="text-[11px] font-bold text-gray-500 uppercase bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="py-2.5 px-3">Transaction Ref</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">VLE Operator</th>
                <th className="py-2.5 px-3">Farmer & Village</th>
                <th className="py-2.5 px-3 text-right">Net Cleared Value</th>
                <th className="py-2.5 px-3 text-right">0.75% Fee (₹)</th>
                <th className="py-2.5 px-3">Target VLE UPI ID</th>
                <th className="py-2.5 px-3">NPCI Bank UTR</th>
                <th className="py-2.5 px-3 text-center">Settlement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 font-mono">
              {ledgerRows.map((row) => (
                <tr key={row.txn_ref} className="hover:bg-gray-50/80 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-emerald-700">{row.txn_ref}</td>
                  <td className="py-2.5 px-3 text-gray-500 text-[11px] font-sans">{row.timestamp}</td>
                  <td className="py-2.5 px-3 font-sans font-semibold text-gray-900">{row.vle_id}</td>
                  <td className="py-2.5 px-3 font-sans">
                    <span className="font-semibold text-gray-900">{row.farmer_name}</span>{' '}
                    <span className="text-gray-500 text-[11px]">({row.village})</span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-sans font-bold text-gray-900">
                    ₹{row.net_cleared.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-emerald-700">
                    ₹{row.vle_fee.toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3 text-sky-700 font-semibold">{row.target_upi}</td>
                  <td className="py-2.5 px-3 text-gray-500 text-[11px]">{row.npci_utr}</td>
                  <td className="py-2.5 px-3 text-center font-sans">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      PAID_UPI
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
