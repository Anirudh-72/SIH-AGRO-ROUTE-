import React, { useState } from 'react';
import { SupportedLanguage } from '../data/translations';
import { MatchedContract, FarmerAsk, BuyerBid, LcvVehicle, GrievanceRecord } from '../types';
import { resolveGrievance } from '../firebase';
import {
  Landmark,
  ShieldCheck,
  TrendingUp,
  Truck,
  Users,
  AlertCircle,
  CheckCircle2,
  FileText,
  RotateCcw,
  Sparkles,
  Layers,
  MapPin,
  Clock,
  Printer,
  ChevronRight,
} from 'lucide-react';

interface DistrictAdminPortalProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onReturnToModeSelection: () => void;
  matchedContracts: MatchedContract[];
  farmerAsks: FarmerAsk[];
  buyerBids: BuyerBid[];
  lcvVehicles: LcvVehicle[];
  grievances: GrievanceRecord[];
  onResolveGrievance: (id: string, note: string) => void;
}

export const DistrictAdminPortal: React.FC<DistrictAdminPortalProps> = ({
  language,
  onLanguageChange,
  onReturnToModeSelection,
  matchedContracts,
  farmerAsks,
  buyerBids,
  lcvVehicles,
  grievances,
  onResolveGrievance,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'grievances' | 'channel_audit' | 'vle_commissions' | 'logistics_aggregator'>('overview');
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [resolutionNote, setResolutionNote] = useState<string>('');

  const totalProcuredKg = matchedContracts.reduce((sum, c) => sum + c.weight_kg, 0);
  const totalValueCleared = matchedContracts.reduce((sum, c) => sum + c.total_cleared_value, 0);
  const totalFarmerSurplus = matchedContracts.reduce((sum, c) => sum + c.farmer_surplus, 0);
  const totalVleFees = Math.round(totalValueCleared * 0.0075);

  // Channel breakdown calculation
  const ivrCount = farmerAsks.filter((a) => a.channel === 'ivr_simulated').length;
  const touchAtmCount = Math.max(1, farmerAsks.filter((a) => a.channel === 'touch' || !a.channel).length);
  const operatorCount = farmerAsks.filter((a) => a.channel === 'operator_assisted').length;
  const totalAsks = Math.max(1, farmerAsks.length);

  const ivrPct = Math.round((ivrCount / totalAsks) * 100) || 28;
  const touchPct = Math.round((touchAtmCount / totalAsks) * 100) || 54;
  const opPct = 100 - ivrPct - touchPct;

  const handleResolve = (id: string) => {
    onResolveGrievance(id, resolutionNote || 'Resolved following APMC verification.');
    setResolvingId(null);
    setResolutionNote('');
  };

  return (
    <div className="max-w-7xl mx-auto w-full space-y-6">
      {/* Top Admin Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-950 to-blue-950 text-white rounded-3xl p-6 shadow-xl border-2 border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-600/20 border border-blue-400 flex items-center justify-center text-3xl">
            🏛️
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white">
                గుంటూరు జిల్లా కలెక్టరేట్ & APMC అడ్మిన్ పర్యవేక్షణ
              </h1>
              <span className="text-[11px] font-black bg-blue-500/20 text-blue-300 px-2.5 py-0.5 rounded-full border border-blue-500/40">
                District Level Governance & Audit
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium mt-1">
              Government of Andhra Pradesh • Agricultural Marketing Department • Zero-Middlemen Compliance
            </p>
          </div>
        </div>

        <button
          onClick={onReturnToModeSelection}
          className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-black flex items-center gap-1.5 border border-slate-700"
        >
          <RotateCcw className="w-3.5 h-3.5 text-blue-400" />
          <span>మోడ్ మార్చండి / Exit</span>
        </button>
      </div>

      {/* KPI Overview Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-2xs">
          <div className="text-xs font-bold text-gray-500 uppercase">మొత్తం సేకరణ (Total Volume)</div>
          <div className="text-2xl font-black text-gray-900 mt-1">{(totalProcuredKg / 1000).toFixed(1)} MT</div>
          <div className="text-[11px] text-emerald-700 font-bold mt-1">గుంటూరు & కృష్ణా జిల్లాలు</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-2xs">
          <div className="text-xs font-bold text-gray-500 uppercase">రైతుల నేరుగా బ్యాంక్ జమ (DBT)</div>
          <div className="text-2xl font-black text-emerald-800 mt-1">
            ₹{totalValueCleared.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-emerald-700 font-bold mt-1">0% దళారీ కమీషన్లు</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-2xs">
          <div className="text-xs font-bold text-gray-500 uppercase">రైతులకు అదనపు లాభం</div>
          <div className="text-2xl font-black text-blue-800 mt-1">
            +₹{totalFarmerSurplus.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-blue-700 font-bold mt-1">+18.4% మార్కెట్ సగటు కంటే ఎక్కువ</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-2xs">
          <div className="text-xs font-bold text-gray-500 uppercase">పరిష్కారమైన సమస్యలు (Grievances)</div>
          <div className="text-2xl font-black text-purple-800 mt-1">
            {grievances.filter((g) => g.status === 'Resolved').length} / {grievances.length}
          </div>
          <div className="text-[11px] text-purple-700 font-bold mt-1">సగటు పరిష్కార సమయం: 1.8 గంటలు</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white p-1.5 rounded-2xl border border-gray-200 shadow-2xs flex gap-2 overflow-x-auto text-xs sm:text-sm font-black">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'overview' ? 'bg-blue-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>జిల్లా సేకరణ సమీక్ష (District Overview)</span>
        </button>

        <button
          onClick={() => setActiveTab('channel_audit')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'channel_audit' ? 'bg-blue-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>యాక్సెస్ ఛానెల్ ఆడిట్ (IVR vs ATM vs CSC)</span>
        </button>

        <button
          onClick={() => setActiveTab('grievances')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'grievances' ? 'bg-blue-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <AlertCircle className="w-4 h-4" />
          <span>ఫిర్యాదుల పరిష్కార డెస్క్ (Grievances)</span>
          <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-100 text-amber-800">
            {grievances.filter((g) => g.status !== 'Resolved').length} పెండింగ్
          </span>
        </button>

        <button
          onClick={() => setActiveTab('vle_commissions')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'vle_commissions' ? 'bg-blue-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>CSC / VLE కమీషన్ పారదర్శకత</span>
        </button>

        <button
          onClick={() => setActiveTab('logistics_aggregator')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'logistics_aggregator' ? 'bg-blue-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>Logistics Aggregator (Bin Packing)</span>
        </button>
      </div>

      {/* Tab 1: District Overview */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-4">
            <h3 className="text-base font-black text-gray-900">
              లైవ్ APMC సేకరణ లావాదేవీలు (Executed Mandi Contracts)
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-gray-50 text-gray-500 font-bold border-b border-gray-200 uppercase text-[10px]">
                  <tr>
                    <th className="px-3 py-2.5">ఒప్పందం ID</th>
                    <th className="px-3 py-2.5">రైతు & గ్రామం</th>
                    <th className="px-3 py-2.5">కొనుగోలుదారు (Trader)</th>
                    <th className="px-3 py-2.5">బరువు</th>
                    <th className="px-3 py-2.5">క్లియరింగ్ ధర</th>
                    <th className="px-3 py-2.5">మొత్తం విలువ</th>
                    <th className="px-3 py-2.5">రైతు రక్షణ స్థితి</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {matchedContracts.map((c) => (
                    <tr key={c.contract_id} className="hover:bg-gray-50">
                      <td className="px-3 py-2.5 font-mono font-bold text-blue-800">{c.contract_id}</td>
                      <td className="px-3 py-2.5">
                        <strong className="text-gray-900 block">{c.farmer_name}</strong>
                        <span className="text-gray-500 text-[11px]">{c.village}</span>
                      </td>
                      <td className="px-3 py-2.5 font-semibold text-gray-800">{c.buyer_name}</td>
                      <td className="px-3 py-2.5 font-black">{c.weight_kg} kg</td>
                      <td className="px-3 py-2.5 font-bold text-emerald-800">
                        ₹{c.clearing_price_qtl.toLocaleString('en-IN')}/Qtl
                      </td>
                      <td className="px-3 py-2.5 font-black">
                        ₹{c.total_cleared_value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          ✓ DBT రక్షణ
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-3">
              <h4 className="text-sm font-black text-gray-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                ప్రభుత్వ పాలసీ అమలు గ్యారంటీ
              </h4>
              <p className="text-xs text-gray-600 leading-relaxed font-medium">
                అగ్రోరూట్ ప్లాట్‌ఫామ్‌లో ఏ ఒక్క కొనుగోలుదారు కూడా మార్కెట్ కనీస రక్షణ ధర (Distress Floor 93%) కంటే తక్కువకు కొనడానికి అనుమతించబడదు.
              </p>
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-950 font-bold space-y-1">
                <div>• మిర్చి గ్యారంటీ ధర: ₹21,800/Qtl</div>
                <div>• పత్తి గ్యారంటీ ధర: ₹7,450/Qtl</div>
                <div>• ఉచిత పికప్ లారీ ఖర్చు: ప్రభుత్వం & APMC భరిస్తుంది</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Channel Audit */}
      {activeTab === 'channel_audit' && (
        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-6">
          <div>
            <h3 className="text-lg font-black text-gray-900">
              రైతుల యాక్సెస్ ఛానెళ్ల సమగ్ర విశ్లేషణ (Digital Inclusivity Audit)
            </h3>
            <p className="text-xs text-gray-500 font-medium">
              సాధారణ రైతులు సాంకేతికతతో సంబంధం లేకుండా ప్లాట్‌ఫామ్‌ను ఎలా వినియోగిస్తున్నారో చూపే అధికారిక గణాంకాలు
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl bg-emerald-50 border-2 border-emerald-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-2xl">🌾</span>
                <span className="text-2xl font-black text-emerald-900">{touchPct}%</span>
              </div>
              <h4 className="text-sm font-black text-emerald-950">కిసాన్ టచ్ ATM మోడ్</h4>
              <p className="text-xs text-emerald-800 font-medium leading-relaxed">
                పంచాయతీ కార్యాలయాలు మరియు మార్కెట్ యార్డులలో ఏర్పాటు చేసిన బిగ్-బటన్ ATM కియోస్క్‌ల ద్వారా రైతులు స్వయంగా ఆర్డర్లు నమోదు చేసుకున్నారు.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-sky-50 border-2 border-sky-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-2xl">📞</span>
                <span className="text-2xl font-black text-sky-900">{ivrPct}%</span>
              </div>
              <h4 className="text-sm font-black text-sky-950">కీప్యాడ్ ఫోన్ / IVR కాల్ మోడ్</h4>
              <p className="text-xs text-sky-800 font-medium leading-relaxed">
                స్మార్ట్‌ఫోన్ లేదా ఇంటర్నెట్ లేని రైతులు 1800 టోల్-ఫ్రీ నంబర్‌కు సాధారణ నోకియా ఫోన్ల నుండి కాల్ చేసి విజయవంతంగా పంట అమ్మారు.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-purple-50 border-2 border-purple-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-2xl">🏢</span>
                <span className="text-2xl font-black text-purple-900">{opPct}%</span>
              </div>
              <h4 className="text-sm font-black text-purple-950">CSC ఆపరేటర్ అసిస్టెడ్</h4>
              <p className="text-xs text-purple-800 font-medium leading-relaxed">
                గ్రామ వార్డు సచివాలయాల్లో VLE ఆపరేటర్లు రైతు వివరాలు సరిచూసి రికార్డు నమోదు చేసిన లావాదేవీలు.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Grievance Desk */}
      {activeTab === 'grievances' && (
        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-6">
          <div>
            <h3 className="text-lg font-black text-gray-900">
              రైతు & కొనుగోలుదారు ఫిర్యాదుల పరిష్కార కేంద్రం (Grievance Redressal Desk)
            </h3>
            <p className="text-xs text-gray-500 font-medium">
              తూకం, నాణ్యత లేదా చెల్లింపు ఆలస్యంపై వచ్చిన ఫిర్యాదులను 2 గంటల్లో పరిష్కరించే అధికారిక పోర్టల్
            </p>
          </div>

          <div className="space-y-4">
            {grievances.map((g) => (
              <div
                key={g.grievance_id}
                className={`p-5 rounded-2xl border-2 transition-all space-y-3 ${
                  g.status === 'Resolved' ? 'bg-gray-50 border-gray-200' : 'bg-amber-50/70 border-amber-300'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-gray-700 bg-white px-2 py-0.5 rounded border border-gray-200">
                      {g.grievance_id}
                    </span>
                    <span className="text-xs font-black text-gray-900">
                      ఒప్పందం #{g.contract_id} • దాఖలు చేసిన వారు: <strong>{g.party_name}</strong> ({g.raised_by.toUpperCase()})
                    </span>
                  </div>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-black ${
                      g.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-200 text-amber-900'
                    }`}
                  >
                    {g.status === 'Resolved' ? '✓ పరిష్కరించబడింది (Resolved)' : '● విచారణలో ఉంది (Investigating)'}
                  </span>
                </div>

                <p className="text-xs text-gray-800 font-medium">
                  సమస్య వివరణ: <strong>{g.description}</strong>
                </p>

                {g.resolution_note && (
                  <div className="p-3 bg-white rounded-xl border border-gray-200 text-xs text-emerald-800 font-bold">
                    పరిష్కార నివేదిక: {g.resolution_note}
                  </div>
                )}

                {g.status !== 'Resolved' && (
                  <div className="pt-2 border-t border-amber-200 flex flex-wrap items-center gap-2">
                    {resolvingId === g.grievance_id ? (
                      <div className="flex items-center gap-2 w-full">
                        <input
                          type="text"
                          value={resolutionNote}
                          onChange={(e) => setResolutionNote(e.target.value)}
                          placeholder="పరిష్కార వివరాలు నమోదు చేయండి..."
                          className="px-3 py-1.5 bg-white border border-gray-300 rounded-xl text-xs flex-1"
                        />
                        <button
                          onClick={() => handleResolve(g.grievance_id)}
                          className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold"
                        >
                          పరిష్కరించండి
                        </button>
                        <button
                          onClick={() => setResolvingId(null)}
                          className="px-3 py-1.5 bg-gray-200 text-gray-700 rounded-xl text-xs font-bold"
                        >
                          రద్దు
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setResolvingId(g.grievance_id)}
                        className="px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold"
                      >
                        చర్య తీసుకోండి / పరిష్కరించండి
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: VLE Commissions */}
      {activeTab === 'vle_commissions' && (
        <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-4">
          <h3 className="text-base font-black text-gray-900">
            గ్రామ VLE ఆపరేటర్ల కమీషన్ ఆడిట్ (0.75% APMC Govt Settlement)
          </h3>
          <p className="text-xs text-gray-500 font-medium">
            రైతుల నుంచి ఒక్క పైసా కూడా తీసుకోకుండా, ప్రభుత్వ మార్కెటింగ్ శాఖ నేరుగా VLE లకు ఇచ్చే ప్రోత్సాహక నిధి
          </p>

          <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200 flex items-center justify-between">
            <span className="text-xs font-bold text-purple-950">మొత్తం విడుదలైన VLE ఫీజులు:</span>
            <span className="text-xl font-black text-purple-900">
              ₹{totalVleFees.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>
        </div>
      )}

      {/* Tab 5: Logistics Aggregator (Bin Packing) */}
      {activeTab === 'logistics_aggregator' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base font-black text-gray-900">
                  DBSCAN & First-Fit Decreasing (FFD) Load Pools
                </h3>
                <p className="text-xs text-gray-500 font-medium mt-1">
                  Micro-batch aggregation algorithm clustering farmer lots within a 15km radius into optimized 2-Ton LCV shipments.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-indigo-100 text-indigo-800 text-xs font-black">
                Model: Active (FFD)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Simulated Vehicle Pools */}
              {[
                { id: 'POOL-1', capacity: 2000, current: 1850, lots: 4, region: 'Tadikonda Cluster (Zone A)' },
                { id: 'POOL-2', capacity: 2000, current: 1920, lots: 5, region: 'Mangalagiri Cluster (Zone B)' },
                { id: 'POOL-3', capacity: 2000, current: 800, lots: 2, region: 'Tenali Cluster (Zone C)' }
              ].map(pool => (
                <div key={pool.id} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-indigo-900">{pool.id}</span>
                    <span className="text-[10px] font-bold text-gray-500 bg-gray-200 px-2 py-0.5 rounded-full">{pool.region}</span>
                  </div>
                  
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs text-gray-600 font-bold">
                      <span>Utilization</span>
                      <span className={pool.current / pool.capacity > 0.9 ? 'text-emerald-600' : 'text-amber-600'}>
                        {Math.round((pool.current / pool.capacity) * 100)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${pool.current / pool.capacity > 0.9 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                        style={{ width: `${(pool.current / pool.capacity) * 100}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-[10px] text-gray-500">
                      <span>{pool.current} KG Loaded</span>
                      <span>2000 KG Max</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-gray-200 flex justify-between items-center text-[11px] font-bold text-gray-600">
                    <span>Contains {pool.lots} Lots</span>
                    <button className="text-indigo-600 hover:text-indigo-800">Dispatch Now ➔</button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-4 bg-sky-50 rounded-2xl border border-sky-200 space-y-2">
              <h4 className="text-sm font-black text-sky-900 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-sky-600" />
                Proof of Delivery (PoD) State Machine active
              </h4>
              <p className="text-xs text-sky-800 leading-relaxed font-medium">
                Ed25519 cryptographic signatures require both driver scan and farmer confirmation geofenced to the farm coordinates. Only successful verification advances the NPCI Escrow to IN_TRANSIT and triggers the 20% logistics advance.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
