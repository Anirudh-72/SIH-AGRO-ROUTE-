import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  INITIAL_FARMER_ASKS,
  INITIAL_BUYER_BIDS,
  GUNTUR_APMC_LAT,
  GUNTUR_APMC_LON,
  filterAsksByHaversine,
  runContinuousDoubleAuction,
  runGreedyBinPacking,
  generateAgmarknetHistoricalData,
} from './data/mockData';
import { SupportedLanguage, TRANSLATIONS } from './data/translations';
import { FoliumRoutingMap } from './components/FoliumRoutingMap';
import { DoubleAuctionConsole } from './components/DoubleAuctionConsole';
import { VleAuditConsole } from './components/VleAuditConsole';
import { KisanAtmView } from './components/KisanAtmView';
import { ModeSelectionScreen } from './components/ModeSelectionScreen';
import { OperatorPortal } from './components/OperatorPortal';
import { KisanAiAssistantModal } from './components/KisanAiAssistantModal';
import { WhatsAppAssistantDrawer } from './components/WhatsAppAssistantDrawer';
import { BuyerPortal } from './components/BuyerPortal';
import { FeaturePhoneSimulator } from './components/FeaturePhoneSimulator';
import { DistrictAdminPortal } from './components/DistrictAdminPortal';
import { SplashScreen } from './components/SplashScreen';
import { FarmerAsk, BuyerBid, GrievanceRecord } from './types';
import {
  subscribeToFarmerAsks,
  subscribeToBuyerBids,
  subscribeToGrievances,
  saveFarmerAsk,
  saveBuyerBid,
  saveGrievance,
  resolveGrievance,
} from './firebase';
import { Truck } from 'lucide-react';

export default function App() {
  // Portal Mode: 'splash' | 'selection' | 'kisan' | 'operator' | 'buyer' | 'ivr' | 'admin'
  const [portalMode, setPortalMode] = useState<
    'splash' | 'selection' | 'kisan' | 'operator' | 'buyer' | 'ivr' | 'admin'
  >('splash');

  // Active language - strictly enforced app-wide
  const [language, setLanguage] = useState<SupportedLanguage>('en');

  // Modals
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);
  const [isWhatsAppDrawerOpen, setIsWhatsAppDrawerOpen] = useState(false);

  // Logistics engine sub-tab
  const [engineTab, setEngineTab] = useState<'dashboard' | 'auction' | 'logistics' | 'vle'>('dashboard');

  // Commodity filter
  const [commodity, setCommodity] = useState<'Guntur Teja Mirchi' | 'Shankar-6 Cotton'>('Guntur Teja Mirchi');
  const [poolingRadiusKm, setPoolingRadiusKm] = useState<number>(8.0);

  // State for Asks, Bids, and Grievances
  const [farmerAsks, setFarmerAsks] = useState<FarmerAsk[]>(INITIAL_FARMER_ASKS);
  const [buyerBids, setBuyerBids] = useState<BuyerBid[]>(INITIAL_BUYER_BIDS);
  const [grievances, setGrievances] = useState<GrievanceRecord[]>([]);

  // Firebase sync
  useEffect(() => {
    const unsubAsks = subscribeToFarmerAsks((asks) => setFarmerAsks(asks));
    const unsubBids = subscribeToBuyerBids((bids) => setBuyerBids(bids));
    const unsubGrievances = subscribeToGrievances((list) => setGrievances(list));
    return () => { unsubAsks(); unsubBids(); unsubGrievances(); };
  }, []);

  const geofilteredAsks = useMemo(
    () => filterAsksByHaversine(farmerAsks, GUNTUR_APMC_LAT, GUNTUR_APMC_LON, poolingRadiusKm),
    [farmerAsks, poolingRadiusKm]
  );

  const { matched: matchedContracts, remainingAsks, remainingBids } = useMemo(
    () => runContinuousDoubleAuction(geofilteredAsks, buyerBids, commodity),
    [geofilteredAsks, buyerBids, commodity]
  );

  const lcvVehicles = useMemo(() => runGreedyBinPacking(matchedContracts, 2000.0), [matchedContracts]);
  const priceData = useMemo(() => generateAgmarknetHistoricalData(commodity), [commodity]);

  const handleAddAsk = (newAsk: FarmerAsk) => saveFarmerAsk(newAsk);
  const handleAddBid = (newBid: BuyerBid) => saveBuyerBid(newBid);
  const handleRaiseGrievance = (g: GrievanceRecord) => saveGrievance(g);
  const handleResolveGrievance = (id: string, note: string) => resolveGrievance(id, note);

  const t = TRANSLATIONS[language];

  // Logistics engine tab content — operator only, no graph/formula for farmers
  const renderLogisticsEngine = () => (
    <div className="space-y-5">
      {/* Sub-tabs */}
      <div className="flex gap-2 flex-wrap text-xs font-black">
        {(['dashboard', 'auction', 'logistics', 'vle'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setEngineTab(tab)}
            className={`px-3 py-1.5 rounded-lg ${engineTab === tab ? 'bg-sky-700 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
          >
            {tab === 'dashboard' ? (language === 'te' ? 'డ్యాష్‌బోర్డ్' : language === 'hi' ? 'डैशबोर्ड' : 'Dashboard')
              : tab === 'auction' ? (language === 'te' ? 'ఆర్డర్ బుక్' : language === 'hi' ? 'ऑर्डर बुक' : 'Order Book')
              : tab === 'logistics' ? (language === 'te' ? 'రూటింగ్ మ్యాప్' : language === 'hi' ? 'रूटिंग मैप' : 'Routing Map')
              : (language === 'te' ? 'VLE ఆడిట్' : language === 'hi' ? 'VLE ऑडिट' : 'VLE Audit')}
          </button>
        ))}
      </div>

      {engineTab === 'dashboard' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: language === 'te' ? 'మ్యాచ్ కాంట్రాక్ట్లు' : language === 'hi' ? 'मैच कॉन्ट्रैक्ट' : 'Matched Contracts', value: matchedContracts.length, color: 'emerald' },
            { label: language === 'te' ? 'వాహనాలు' : language === 'hi' ? 'वाहन' : 'Vehicles', value: lcvVehicles.length, color: 'sky' },
            { label: language === 'te' ? 'క్లియర్ బరువు (kg)' : language === 'hi' ? 'क्लियर वजन' : 'Cleared Weight (kg)', value: matchedContracts.reduce((s, c) => s + c.weight_kg, 0).toLocaleString('en-IN'), color: 'indigo' },
            { label: language === 'te' ? 'మొత్తం విలువ' : language === 'hi' ? 'कुल मूल्य' : 'Total Value', value: `₹${matchedContracts.reduce((s, c) => s + c.total_cleared_value, 0).toLocaleString('en-IN')}`, color: 'teal' },
          ].map((m) => (
            <div key={m.label} className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
              <div className="text-xs font-bold text-gray-500 uppercase mb-1">{m.label}</div>
              <div className="text-xl font-black text-gray-900">{m.value}</div>
            </div>
          ))}
        </div>
      )}

      {engineTab === 'auction' && (
        <DoubleAuctionConsole
          matchedContracts={matchedContracts}
          asks={geofilteredAsks}
          bids={buyerBids}
          commodity={commodity}
          onAddAsk={handleAddAsk}
          onAddBid={handleAddBid}
        />
      )}

      {engineTab === 'logistics' && (
        <FoliumRoutingMap lcvVehicles={lcvVehicles} poolingRadiusKm={poolingRadiusKm} allAsks={matchedContracts} />
      )}

      {engineTab === 'vle' && (
        <VleAuditConsole matchedContracts={matchedContracts} />
      )}
    </div>
  );

  // =========================================================================
  // SPLASH SCREEN
  // =========================================================================
  if (portalMode === 'splash') {
    return <SplashScreen onComplete={() => setPortalMode('selection')} />;
  }

  // =========================================================================
  // MODE SELECTION
  // =========================================================================
  if (portalMode === 'selection') {
    return (
      <ModeSelectionScreen
        language={language}
        onLanguageChange={setLanguage}
        onSelectKisanMode={() => setPortalMode('kisan')}
        onSelectOperatorMode={() => setPortalMode('operator')}
        onSelectBuyerMode={() => setPortalMode('buyer')}
        onSelectIvrMode={() => setPortalMode('ivr')}
        onSelectAdminMode={() => setPortalMode('admin')}
      />
    );
  }

  // =========================================================================
  // KISAN MODE
  // =========================================================================
  if (portalMode === 'kisan') {
    return (
      <div className="min-h-screen bg-[#F6F8F7] p-3 sm:p-6 flex flex-col justify-between">
        <KisanAtmView
          language={language}
          onLanguageChange={setLanguage}
          latestContract={matchedContracts[0]}
          onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
          onSwitchToOperator={() => setPortalMode('operator')}
          onReturnToModeSelection={() => setPortalMode('selection')}
          onOrderCreated={(order) => {
            handleAddAsk({
              farmer_id: `F-AP-${Math.floor(200 + Math.random() * 800)}`,
              name: order.farmerName,
              village: order.village,
              commodity,
              weight_kg: order.netWeightKg,
              ask_price_per_qtl: order.ratePerQtl,
              lat: 16.4258,
              lon: 80.4619,
              vle_id: 'VLE-GNT-01',
              contact: order.phone,
              channel: 'touch',
              created_at: new Date().toISOString(),
            });
          }}
        />
        <KisanAiAssistantModal
          isOpen={isAiAssistantOpen}
          onClose={() => setIsAiAssistantOpen(false)}
          language={language}
          onLanguageChange={setLanguage}
          commodity={commodity}
        />
        <WhatsAppAssistantDrawer
          isOpen={isWhatsAppDrawerOpen}
          onClose={() => setIsWhatsAppDrawerOpen(false)}
          language={language}
        />
      </div>
    );
  }

  // =========================================================================
  // BUYER MODE
  // =========================================================================
  if (portalMode === 'buyer') {
    return (
      <div className="min-h-screen bg-[#F8FAFC]">
        <BuyerPortal
          language={language}
          onLanguageChange={setLanguage}
          onReturnToModeSelection={() => setPortalMode('selection')}
          farmerAsks={farmerAsks}
          buyerBids={buyerBids}
          matchedContracts={matchedContracts}
          lcvVehicles={lcvVehicles}
          priceData={priceData}
          commodity={commodity}
          onCommodityChange={setCommodity}
          onAddBid={handleAddBid}
          onRaiseGrievance={handleRaiseGrievance}
        />
      </div>
    );
  }

  // =========================================================================
  // IVR / FEATURE PHONE
  // =========================================================================
  if (portalMode === 'ivr') {
    return (
      <div className="min-h-screen bg-slate-950">
        <FeaturePhoneSimulator
          language={language}
          onLanguageChange={setLanguage}
          onReturnToModeSelection={() => setPortalMode('selection')}
          onAddFarmerAsk={handleAddAsk}
        />
      </div>
    );
  }

  // =========================================================================
  // ADMIN MODE
  // =========================================================================
  if (portalMode === 'admin') {
    return (
      <div className="min-h-screen bg-[#F8FAFC]">
        <DistrictAdminPortal
          language={language}
          onLanguageChange={setLanguage}
          onReturnToModeSelection={() => setPortalMode('selection')}
          matchedContracts={matchedContracts}
          farmerAsks={farmerAsks}
          buyerBids={buyerBids}
          lcvVehicles={lcvVehicles}
          grievances={grievances}
          onResolveGrievance={handleResolveGrievance}
        />
      </div>
    );
  }

  // =========================================================================
  // OPERATOR MODE
  // =========================================================================
  return (
    <div className="min-h-screen bg-[#F8FAFC] p-3 sm:p-6 flex flex-col justify-between">
      <OperatorPortal
        language={language}
        onLanguageChange={setLanguage}
        onReturnToModeSelection={() => setPortalMode('selection')}
        onSwitchToKisanMode={() => setPortalMode('kisan')}
        renderEngineTab={renderLogisticsEngine}
      />
      <KisanAiAssistantModal
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
        language={language}
        onLanguageChange={setLanguage}
        commodity={commodity}
      />
      <WhatsAppAssistantDrawer
        isOpen={isWhatsAppDrawerOpen}
        onClose={() => setIsWhatsAppDrawerOpen(false)}
        language={language}
      />
    </div>
  );
}
