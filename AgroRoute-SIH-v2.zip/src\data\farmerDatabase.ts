// Farmer Profile Database — in-memory + localStorage persistence

export interface FarmerRegistrationRecord {
  aadhaarFull: string;         // 12-digit Aadhaar
  aadhaarLast4: string;        // last 4 digits for display
  name: string;
  phone: string;
  village: string;
  bankName: string;
  accountLast4: string;
  preferredLanguage: 'te' | 'hi' | 'en';
  registeredAt: string;        // ISO timestamp
  registeredByVleId: string;
}

const STORAGE_KEY = 'agroroute_farmer_db';

function loadFromStorage(): FarmerRegistrationRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as FarmerRegistrationRecord[];
  } catch {
    // ignore
  }
  return [];
}

function saveToStorage(records: FarmerRegistrationRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch {
    // ignore
  }
}

// Seed data — pre-registered farmers for demo
const SEED_FARMERS: FarmerRegistrationRecord[] = [
  {
    aadhaarFull: '987600004012',
    aadhaarLast4: '4012',
    name: 'K. Venkateswara Rao',
    phone: '98480 12345',
    village: 'Tadikonda',
    bankName: 'State Bank of India (SBI)',
    accountLast4: '4012',
    preferredLanguage: 'te',
    registeredAt: '2026-08-01T09:00:00.000Z',
    registeredByVleId: 'VLE-GNT-402',
  },
  {
    aadhaarFull: '876500008834',
    aadhaarLast4: '8834',
    name: 'V. Sambasiva Rao',
    phone: '98480 44321',
    village: 'Tadikonda',
    bankName: 'Andhra Pragathi Grameena Bank',
    accountLast4: '8834',
    preferredLanguage: 'te',
    registeredAt: '2026-08-10T11:00:00.000Z',
    registeredByVleId: 'VLE-GNT-402',
  },
  {
    aadhaarFull: '765400001902',
    aadhaarLast4: '1902',
    name: 'K. Venkata Reddy',
    phone: '98491 66778',
    village: 'Mangalagiri',
    bankName: 'Union Bank of India',
    accountLast4: '1902',
    preferredLanguage: 'te',
    registeredAt: '2026-08-15T10:00:00.000Z',
    registeredByVleId: 'VLE-GNT-402',
  },
  {
    aadhaarFull: '654300005561',
    aadhaarLast4: '5561',
    name: 'M. Subrahmanyam',
    phone: '94402 33445',
    village: 'Pedakakani',
    bankName: 'Canara Bank',
    accountLast4: '5561',
    preferredLanguage: 'te',
    registeredAt: '2026-08-20T08:30:00.000Z',
    registeredByVleId: 'VLE-GNT-402',
  },
  {
    aadhaarFull: '543200007723',
    aadhaarLast4: '7723',
    name: 'P. Nageswara Rao',
    phone: '99890 11223',
    village: 'Amaravati Rural',
    bankName: 'State Bank of India (SBI)',
    accountLast4: '7723',
    preferredLanguage: 'te',
    registeredAt: '2026-08-25T09:15:00.000Z',
    registeredByVleId: 'VLE-GNT-402',
  },
];

// Internal state — will be loaded from storage on first access
let _db: FarmerRegistrationRecord[] | null = null;

function getDb(): FarmerRegistrationRecord[] {
  if (_db === null) {
    const stored = loadFromStorage();
    if (stored.length === 0) {
      _db = [...SEED_FARMERS];
      saveToStorage(_db);
    } else {
      // Ensure seed farmers are always present
      const existing = new Set(stored.map((r) => r.aadhaarFull));
      const missing = SEED_FARMERS.filter((f) => !existing.has(f.aadhaarFull));
      _db = [...stored, ...missing];
    }
  }
  return _db;
}

/** Look up a farmer by full 12-digit Aadhaar number */
export function findFarmerByAadhaar(aadhaarFull: string): FarmerRegistrationRecord | null {
  const clean = aadhaarFull.replace(/\s+/g, '');
  return getDb().find((r) => r.aadhaarFull === clean) || null;
}

/** Register a new farmer */
export function registerFarmer(farmer: FarmerRegistrationRecord): void {
  const db = getDb();
  // Remove existing entry with same Aadhaar if any
  const idx = db.findIndex((r) => r.aadhaarFull === farmer.aadhaarFull);
  if (idx >= 0) {
    db.splice(idx, 1, farmer);
  } else {
    db.unshift(farmer);
  }
  saveToStorage(db);
}

/** Get all farmers (for listing in operator dashboard) */
export function getAllFarmers(): FarmerRegistrationRecord[] {
  return [...getDb()];
}

/** Force reset (for testing) */
export function resetDb(): void {
  _db = null;
  localStorage.removeItem(STORAGE_KEY);
}
