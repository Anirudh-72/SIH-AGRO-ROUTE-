import { SupportedLanguage } from '../data/translations';

// Cache available voices
let voicesLoaded = false;
let availableVoices: SpeechSynthesisVoice[] = [];

if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  const loadVoices = () => {
    availableVoices = window.speechSynthesis.getVoices();
    voicesLoaded = true;
  };

  loadVoices();
  if (window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }
}

/**
 * Get the best matching speech synthesis voice for the target language.
 */
export function getVoiceForLanguage(lang: SupportedLanguage): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;

  if (!voicesLoaded || availableVoices.length === 0) {
    availableVoices = window.speechSynthesis.getVoices();
  }

  const langCode = lang === 'te' ? 'te-IN' : lang === 'hi' ? 'hi-IN' : 'en-IN';

  // 1. Exact match
  const exact = availableVoices.find((v) => v.lang.toLowerCase() === langCode.toLowerCase());
  if (exact) return exact;

  // 2. Prefix match (e.g., 'te', 'hi', 'en')
  const prefix = lang === 'te' ? 'te' : lang === 'hi' ? 'hi' : 'en';
  const matchPrefix = availableVoices.find((v) => v.lang.toLowerCase().startsWith(prefix));
  if (matchPrefix) return matchPrefix;

  // 3. Fallback to any Indian voice or default
  const inVoice = availableVoices.find((v) => v.lang.toLowerCase().includes('in'));
  return inVoice || availableVoices[0] || null;
}

/**
 * Speak text in the specified language with callback on start and end.
 */
export function speakVernacularText(
  text: string,
  lang: SupportedLanguage,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: () => void
): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported in this environment');
    return false;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  const voice = getVoiceForLanguage(lang);
  if (voice) {
    utterance.voice = voice;
  }
  utterance.lang = lang === 'te' ? 'te-IN' : lang === 'hi' ? 'hi-IN' : 'en-IN';
  utterance.rate = 0.95; // Slightly slower for rural audience comprehension
  utterance.pitch = 1.0;

  utterance.onstart = () => {
    if (onStart) onStart();
  };

  utterance.onend = () => {
    if (onEnd) onEnd();
  };

  utterance.onerror = (e) => {
    console.warn('Speech synthesis error or interrupted:', e);
    if (onError) onError();
    else if (onEnd) onEnd();
  };

  window.speechSynthesis.speak(utterance);
  return true;
}

/**
 * Stop any current speech synthesis.
 */
export function stopSpeech(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
