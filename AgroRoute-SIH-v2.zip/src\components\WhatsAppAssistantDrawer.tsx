import React, { useState } from 'react';
import { SupportedLanguage, TRANSLATIONS } from '../data/translations';
import { speakVernacularText, stopSpeech } from '../utils/speechUtils';
import {
  X,
  Play,
  Square,
  CheckCheck,
  Phone,
  Video,
  MoreVertical,
  Mic,
  Smile,
  Paperclip,
  Share2,
  QrCode,
  ShieldCheck,
} from 'lucide-react';

interface WhatsAppAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  language: SupportedLanguage;
}

export const WhatsAppAssistantDrawer: React.FC<WhatsAppAssistantDrawerProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const t = TRANSLATIONS[language];
  const [isPlayingAudio, setIsPlayingAudio] = useState<'farmer' | 'bot' | null>(null);

  if (!isOpen) return null;

  const farmerAudioText =
    language === 'te'
      ? 'నమస్కారం సార్! నా పేరు సాంబశివరావు, తాడికొండ గ్రామం. నా వద్ద 8 బస్తాల మిర్చి ఉంది, సుమారు 420 కేజీలు. రేపు ఉదయం లారీ పంపగలరా?'
      : language === 'hi'
      ? 'नमस्ते साहब! मेरा नाम साम्बाशिव राव है, गांव ताडिकोंडा। मेरे पास 8 बोरी मिर्च है, लगभग 420 किलो। क्या कल सुबह पिकअप गाड़ी भेज सकते हैं?'
      : 'Hello sir! My name is Sambasiva Rao from Tadikonda village. I have 8 bags of chilli, approximately 420 kg. Can you please send a pickup vehicle tomorrow morning?';

  const botAudioText =
    language === 'te'
      ? 'సాంబశివరావు గారూ, మీ తాడికొండ గ్రామానికి LCV-01 లారీ బుక్ చేయబడింది. ఈరోజు ధర కేజీకి రూ. 218. మీ 420 కేజీల మిర్చికి రూ. 91,560 నేరుగా మీ స్టేట్ బ్యాంక్ ఆఫ్ ఇండియా ఖాతాకు జమ అవుతుంది.'
      : language === 'hi'
      ? 'साम्बाशिव राव जी, आपके ताडिकोंडा गांव के लिए 2-टन गाड़ी LCV-01 बुक कर ली गई है। आज का भाव ₹218 प्रति किलो है। आपकी 420 किलो मिर्च का ₹91,560 सीधे आपके बैंक खाते में जमा होगा।'
      : 'Sambasiva Rao garu, 2-Ton LCV-01 has been booked for Tadikonda village. Today’s rate is Rs. 218 per kg. Rs. 91,560 will be credited directly to your SBI account via DBT.';

  const handlePlayVoice = (type: 'farmer' | 'bot') => {
    if (isPlayingAudio === type) {
      stopSpeech();
      setIsPlayingAudio(null);
      return;
    }

    setIsPlayingAudio(type);
    const textToSpeak = type === 'farmer' ? farmerAudioText : botAudioText;

    speakVernacularText(
      textToSpeak,
      language,
      () => setIsPlayingAudio(type),
      () => setIsPlayingAudio(null),
      () => setIsPlayingAudio(null)
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#EFEAE2] w-full max-w-md rounded-2xl shadow-2xl border border-gray-300 overflow-hidden flex flex-col h-[650px] max-h-[92vh]">
        {/* WhatsApp Top Navigation Bar */}
        <div className="bg-[#075E54] text-white p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-[#075E54] flex items-center justify-center font-black text-sm">
                🌾
              </div>
              <span className="w-3 h-3 rounded-full bg-[#25D366] border-2 border-[#075E54] absolute bottom-0 right-0" />
            </div>

            <div>
              <div className="text-sm font-bold flex items-center gap-1.5 leading-tight">
                <span>AgroRoute Kisan Bot</span>
                <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
              </div>
              <div className="text-[10px] text-emerald-200">
                Official APMC Verified Assistant • Online
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 text-white/90">
            <Phone className="w-4 h-4" />
            <Video className="w-4 h-4" />
            <button
              onClick={() => {
                stopSpeech();
                onClose();
              }}
              className="p-1 text-white hover:bg-white/10 rounded-md"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* WhatsApp Chat Conversation Canvas */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[radial-gradient(#CBD5E1_1px,transparent_1px)] [background-size:16px_16px]">
          {/* Encryption Notice */}
          <div className="text-center my-1">
            <span className="px-3 py-1 bg-[#FFF9C4] text-amber-900 text-[10px] rounded-md shadow-2xs inline-block">
              🔒 End-to-end encrypted with Government NPCI Escrow
            </span>
          </div>

          {/* 1. Farmer Voice Note Bubble (Incoming from Farmer) */}
          <div className="flex justify-end">
            <div className="bg-[#DCF8C6] rounded-2xl rounded-tr-xs p-3 shadow-xs max-w-[85%] border border-[#c3eab3]">
              <div className="text-[11px] font-bold text-[#075E54] mb-1 flex items-center justify-between">
                <span>V. Sambasiva Rao (Tadikonda)</span>
                <span className="text-[10px] text-gray-500 font-normal">10:14 AM</span>
              </div>

              {/* Voice Note Player Pill */}
              <div className="flex items-center gap-2.5 my-1 bg-white/70 p-2 rounded-xl border border-[#c5e6b7]">
                <button
                  type="button"
                  onClick={() => handlePlayVoice('farmer')}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                    isPlayingAudio === 'farmer'
                      ? 'bg-rose-600 text-white animate-pulse'
                      : 'bg-[#075E54] text-white hover:bg-[#128C7E]'
                  }`}
                >
                  {isPlayingAudio === 'farmer' ? (
                    <Square className="w-4 h-4" />
                  ) : (
                    <Play className="w-4 h-4 ml-0.5" />
                  )}
                </button>

                {/* Simulated Audio Waveform */}
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-0.5 h-4">
                    {[12, 18, 8, 24, 16, 28, 14, 20, 10, 22, 16, 26, 12, 18].map((h, i) => (
                      <span
                        key={i}
                        className={`w-1 rounded-full ${
                          isPlayingAudio === 'farmer' ? 'bg-[#075E54] animate-pulse' : 'bg-gray-400'
                        }`}
                        style={{ height: `${h}px` }}
                      />
                    ))}
                  </div>
                  <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                    <span>{isPlayingAudio === 'farmer' ? 'Playing...' : '0:06'}</span>
                    <span>Voice Note (తెలుగు / Hindi)</span>
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-gray-600 italic">
                "{farmerAudioText.substring(0, 50)}..."
              </div>

              <div className="flex justify-end items-center gap-1 text-[10px] text-gray-500 mt-1">
                <span>10:14 AM</span>
                <CheckCheck className="w-3.5 h-3.5 text-sky-500" />
              </div>
            </div>
          </div>

          {/* 2. Bot Automated Reply Bubble */}
          <div className="flex justify-start">
            <div className="bg-white rounded-2xl rounded-tl-xs p-3 shadow-xs max-w-[85%] border border-gray-200">
              <div className="text-[11px] font-bold text-[#075E54] mb-1">
                AgroRoute Automated Assistant
              </div>

              {/* Bot Voice Note Player */}
              <div className="flex items-center gap-2.5 my-1 bg-gray-50 p-2 rounded-xl border border-gray-200">
                <button
                  type="button"
                  onClick={() => handlePlayVoice('bot')}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                    isPlayingAudio === 'bot'
                      ? 'bg-rose-600 text-white animate-pulse'
                      : 'bg-[#25D366] text-emerald-950 hover:bg-[#20bd5a]'
                  }`}
                >
                  {isPlayingAudio === 'bot' ? (
                    <Square className="w-4 h-4" />
                  ) : (
                    <Play className="w-4 h-4 ml-0.5" />
                  )}
                </button>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-0.5 h-4">
                    {[14, 22, 12, 26, 18, 30, 16, 24, 14, 28, 20, 18, 14, 22].map((h, i) => (
                      <span
                        key={i}
                        className={`w-1 rounded-full ${
                          isPlayingAudio === 'bot' ? 'bg-[#25D366] animate-pulse' : 'bg-gray-400'
                        }`}
                        style={{ height: `${h}px` }}
                      />
                    ))}
                  </div>
                  <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                    <span>{isPlayingAudio === 'bot' ? 'Playing...' : '0:08'}</span>
                    <span>Verified Mandi Receipt</span>
                  </div>
                </div>
              </div>

              {/* Verified Digital Booking Card with Thermal QR Stamp */}
              <div className="mt-2.5 p-2.5 bg-emerald-50 rounded-xl border border-emerald-300 text-xs space-y-1 text-emerald-950">
                <div className="flex items-center justify-between font-bold text-[11px] text-emerald-900 border-b border-emerald-200 pb-1">
                  <span>✅ VEHICLE BOOKING CONFIRMED</span>
                  <span>LCV-AP-01</span>
                </div>
                <div className="text-[11px] font-semibold">
                  Crop: <strong>Guntur Teja Mirchi</strong> (420 KG)
                </div>
                <div className="text-[11px]">
                  Guaranteed Rate: <strong>Rs. 218/KG</strong> (Rs. 21,800/Qtl)
                </div>
                <div className="text-[11px] font-bold text-emerald-800">
                  Total Payout: Rs. 91,560.00
                </div>
                <div className="text-[9px] text-gray-500 font-mono pt-1 flex items-center justify-between">
                  <span>Aadhaar DBT • SBI •••• 4012</span>
                  <QrCode className="w-4 h-4 text-emerald-800" />
                </div>
              </div>

              <div className="flex justify-end items-center gap-1 text-[10px] text-gray-500 mt-1">
                <span>10:15 AM</span>
              </div>
            </div>
          </div>
        </div>

        {/* WhatsApp Mock Input Footer */}
        <div className="p-2 bg-[#F0F2F5] border-t border-gray-300 flex items-center gap-2">
          <button className="p-1.5 text-gray-600 hover:text-gray-900">
            <Smile className="w-5 h-5" />
          </button>
          <button className="p-1.5 text-gray-600 hover:text-gray-900">
            <Paperclip className="w-5 h-5" />
          </button>
          <input
            type="text"
            readOnly
            value="Press mic to speak in Telugu or Hindi..."
            className="flex-1 py-2 px-3 bg-white rounded-full text-xs text-gray-500 border border-gray-200"
          />
          <button
            onClick={() => handlePlayVoice('farmer')}
            className="w-10 h-10 rounded-full bg-[#128C7E] text-white flex items-center justify-center hover:bg-[#075E54] shadow-xs"
            title="Simulate Voice Note"
          >
            <Mic className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
