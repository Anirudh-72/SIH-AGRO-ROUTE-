import React, { useState, useEffect, useRef } from 'react';
import { SupportedLanguage } from '../data/translations';
import { FarmerAsk } from '../types';
import { speakVernacularText } from '../utils/speechUtils';
import {
  Phone,
  PhoneCall,
  PhoneOff,
  Volume2,
  VolumeX,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  ShieldCheck,
  Radio,
  ArrowLeft,
  Smartphone,
  Info,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface FeaturePhoneSimulatorProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onReturnToModeSelection: () => void;
  onAddFarmerAsk: (ask: FarmerAsk) => void;
}

// DTMF standard frequencies
const DTMF_FREQS: { [key: string]: [number, number] } = {
  '1': [697, 1209],
  '2': [697, 1336],
  '3': [697, 1477],
  '4': [770, 1209],
  '5': [770, 1336],
  '6': [770, 1477],
  '7': [852, 1209],
  '8': [852, 1336],
  '9': [852, 1477],
  '*': [941, 1209],
  '0': [941, 1336],
  '#': [941, 1477],
};

export const FeaturePhoneSimulator: React.FC<FeaturePhoneSimulatorProps> = ({
  language,
  onLanguageChange,
  onReturnToModeSelection,
  onAddFarmerAsk,
}) => {
  // IVR Call State
  // 'idle' | 'calling' | 'connected_menu' | 'enter_quantity' | 'confirm_price' | 'order_confirmed'
  const [callState, setCallState] = useState<
    'idle' | 'calling' | 'connected_menu' | 'enter_quantity' | 'confirm_price' | 'order_confirmed'
  >('idle');

  const [dialedNumber, setDialedNumber] = useState<string>('1800-425-1515');
  const [callDuration, setCallDuration] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Farmer's input during call
  const [selectedCrop, setSelectedCrop] = useState<'Guntur Teja Mirchi' | 'Shankar-6 Cotton'>('Guntur Teja Mirchi');
  const [enteredQuantityStr, setEnteredQuantityStr] = useState<string>('');
  const [generatedToken, setGeneratedToken] = useState<string>('IVR-8842');

  const audioCtxRef = useRef<AudioContext | null>(null);

  // Play realistic DTMF Beep
  const playTone = (key: string) => {
    if (!soundEnabled) return;
    try {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtxClass) return;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioCtxClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const freqs = DTMF_FREQS[key] || [440, 440];
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.frequency.value = freqs[0];
      osc2.frequency.value = freqs[1];
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + 0.16);
      osc2.stop(ctx.currentTime + 0.16);
    } catch (e) {
      // Ignore audio synthesis errors
    }
  };

  // Call timer effect
  useEffect(() => {
    let timer: any = null;
    if (callState !== 'idle' && callState !== 'order_confirmed') {
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [callState]);

  // Handle Initiating Call
  const handleStartCall = () => {
    playTone('*');
    setCallState('calling');
    setCallDuration(0);

    setTimeout(() => {
      setCallState('connected_menu');
      const prompt =
        language === 'te'
          ? 'నమస్కారం! అగ్రోరూట్ కిసాన్ హెల్ప్‌లైన్‌కు స్వాగతం. మిర్చి అమ్మడానికి 1 నొక్కండి, పత్తి అమ్మడానికి 2 నొక్కండి.'
          : language === 'hi'
          ? 'नमस्ते! एग्रोरूट किसान हेल्पलाइन में स्वागत है। मिर्च बेचने के लिए 1 दबाएं, कपास के लिए 2 दबाएं।'
          : 'Welcome to AgroRoute Kisan Helpline. Press 1 for Guntur Mirchi, press 2 for Cotton.';
      if (soundEnabled) speakVernacularText(prompt, language);
    }, 1500);
  };

  // Handle Keypad Press
  const handleKeyPress = (key: string) => {
    playTone(key);

    if (callState === 'idle') {
      if (key === '#') {
        handleStartCall();
      } else {
        setDialedNumber((prev) => (prev.length < 14 ? prev + key : prev));
      }
      return;
    }

    if (callState === 'connected_menu') {
      if (key === '1') {
        setSelectedCrop('Guntur Teja Mirchi');
        setCallState('enter_quantity');
        setEnteredQuantityStr('');
        const prompt =
          language === 'te'
            ? 'గుంటూరు తేజ మిర్చి ఎంచుకున్నారు. ఎన్ని క్వింటాళ్లు అమ్మాలనుకుంటున్నారు? సంఖ్యను టైప్ చేసి హ్యాష్ నొక్కండి.'
            : 'You selected Mirchi. Enter quantity in quintals and press hash.';
        if (soundEnabled) speakVernacularText(prompt, language);
      } else if (key === '2') {
        setSelectedCrop('Shankar-6 Cotton');
        setCallState('enter_quantity');
        setEnteredQuantityStr('');
        const prompt =
          language === 'te'
            ? 'శంకర్-6 పత్తి ఎంచుకున్నారు. ఎన్ని క్వింటాళ్లు అమ్మాలనుకుంటున్నారు? సంఖ్యను టైప్ చేసి హ్యాష్ నొక్కండి.'
            : 'You selected Cotton. Enter quantity in quintals and press hash.';
        if (soundEnabled) speakVernacularText(prompt, language);
      }
      return;
    }

    if (callState === 'enter_quantity') {
      if (key === '#') {
        const qty = parseInt(enteredQuantityStr, 10) || 15;
        setEnteredQuantityStr(qty.toString());
        setCallState('confirm_price');
        const rate = selectedCrop === 'Guntur Teja Mirchi' ? 21800 : 7450;
        const prompt =
          language === 'te'
            ? `మీరు ${qty} క్వింటాళ్లు నమోదు చేశారు. నేటి గ్యారంటీ ధర క్వింటాలుకు ₹${rate}. ఉచిత లారీ బుక్ చేయడానికి 1 నొక్కండి.`
            : `You entered ${qty} quintals. Today guaranteed rate is Rs ${rate} per quintal. Press 1 to book free pickup truck.`;
        if (soundEnabled) speakVernacularText(prompt, language);
      } else if (key >= '0' && key <= '9') {
        setEnteredQuantityStr((prev) => (prev.length < 3 ? prev + key : prev));
      }
      return;
    }

    if (callState === 'confirm_price') {
      if (key === '1') {
        handleConfirmOrder();
      } else if (key === '2' || key === '*') {
        setCallState('connected_menu');
      }
      return;
    }
  };

  // Confirm Order and create FarmerAsk with channel: 'ivr_simulated'
  const handleConfirmOrder = () => {
    const newToken = `IVR-${Math.floor(1000 + Math.random() * 9000)}`;
    setGeneratedToken(newToken);
    setCallState('order_confirmed');

    const qtyQtl = parseInt(enteredQuantityStr, 10) || 12;
    const weightKg = qtyQtl * 100;
    const rate = selectedCrop === 'Guntur Teja Mirchi' ? 21800 : 7450;

    const newAsk: FarmerAsk = {
      farmer_id: `F-${newToken}`,
      name: 'P. Venkateswara Rao (IVR Farmer)',
      village: 'Tadikonda Mandal (Rural)',
      commodity: selectedCrop,
      weight_kg: weightKg,
      ask_price_per_qtl: rate,
      lat: 16.3800 + Math.random() * 0.04,
      lon: 80.4600 + Math.random() * 0.04,
      vle_id: 'VLE-GNT-402',
      contact: '98480 99881',
      channel: 'ivr_simulated',
      within_pooling_radius: true,
      created_at: new Date().toISOString(),
    };

    onAddFarmerAsk(newAsk);

    try {
      confetti({
        particleCount: 40,
        spread: 50,
        origin: { y: 0.6 },
      });
    } catch (e) {}

    const prompt =
      language === 'te'
        ? `మీ బుకింగ్ పూర్తయింది! టోకెన్ నంబర్ ${newToken}. మీ తాడికొండ విలేజ్ సెక్రటేరియట్ ఆపరేటర్ లారీ కేటాయింపు కోసం మిమ్మల్ని సంప్రదిస్తారు.`
        : `Booking confirmed! Token number ${newToken}. Your village VLE operator will contact you for truck arrival.`;
    if (soundEnabled) speakVernacularText(prompt, language);
  };

  // End / Hang Up Call
  const handleEndCall = () => {
    playTone('#');
    setCallState('idle');
    setEnteredQuantityStr('');
  };

  // Format Call Timer
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="max-w-6xl mx-auto w-full space-y-6">
      {/* Top Banner */}
      <div className="bg-emerald-950 text-white rounded-3xl p-5 sm:p-6 shadow-xl border-2 border-emerald-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-emerald-700/80 border border-emerald-500 flex items-center justify-center text-3xl shadow-inner">
            📞
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white">
                {language === 'te'
                  ? 'కీప్యాడ్ ఫోన్ / IVR సిమ్యులేటర్ (Zero-Smartphone Layer)'
                  : 'Keypad Feature Phone / IVR Simulator'}
              </h1>
              <span className="text-[11px] font-black bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-500/40">
                100% Offline / Non-Smartphone Ready
              </span>
            </div>
            <p className="text-xs text-emerald-200/80 font-medium mt-1">
              స్మార్ట్‌ఫోన్ లేదా ఇంటర్నెట్ లేని సాధారణ రైతులు కేవలం టోల్-ఫ్రీ <strong>1800-425-1515</strong> కి కాల్ చేసి పంట నమోదు చేసుకునే సాంకేతికత.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Mute/Audio Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2.5 rounded-xl border text-xs font-black flex items-center gap-1.5 transition-all ${
              soundEnabled
                ? 'bg-emerald-800 text-emerald-200 border-emerald-600'
                : 'bg-gray-800 text-gray-400 border-gray-700'
            }`}
            title="Audio voice & DTMF tones toggle"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">{soundEnabled ? 'వాయిస్ ఆన్' : 'వాయిస్ ఆఫ్'}</span>
          </button>

          {/* Mode Exit */}
          <button
            id="ivr-exit-btn"
            onClick={onReturnToModeSelection}
            className="px-3.5 py-2.5 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-emerald-200 text-xs font-black flex items-center gap-2 border border-emerald-700 transition-all"
          >
            <RotateCcw className="w-4 h-4 text-emerald-400" />
            <span>మోడ్ మార్చండి / Exit</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Realistic Nokia Keypad Mockup on Left + Live Process Breakdown on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* ================================================================= */}
        {/* THE NOKIA / BHARATPHONE HARDWARE CHASSIS */}
        {/* ================================================================= */}
        <div className="lg:col-span-6 flex justify-center">
          <div className="w-full max-w-[340px] bg-gradient-to-b from-slate-900 via-slate-950 to-neutral-950 rounded-[48px] p-6 shadow-2xl border-4 border-slate-800 relative select-none">
            {/* Top Speaker Grill */}
            <div className="flex justify-center mb-4">
              <div className="w-16 h-1.5 bg-slate-800 rounded-full border border-slate-700"></div>
            </div>

            {/* Brand Logo */}
            <div className="text-center mb-3">
              <span className="text-[10px] font-black tracking-widest text-slate-400 uppercase">
                BHARAT-PHONE • KISAN SETU 4G
              </span>
            </div>

            {/* RETRO BACKLIT MONOCHROME LCD SCREEN */}
            <div className="bg-[#0b1f17] border-4 border-slate-800 rounded-2xl p-4 shadow-inner min-h-[210px] flex flex-col justify-between relative overflow-hidden font-mono text-emerald-300">
              {/* Scanline CRT overlay */}
              <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[length:100%_4px] pointer-events-none opacity-40"></div>

              {/* Status Header Bar: Battery & Network */}
              <div className="flex items-center justify-between text-[10px] border-b border-emerald-900/60 pb-1.5 z-10 text-emerald-400/90 font-bold">
                <span className="flex items-center gap-1">
                  <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
                  BSNL-AP 4G
                </span>
                <span>{callState === 'idle' ? '10:42 AM' : formatTime(callDuration)}</span>
                <span>🔋 85%</span>
              </div>

              {/* Screen Content State Machine */}
              <div className="py-2 z-10 space-y-2 flex-1 flex flex-col justify-center">
                {/* IDLE STATE */}
                {callState === 'idle' && (
                  <div className="text-center space-y-2">
                    <div className="text-xs text-emerald-400/80 uppercase tracking-wider font-bold">
                      APMC TOLL-FREE
                    </div>
                    <div className="text-lg font-black text-emerald-300 tracking-wider">
                      {dialedNumber}
                    </div>
                    <p className="text-[10px] text-emerald-400/70 leading-tight">
                      కాల్ చేయడానికి ఆకుపచ్చ బటన్ లేదా <strong>[CALL]</strong> నొక్కండి
                    </p>
                  </div>
                )}

                {/* CALLING / CONNECTING */}
                {callState === 'calling' && (
                  <div className="text-center space-y-2">
                    <div className="text-[11px] text-amber-300 animate-pulse font-bold">
                      డయలింగ్... (CALLING)
                    </div>
                    <div className="text-sm font-black text-emerald-200">{dialedNumber}</div>
                    <div className="text-[10px] text-emerald-400/60">Guntur APMC Kisan Escrow IVR</div>
                  </div>
                )}

                {/* CONNECTED MENU */}
                {callState === 'connected_menu' && (
                  <div className="space-y-1.5 text-[11px]">
                    <div className="text-[9px] text-emerald-400 font-bold uppercase border-b border-emerald-900 pb-0.5">
                      IVR MENU: పంట ఎంపిక
                    </div>
                    <div className="text-emerald-200 font-bold leading-tight">
                      [1] గుంటూరు తేజ మిర్చి
                    </div>
                    <div className="text-emerald-200 font-bold leading-tight">
                      [2] శంకర్-6 పత్తి
                    </div>
                    <div className="text-[10px] text-emerald-400/80 pt-1">
                      కీప్యాడ్ లో 1 లేదా 2 నొక్కండి
                    </div>
                  </div>
                )}

                {/* ENTER QUANTITY */}
                {callState === 'enter_quantity' && (
                  <div className="space-y-1.5 text-[11px]">
                    <div className="text-[9px] text-emerald-400 font-bold uppercase border-b border-emerald-900 pb-0.5">
                      పరిమాణం నమోదు
                    </div>
                    <div className="text-emerald-200 font-bold">
                      పంట: {selectedCrop === 'Guntur Teja Mirchi' ? 'మిర్చి' : 'పత్తి'}
                    </div>
                    <div className="bg-emerald-950/80 p-1.5 rounded border border-emerald-700 text-center">
                      <span className="text-sm font-black text-white">
                        {enteredQuantityStr || '0'}
                      </span>{' '}
                      <span className="text-[10px]">క్వింటాళ్లు</span>
                    </div>
                    <div className="text-[9px] text-emerald-400/80">
                      సంఖ్య టైప్ చేసి <strong>#</strong> నొక్కండి
                    </div>
                  </div>
                )}

                {/* CONFIRM PRICE */}
                {callState === 'confirm_price' && (
                  <div className="space-y-1 text-[11px]">
                    <div className="text-[9px] text-emerald-400 font-bold uppercase border-b border-emerald-900 pb-0.5">
                      ధర నిర్ధారణ & బుకింగ్
                    </div>
                    <div className="text-emerald-200">
                      పరిమాణం: <strong>{enteredQuantityStr} Qtl</strong> ({parseInt(enteredQuantityStr, 10) * 100} kg)
                    </div>
                    <div className="text-amber-300 font-bold">
                      రేటు: ₹{selectedCrop === 'Guntur Teja Mirchi' ? '21,800' : '7,450'}/Qtl
                    </div>
                    <div className="text-[10px] text-emerald-300 font-bold pt-1">
                      [1] నిర్ధారించండి | [2] రద్దు
                    </div>
                  </div>
                )}

                {/* ORDER CONFIRMED */}
                {callState === 'order_confirmed' && (
                  <div className="space-y-1.5 text-[10px]">
                    <div className="text-[9px] text-emerald-300 font-bold uppercase border-b border-emerald-800 pb-0.5 flex items-center justify-between">
                      <span>SMS రశీదు</span>
                      <span>{generatedToken}</span>
                    </div>
                    <div className="text-emerald-100 font-bold">
                      ఆర్డర్ నమోదైంది!
                    </div>
                    <div className="text-emerald-300">
                      లారీ: ఉచిత పికప్ రేపు 9 AM
                    </div>
                    <div className="text-[9px] text-emerald-400/80">
                      VLE-GNT-402 తాడికొండ ఆపరేటర్ ఫోన్ చేస్తారు.
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Softkeys */}
              <div className="flex justify-between items-center text-[10px] border-t border-emerald-900/60 pt-1 z-10 text-emerald-400/80 font-bold">
                <span>{callState === 'idle' ? 'Options' : 'Mute'}</span>
                <span>{callState === 'idle' ? 'Menu' : 'End'}</span>
              </div>
            </div>

            {/* CALL ACTION KEYS (GREEN & RED) */}
            <div className="grid grid-cols-2 gap-4 my-4">
              <button
                id="phone-call-btn"
                onClick={handleStartCall}
                disabled={callState !== 'idle'}
                className={`py-3 px-4 rounded-2xl flex items-center justify-center gap-2 font-black text-xs transition-all shadow-md active:scale-95 ${
                  callState === 'idle'
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                    : 'bg-emerald-950 text-emerald-800 opacity-50 cursor-not-allowed'
                }`}
              >
                <PhoneCall className="w-4 h-4" />
                <span>CALL</span>
              </button>

              <button
                id="phone-end-btn"
                onClick={handleEndCall}
                disabled={callState === 'idle'}
                className={`py-3 px-4 rounded-2xl flex items-center justify-center gap-2 font-black text-xs transition-all shadow-md active:scale-95 ${
                  callState !== 'idle'
                    ? 'bg-rose-600 hover:bg-rose-500 text-white cursor-pointer'
                    : 'bg-rose-950 text-rose-800 opacity-50 cursor-not-allowed'
                }`}
              >
                <PhoneOff className="w-4 h-4" />
                <span>END</span>
              </button>
            </div>

            {/* PHYSICAL 3x4 TACTILE KEYPAD */}
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { key: '1', sub: '.,' },
                { key: '2', sub: 'ABC' },
                { key: '3', sub: 'DEF' },
                { key: '4', sub: 'GHI' },
                { key: '5', sub: 'JKL' },
                { key: '6', sub: 'MNO' },
                { key: '7', sub: 'PQRS' },
                { key: '8', sub: 'TUV' },
                { key: '9', sub: 'WXYZ' },
                { key: '*', sub: 'APMC' },
                { key: '0', sub: '+' },
                { key: '#', sub: 'CONF' },
              ].map(({ key, sub }) => (
                <button
                  key={key}
                  id={`ivr-key-${key === '*' ? 'star' : key === '#' ? 'hash' : key}`}
                  onClick={() => handleKeyPress(key)}
                  className="bg-gradient-to-b from-slate-800 to-slate-900 hover:from-slate-700 hover:to-slate-800 active:from-slate-950 active:to-black text-white rounded-2xl p-2.5 border-2 border-slate-700 shadow-md active:shadow-inner flex flex-col items-center justify-center transition-all active:scale-95 group"
                >
                  <span className="text-base font-black leading-none group-hover:text-emerald-300">
                    {key}
                  </span>
                  <span className="text-[8px] font-bold text-slate-400 group-hover:text-slate-200 mt-0.5">
                    {sub}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ================================================================= */}
        {/* RIGHT COLUMN: EDUCATIONAL / LIVE WORKFLOW AUDIT */}
        {/* ================================================================= */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white p-6 rounded-3xl border border-gray-200 shadow-2xs space-y-4">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                <Smartphone className="w-5 h-5" />
              </span>
              <div>
                <h3 className="text-base font-black text-gray-900">
                  స్మార్ట్‌ఫోన్ లేని రైతుల కోసం జీరో-టెక్నాలజీ వంతెన
                </h3>
                <p className="text-xs text-gray-500 font-medium">
                  Inclusive Architecture for Rural Smallholders (SIH26033 Mandate)
                </p>
              </div>
            </div>

            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-2">
              <div className="font-black flex items-center gap-1.5 text-emerald-900">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                కీప్యాడ్ ఫోన్ ద్వారా ఆర్డర్ ఎలా పూర్తవుతుంది?
              </div>
              <ol className="list-decimal pl-4 space-y-1 font-medium text-emerald-900/90 text-[11px] leading-relaxed">
                <li>
                  రైతు ఉచిత నంబర్ <strong>1800-425-1515</strong> కి మిస్డ్‌కాల్ లేదా కాల్ చేస్తాడు.
                </li>
                <li>
                  స్థానిక భాషలో (తెలుగు/హిందీ) IVR ఆడియో ద్వారా పంట మరియు బస్తాల సంఖ్యను అడుగుతుంది.
                </li>
                <li>
                  నేటి ప్రభుత్వ కనీస రక్షణ ధర మరియు ఆక్షన్ మార్కెట్ ధర రైతుకు ఆడియో రూపంలో చదివి వినిపిస్తుంది.
                </li>
                <li>
                  నిర్ధారించిన వెంటనే ఆర్డర్ సిస్టమ్‌లో <code>channel: 'ivr_simulated'</code> ట్యాగ్‌తో నమోదవుతుంది.
                </li>
                <li>
                  గ్రామ పంచాయతీ CSC ఆపరేటర్‌కు తక్షణమే హెచ్చరిక వెళ్లి, లారీ పికప్ సమయాన్ని ఖరారు చేస్తారు.
                </li>
              </ol>
            </div>

            {/* Simulated Live Action Log */}
            <div className="border border-gray-200 rounded-2xl p-4 bg-gray-50 space-y-2">
              <div className="text-xs font-black text-gray-700 uppercase tracking-wider flex items-center justify-between">
                <span>లైవ్ సిస్టమ్ రికార్డు (Current Call State)</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 font-bold">
                  {callState.toUpperCase()}
                </span>
              </div>

              <div className="text-xs space-y-1 text-gray-600">
                <div className="flex justify-between">
                  <span>కాల్ చేసిన హెల్ప్‌లైన్:</span>
                  <strong className="text-gray-900">1800-425-1515 (APMC Krishi Setu)</strong>
                </div>
                <div className="flex justify-between">
                  <span>ఎంపిక చేసిన పంట:</span>
                  <strong className="text-emerald-800">{selectedCrop}</strong>
                </div>
                <div className="flex justify-between">
                  <span>నమోదు చేసిన పరిమాణం:</span>
                  <strong className="text-gray-900">{enteredQuantityStr || '0'} క్వింటాళ్లు</strong>
                </div>
                <div className="flex justify-between">
                  <span>కేటాయించిన టోకెన్:</span>
                  <strong className="text-sky-800 font-mono">{generatedToken}</strong>
                </div>
              </div>
            </div>

            {/* Quick Test Action */}
            <div className="p-4 bg-sky-50 rounded-2xl border border-sky-200 flex items-center justify-between gap-3">
              <div className="text-xs text-sky-950 font-medium">
                డెమో పరీక్ష కోసం 1-క్లిక్ ఆటోమేటిక్ కాల్ పూర్తి చేయాలనుకుంటున్నారా?
              </div>
              <button
                onClick={() => {
                  handleStartCall();
                  setTimeout(() => handleKeyPress('1'), 1800);
                  setTimeout(() => handleKeyPress('1'), 2800);
                  setTimeout(() => handleKeyPress('5'), 3400);
                  setTimeout(() => handleKeyPress('#'), 4000);
                  setTimeout(() => handleKeyPress('1'), 5200);
                }}
                className="px-3 py-2 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-black shrink-0 transition-all"
              >
                ఆటో-డెమో రన్
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
