export type SupportedLanguage = 'te' | 'hi' | 'en';

export interface TranslationDictionary {
  appName: string;
  subTitle: string;
  operatorMode: string;
  farmerMode: string;
  todayMandiPrice: string;
  perKg: string;
  perQuintal: string;
  floorProtected: string;
  listenAudio: string;
  speaking: string;
  stopAudio: string;
  bookPickupTitle: string;
  bookPickupSubtitle: string;
  selectCrop: string;
  howManyBags: string;
  bags: string;
  approxWeight: string;
  enterYieldQuantity: string;
  selectWeightUnit: string;
  totalCalculatedWeight: string;
  estimatedPayout: string;
  allCropsDropdownLabel: string;
  cropCategoryLabel: string;
  quickSelectCrop: string;
  yieldQuantityPlaceholder: string;
  selectVillage: string;
  bookPickupBtn: string;
  bookingSuccess: string;
  myMoneyTitle: string;
  myMoneySubtitle: string;
  dbtTransferDone: string;
  depositedTo: string;
  accountEnding: string;
  utrNumber: string;
  zeroCashNotice: string;
  produceTrackerTitle: string;
  step1: string;
  step1Sub: string;
  step2: string;
  step2Sub: string;
  step3: string;
  step3Sub: string;
  step4: string;
  step4Sub: string;
  callHelpdesk: string;
  aiAssistantTitle: string;
  aiAssistantSubtitle: string;
  askAnythingPrompt: string;
  typeOrSpeak: string;
  sendBtn: string;
  whatsAppBotTitle: string;
  whatsAppBotSubtitle: string;
  listenToVoiceNote: string;
  voiceNotePlaying: string;
  switchLanguage: string;
  // New keys for Operator Farmer Search
  searchByAadhaar: string;
  enterAadhaarPrompt: string;
  aadhaarLabel: string;
  aadhaarPlaceholder: string;
  searchBtn: string;
  farmerFound: string;
  farmerNotFound: string;
  registerNewFarmer: string;
  confirmIdentity: string;
  confirmNamePrompt: string;
  confirmVillagePrompt: string;
  confirmPhonePrompt: string;
  identityConfirmed: string;
  identityFailed: string;
  proceedToOrder: string;
  farmerName: string;
  farmerPhone: string;
  farmerVillage: string;
  farmerBank: string;
  farmerAccountLast4: string;
  farmerLanguage: string;
  saveAndRegister: string;
  farmerRegistered: string;
  // History / Transaction keys
  myOrders: string;
  orderHistory: string;
  noOrdersYet: string;
  orderId: string;
  orderDate: string;
  cropName: string;
  quantity: string;
  totalPayout: string;
  status: string;
  statusScheduled: string;
  statusInTransit: string;
  statusWeighed: string;
  statusPaid: string;
  viewSlip: string;
  // Navigation
  back: string;
  home: string;
  menu: string;
  // Mode selection
  selectMode: string;
  kisanMode: string;
  operatorMode2: string;
  buyerMode: string;
  ivrMode: string;
  adminMode: string;
  enterKisanMode: string;
  enterOperatorMode: string;
  enterBuyerMode: string;
  enterIvrMode: string;
  enterAdminMode: string;
  crops: {
    chilli: string;
    cotton: string;
    turmeric: string;
    maize: string;
  };
  sampleQuestions: string[];
}

export const TRANSLATIONS: Record<SupportedLanguage, TranslationDictionary> = {
  te: {
    appName: 'అగ్రోరూట్ కిసాన్ సేతు',
    subTitle: 'ఆంధ్రప్రదేశ్ రైతుల ప్రత్యక్ష మార్కెట్ సేవలు (గుంటూరు - విజయవాడ)',
    operatorMode: 'VLE / ఆపరేటర్ పోర్టల్',
    farmerMode: 'కిసాన్ మోడ్ (రైతు సేవలు)',
    todayMandiPrice: 'ఈరోజు గుంటూరు మార్కెట్ గ్యారంటీ ధర',
    perKg: 'కేజీకి',
    perQuintal: 'క్వింటాల్ కు',
    floorProtected: 'ప్రభుత్వ కనీస రక్షణ ధర కంటే ₹18 ఎక్కువ! నేడు అమ్మడం లాభదాయకం.',
    listenAudio: 'వినండి',
    speaking: 'వినిపిస్తోంది...',
    stopAudio: 'ఆపండి',
    bookPickupTitle: 'మీ ఊరికే ఉచిత రవాణా లారీని బుక్ చేయండి',
    bookPickupSubtitle: 'మధ్యవర్తులు లేకుండా నేరుగా మీ గ్రామం వద్దే తూకం మరియు పైకం',
    selectCrop: 'పంటను ఎంచుకోండి:',
    howManyBags: 'ఎన్ని బస్తాలు ఉన్నాయి?',
    bags: 'బస్తాలు',
    approxWeight: 'సుమారు బరువు',
    enterYieldQuantity: 'పంట దిగుబడి పరిమాణం:',
    selectWeightUnit: 'తూకం కొలత యూనిట్:',
    totalCalculatedWeight: 'మొత్తం నికర బరువు',
    estimatedPayout: 'అంచనా మొత్తం చెల్లింపు',
    allCropsDropdownLabel: 'అన్ని పంటల జాబితా:',
    cropCategoryLabel: 'రకం',
    quickSelectCrop: 'త్వరిత ఎంపిక:',
    yieldQuantityPlaceholder: 'దిగుబడి పరిమాణం టైప్ చేయండి',
    selectVillage: 'మీ గ్రామం ఎంచుకోండి:',
    bookPickupBtn: 'లారీ పంపమని కోరండి',
    bookingSuccess: 'లారీ బుకింగ్ విజయవంతమైంది! LCV-01 బయలుదేరింది.',
    myMoneyTitle: 'నా బ్యాంక్ జమ రశీదు',
    myMoneySubtitle: 'ఆధార్ ద్వారా DBT జమ',
    dbtTransferDone: 'బ్యాంక్ ఖాతాకు విజయవంతంగా జమైంది!',
    depositedTo: 'స్టేట్ బ్యాంక్ ఆఫ్ ఇండియా (SBI)',
    accountEnding: 'ఆధార్ లింక్డ్ ఖాతా నంబర్ •••• 4012',
    utrNumber: 'NPCI UTR నంబర్: UTR-202609099412',
    zeroCashNotice: 'నగదు రహిత రక్షణ: దళారీకి ఎటువంటి కమీషన్ ఇవ్వనక్కర్లేదు.',
    produceTrackerTitle: 'మీ పంట ప్రయాణ ట్రాకర్ (లైవ్ స్టేటస్)',
    step1: 'బుకింగ్ నమోదైంది',
    step1Sub: 'తాడికొండ సేవా కేంద్రం వద్ద నమోదు',
    step2: '2-టన్నుల లారీ కేటాయించబడింది',
    step2Sub: 'డ్రైవర్: జి. వెంకటేశ్ (AP 07 TJ 3401)',
    step3: 'గ్రామంలో డిజిటల్ తూకం పూర్తయింది',
    step3Sub: '420 కేజీలు నాణ్యత ధృవీకరించబడింది',
    step4: 'డబ్బు మీ బ్యాంక్ లో పడింది',
    step4Sub: '₹91,560 DBT ద్వారా జమ అయింది',
    callHelpdesk: 'సహాయం కోసం టోల్ ఫ్రీ కి కాల్ చేయండి: 1800-425-1515',
    aiAssistantTitle: 'రైతు AI మిత్ర',
    aiAssistantSubtitle: 'మీ సొంత భాషలో అడగండి',
    askAnythingPrompt: 'ధరలు, రవాణా లేదా చెల్లింపు గురించి అడగండి...',
    typeOrSpeak: 'ఇక్కడ టైప్ చేయండి...',
    sendBtn: 'పంపు',
    whatsAppBotTitle: 'వాట్సాప్ వాయిస్ అసిస్టెంట్',
    whatsAppBotSubtitle: 'వాట్సాప్ లో ఆడియో మెసేజ్ తో పంట రవాణా బుకింగ్',
    listenToVoiceNote: 'వాయిస్ నోట్ వినండి',
    voiceNotePlaying: 'వాయిస్ నోట్ ప్లే అవుతోంది...',
    switchLanguage: 'భాష మార్చండి:',
    // Farmer Search
    searchByAadhaar: 'ఆధార్ నంబర్ తో రైతును వెతకండి',
    enterAadhaarPrompt: '12 అంకెల ఆధార్ నంబర్ నమోదు చేయండి',
    aadhaarLabel: 'ఆధార్ నంబర్ (12 అంకెలు)',
    aadhaarPlaceholder: 'ఉదా: 9876 0000 4012',
    searchBtn: 'వెతకండి',
    farmerFound: 'రైతు నమోదు కనుగొనబడింది',
    farmerNotFound: 'రైతు నమోదు కనుగొనబడలేదు',
    registerNewFarmer: 'కొత్త రైతును నమోదు చేయండి',
    confirmIdentity: 'గుర్తింపు ధృవీకరించండి',
    confirmNamePrompt: 'రైతు పూర్తి పేరు నిర్ధారించండి:',
    confirmVillagePrompt: 'రైతు గ్రామం నిర్ధారించండి:',
    confirmPhonePrompt: 'మొబైల్ నంబర్ చివరి 4 అంకెలు నిర్ధారించండి:',
    identityConfirmed: 'గుర్తింపు ధృవీకరించబడింది! ఆర్డర్ ప్రక్రియ కొనసాగించండి.',
    identityFailed: 'వివరాలు సరిపోలడం లేదు. దయచేసి తిరిగి ప్రయత్నించండి.',
    proceedToOrder: 'ఆర్డర్ నమోదు చేయండి',
    farmerName: 'రైతు పేరు',
    farmerPhone: 'మొబైల్ నంబర్',
    farmerVillage: 'గ్రామం',
    farmerBank: 'బ్యాంక్ పేరు',
    farmerAccountLast4: 'ఖాతా నంబర్ చివరి 4 అంకెలు',
    farmerLanguage: 'ఇష్టమైన భాష',
    saveAndRegister: 'నమోదు చేసి ఆర్డర్ కు వెళ్ళండి',
    farmerRegistered: 'రైతు విజయవంతంగా నమోదైయ్యాడు!',
    // History
    myOrders: 'నా ఆర్డర్లు',
    orderHistory: 'ఆర్డర్ చరిత్ర',
    noOrdersYet: 'ఇంకా ఆర్డర్లు లేవు.',
    orderId: 'ఆర్డర్ ID',
    orderDate: 'తేదీ',
    cropName: 'పంట',
    quantity: 'పరిమాణం',
    totalPayout: 'మొత్తం విలువ',
    status: 'స్థితి',
    statusScheduled: 'షెడ్యూల్ అయింది',
    statusInTransit: 'లారీ మార్గంలో',
    statusWeighed: 'తూకం పూర్తయింది',
    statusPaid: 'బ్యాంక్ లో జమ అయింది',
    viewSlip: 'రశీదు చూడండి',
    // Navigation
    back: 'వెనక్కు',
    home: 'హోమ్',
    menu: 'మెను',
    // Mode selection
    selectMode: 'మీ విభాగాన్ని ఎంచుకోండి',
    kisanMode: 'కిసాన్ మోడ్',
    operatorMode2: 'ఆపరేటర్ మోడ్',
    buyerMode: 'కొనుగోలుదారు మోడ్',
    ivrMode: 'కీప్యాడ్ ఫోన్ IVR',
    adminMode: 'జిల్లా అడ్మిన్',
    enterKisanMode: 'కిసాన్ మోడ్ లోకి వెళ్ళండి',
    enterOperatorMode: 'ఆపరేటర్ మోడ్ లోకి వెళ్ళండి',
    enterBuyerMode: 'కొనుగోలుదారు మోడ్ లోకి వెళ్ళండి',
    enterIvrMode: 'IVR సిమ్యులేటర్ లోకి వెళ్ళండి',
    enterAdminMode: 'అడ్మిన్ పోర్టల్ లోకి వెళ్ళండి',
    crops: {
      chilli: 'గుంటూరు తేజ మిర్చి',
      cotton: 'శంకర్-6 దూది (పత్తి)',
      turmeric: 'దుగ్గిరాల పసుపు',
      maize: 'మొక్కజొన్న',
    },
    sampleQuestions: [
      'ఈరోజు మిర్చి ధర ఎంత?',
      'నా గ్రామానికి లారీ ఎప్పుడు వస్తుంది?',
      'నా బ్యాంక్ ఖాతాకు డబ్బులు పడ్డాయా?',
      'కనీస రక్షణ ధర ఎంత?',
    ],
  },
  hi: {
    appName: 'एग्रोरूट किसान सेतु',
    subTitle: 'आंध्र प्रदेश किसानों के लिए सीधी मंडी सेवा (गुंटूर - विजयवाड़ा)',
    operatorMode: 'VLE / ऑपरेटर पोर्टल',
    farmerMode: 'किसान मोड (किसान सेवाएं)',
    todayMandiPrice: 'आज का गुंटूर मंडी गारंटीकृत भाव',
    perKg: 'प्रति किलो',
    perQuintal: 'प्रति क्विंटल',
    floorProtected: 'सरकारी न्यूनतम मूल्य से ₹18 अधिक! आज बेचना फायदेमंद है।',
    listenAudio: 'सुनें',
    speaking: 'सुनाई दे रहा है...',
    stopAudio: 'रोकें',
    bookPickupTitle: 'अपने गांव में सीधी पिकअप गाड़ी बुक करें',
    bookPickupSubtitle: 'बिना बिचौलियों के गांव पर सही तौल और तुरंत भुगतान',
    selectCrop: 'फसल चुनें:',
    howManyBags: 'कितनी बोरियां हैं?',
    bags: 'बोरियां',
    approxWeight: 'अनुमानित वजन',
    enterYieldQuantity: 'फसल की मात्रा दर्ज करें:',
    selectWeightUnit: 'वजन की इकाई:',
    totalCalculatedWeight: 'कुल शुद्ध वजन',
    estimatedPayout: 'अनुमानित कुल भुगतान',
    allCropsDropdownLabel: 'सभी फसलों की सूची:',
    cropCategoryLabel: 'श्रेणी',
    quickSelectCrop: 'त्वरित चयन:',
    yieldQuantityPlaceholder: 'मात्रा दर्ज करें',
    selectVillage: 'अपना गांव चुनें:',
    bookPickupBtn: 'गाड़ी बुलाएं',
    bookingSuccess: 'पिकअप गाड़ी सफलतापूर्वक बुक हो गई! LCV-01 रवाना हो चुकी है।',
    myMoneyTitle: 'मेरी बैंक जमा रसीद',
    myMoneySubtitle: 'आधार DBT द्वारा सीधा भुगतान',
    dbtTransferDone: 'पैसा आपके बैंक खाते में जमा हो चुका है!',
    depositedTo: 'भारतीय स्टेट बैंक (SBI)',
    accountEnding: 'आधार लिंक खाता अंतिम अंक •••• 4012',
    utrNumber: 'NPCI UTR संख्या: UTR-202609099412',
    zeroCashNotice: 'कैशलेस सुरक्षा: किसी बिचौलिए को कोई नकद कमीशन न दें।',
    produceTrackerTitle: 'आपकी उपज का लाइव ट्रैकर',
    step1: 'बुकिंग दर्ज हुई',
    step1Sub: 'ताडिकोंडा केंद्र पर दर्ज',
    step2: '2-टन गाड़ी रवाना',
    step2Sub: 'चालक: जी. वेंकटेश (AP 07 TJ 3401)',
    step3: 'गांव में तौल और गुणवत्ता जांच पूरी',
    step3Sub: '420 किलो सही तौल सत्यापित',
    step4: 'पैसा बैंक खाते में पहुंच गया',
    step4Sub: '₹91,560 DBT द्वारा जमा',
    callHelpdesk: 'किसान सहायता नंबर: 1800-425-1515 पर कॉल करें',
    aiAssistantTitle: 'किसान AI साथी',
    aiAssistantSubtitle: 'अपनी भाषा में पूछें',
    askAnythingPrompt: 'भाव, गाड़ी या भुगतान के बारे में पूछें...',
    typeOrSpeak: 'यहाँ लिखें...',
    sendBtn: 'भेजें',
    whatsAppBotTitle: 'व्हाट्सएप वॉइस असिस्टेंट',
    whatsAppBotSubtitle: 'व्हाट्सएप पर वॉइस मैसेज भेजकर गाड़ी बुक करें',
    listenToVoiceNote: 'वॉइस नोट सुनें',
    voiceNotePlaying: 'वॉइस नोट चल रहा है...',
    switchLanguage: 'भाषा बदलें:',
    // Farmer Search
    searchByAadhaar: 'आधार नंबर से किसान खोजें',
    enterAadhaarPrompt: '12 अंकों का आधार नंबर दर्ज करें',
    aadhaarLabel: 'आधार नंबर (12 अंक)',
    aadhaarPlaceholder: 'उदा: 9876 0000 4012',
    searchBtn: 'खोजें',
    farmerFound: 'किसान पंजीकरण मिला',
    farmerNotFound: 'किसान पंजीकरण नहीं मिला',
    registerNewFarmer: 'नया किसान पंजीकृत करें',
    confirmIdentity: 'पहचान की पुष्टि करें',
    confirmNamePrompt: 'किसान का पूरा नाम पुष्टि करें:',
    confirmVillagePrompt: 'किसान का गांव पुष्टि करें:',
    confirmPhonePrompt: 'मोबाइल नंबर के अंतिम 4 अंक पुष्टि करें:',
    identityConfirmed: 'पहचान सत्यापित! ऑर्डर प्रक्रिया जारी रखें।',
    identityFailed: 'विवरण मेल नहीं खाते। कृपया पुनः प्रयास करें।',
    proceedToOrder: 'ऑर्डर दर्ज करें',
    farmerName: 'किसान का नाम',
    farmerPhone: 'मोबाइल नंबर',
    farmerVillage: 'गांव',
    farmerBank: 'बैंक का नाम',
    farmerAccountLast4: 'खाता नंबर के अंतिम 4 अंक',
    farmerLanguage: 'पसंदीदा भाषा',
    saveAndRegister: 'पंजीकृत करें और ऑर्डर पर जाएं',
    farmerRegistered: 'किसान सफलतापूर्वक पंजीकृत हो गया!',
    // History
    myOrders: 'मेरे ऑर्डर',
    orderHistory: 'ऑर्डर इतिहास',
    noOrdersYet: 'अभी तक कोई ऑर्डर नहीं।',
    orderId: 'ऑर्डर ID',
    orderDate: 'तारीख',
    cropName: 'फसल',
    quantity: 'मात्रा',
    totalPayout: 'कुल राशि',
    status: 'स्थिति',
    statusScheduled: 'निर्धारित',
    statusInTransit: 'गाड़ी रास्ते में',
    statusWeighed: 'तौल पूरी',
    statusPaid: 'बैंक में जमा',
    viewSlip: 'रसीद देखें',
    // Navigation
    back: 'वापस',
    home: 'होम',
    menu: 'मेनू',
    // Mode selection
    selectMode: 'अपना विभाग चुनें',
    kisanMode: 'किसान मोड',
    operatorMode2: 'ऑपरेटर मोड',
    buyerMode: 'खरीदार मोड',
    ivrMode: 'कीपैड फोन IVR',
    adminMode: 'जिला एडमिन',
    enterKisanMode: 'किसान मोड में जाएं',
    enterOperatorMode: 'ऑपरेटर मोड में जाएं',
    enterBuyerMode: 'खरीदार मोड में जाएं',
    enterIvrMode: 'IVR सिमुलेटर में जाएं',
    enterAdminMode: 'एडमिन पोर्टल में जाएं',
    crops: {
      chilli: 'गुंटूर तेजा लाल मिर्च',
      cotton: 'शंकर-6 कपास',
      turmeric: 'हल्दी',
      maize: 'मक्का',
    },
    sampleQuestions: [
      'आज मिर्च का भाव क्या है?',
      'मेरे गांव में पिकअप ट्रक कब पहुंचेगा?',
      'क्या मेरा पैसा बैंक खाते में आ गया है?',
      'न्यूनतम मूल्य सुरक्षा क्या है?',
    ],
  },
  en: {
    appName: 'AgroRoute Kisan Setu',
    subTitle: 'Direct Mandi & First-Mile Logistics for Smallholders (Guntur - Vijayawada)',
    operatorMode: 'VLE / Operator Portal',
    farmerMode: 'Kisan Mode (Farmer Services)',
    todayMandiPrice: "Today's Guaranteed Mandi Price",
    perKg: 'per kg',
    perQuintal: 'per quintal',
    floorProtected: '₹18 above distress floor. Good time to sell without middlemen.',
    listenAudio: 'Listen',
    speaking: 'Speaking...',
    stopAudio: 'Stop',
    bookPickupTitle: 'Book Doorstep Vehicle Pickup',
    bookPickupSubtitle: 'Zero middlemen, digital weighment, and direct bank credit',
    selectCrop: 'Select Crop:',
    howManyBags: 'How many bags do you have?',
    bags: 'Bags',
    approxWeight: 'Estimated Weight',
    enterYieldQuantity: 'Enter Crop Yield Quantity:',
    selectWeightUnit: 'Select Unit of Measurement:',
    totalCalculatedWeight: 'Total Net Weight',
    estimatedPayout: 'Estimated Total Payout',
    allCropsDropdownLabel: 'All Crops List:',
    cropCategoryLabel: 'Category',
    quickSelectCrop: 'Quick Select:',
    yieldQuantityPlaceholder: 'Enter quantity',
    selectVillage: 'Select Village:',
    bookPickupBtn: 'Request Pickup Vehicle',
    bookingSuccess: 'Pickup vehicle booked! 2-Ton LCV-01 dispatched to your village.',
    myMoneyTitle: 'My Bank Deposit & Receipt',
    myMoneySubtitle: 'Aadhaar Direct Benefit Transfer (DBT)',
    dbtTransferDone: 'Payment successfully credited to your bank account!',
    depositedTo: 'State Bank of India (SBI)',
    accountEnding: 'Aadhaar-seeded A/C ending in •••• 4012',
    utrNumber: 'NPCI UTR Ref: UTR-202609099412',
    zeroCashNotice: 'Zero Cash Protocol: No intermediary cuts or cash deductions.',
    produceTrackerTitle: 'Your Produce Journey Tracker (Live Status)',
    step1: 'Pickup Booked',
    step1Sub: 'Logged at Tadikonda Village CSC',
    step2: '2-Ton LCV Dispatched',
    step2Sub: 'Driver: G. Venkatesh (AP 07 TJ 3401)',
    step3: 'Gate Weighed & Quality Verified',
    step3Sub: '420 KG verified on digital scales',
    step4: 'Money in Bank Account',
    step4Sub: '₹91,560 credited via Aadhaar DBT',
    callHelpdesk: 'Toll-Free Kisan Helpdesk: 1800-425-1515',
    aiAssistantTitle: 'Kisan AI Saathi',
    aiAssistantSubtitle: 'Ask in your language by voice or text',
    askAnythingPrompt: 'Ask about prices, pickup, or bank payments...',
    typeOrSpeak: 'Type your question here...',
    sendBtn: 'Send',
    whatsAppBotTitle: 'WhatsApp Voice Assistant',
    whatsAppBotSubtitle: 'Book pickup via a voice note on WhatsApp',
    listenToVoiceNote: 'Listen to Voice Note',
    voiceNotePlaying: 'Playing voice note...',
    switchLanguage: 'Language:',
    // Farmer Search
    searchByAadhaar: 'Search Farmer by Aadhaar Number',
    enterAadhaarPrompt: 'Enter 12-digit Aadhaar number',
    aadhaarLabel: 'Aadhaar Number (12 digits)',
    aadhaarPlaceholder: 'e.g. 9876 0000 4012',
    searchBtn: 'Search',
    farmerFound: 'Farmer Registration Found',
    farmerNotFound: 'Farmer Not Registered',
    registerNewFarmer: 'Register New Farmer',
    confirmIdentity: 'Confirm Farmer Identity',
    confirmNamePrompt: 'Confirm farmer full name:',
    confirmVillagePrompt: 'Confirm farmer village:',
    confirmPhonePrompt: 'Confirm last 4 digits of mobile number:',
    identityConfirmed: 'Identity Verified! Proceed to place the order.',
    identityFailed: 'Details do not match. Please try again.',
    proceedToOrder: 'Proceed to Order',
    farmerName: 'Farmer Name',
    farmerPhone: 'Mobile Number',
    farmerVillage: 'Village',
    farmerBank: 'Bank Name',
    farmerAccountLast4: 'Account Last 4 Digits',
    farmerLanguage: 'Preferred Language',
    saveAndRegister: 'Register & Proceed to Order',
    farmerRegistered: 'Farmer registered successfully!',
    // History
    myOrders: 'My Orders',
    orderHistory: 'Order History',
    noOrdersYet: 'No orders yet.',
    orderId: 'Order ID',
    orderDate: 'Date',
    cropName: 'Crop',
    quantity: 'Quantity',
    totalPayout: 'Total Value',
    status: 'Status',
    statusScheduled: 'Scheduled',
    statusInTransit: 'Truck En Route',
    statusWeighed: 'Weighed at APMC',
    statusPaid: 'Bank Credited',
    viewSlip: 'View Slip',
    // Navigation
    back: 'Back',
    home: 'Home',
    menu: 'Menu',
    // Mode selection
    selectMode: 'Select Your Mode',
    kisanMode: 'Kisan Mode',
    operatorMode2: 'Operator Mode',
    buyerMode: 'Buyer Mode',
    ivrMode: 'Keypad Phone IVR',
    adminMode: 'District Admin',
    enterKisanMode: 'Enter Kisan Mode',
    enterOperatorMode: 'Enter Operator Mode',
    enterBuyerMode: 'Enter Buyer Mode',
    enterIvrMode: 'Enter IVR Simulator',
    enterAdminMode: 'Enter Admin Portal',
    crops: {
      chilli: 'Guntur Teja Chilli',
      cotton: 'Shankar-6 Cotton',
      turmeric: 'Duggirala Turmeric',
      maize: 'Yellow Maize',
    },
    sampleQuestions: [
      'What is the chilli price today?',
      'When will the truck arrive at my village?',
      'Has my money been sent to my bank?',
      'What is the price floor protection?',
    ],
  },
};
