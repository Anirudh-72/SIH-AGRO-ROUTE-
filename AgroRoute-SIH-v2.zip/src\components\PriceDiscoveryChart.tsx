import React, { useState } from 'react';
import { PricePoint } from '../types';
import { ShieldCheck, TrendingUp, AlertTriangle, Calendar } from 'lucide-react';

interface PriceDiscoveryChartProps {
  data: PricePoint[];
  commodity: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton';
  onCommodityChange: (c: 'Guntur Teja Mirchi' | 'Shankar-6 Cotton') => void;
}

export const PriceDiscoveryChart: React.FC<PriceDiscoveryChartProps> = ({
  data,
  commodity,
  onCommodityChange,
}) => {
  const [hoveredPoint, setHoveredPoint] = useState<PricePoint | null>(null);

  const latest = data[data.length - 1];
  const previous = data[data.length - 2] || latest;
  const spotChange = latest.daily_modal_price - previous.daily_modal_price;

  // Chart coordinate mapping
  const width = 800;
  const height = 320;
  const padding = { top: 20, right: 30, bottom: 40, left: 60 };

  const prices = data.flatMap((d) => [d.daily_modal_price, d.rolling_avg_7d, d.distress_floor]);
  const minPrice = Math.floor(Math.min(...prices) * 0.98);
  const maxPrice = Math.ceil(Math.max(...prices) * 1.02);

  const getX = (index: number) => {
    return padding.left + (index / (data.length - 1)) * (width - padding.left - padding.right);
  };

  const getY = (val: number) => {
    return height - padding.bottom - ((val - minPrice) / (maxPrice - minPrice)) * (height - padding.top - padding.bottom);
  };

  // Paths
  const spotPath = data.reduce(
    (acc, d, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.daily_modal_price)}`,
    ''
  );

  const rollingPath = data.reduce(
    (acc, d, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.rolling_avg_7d)}`,
    ''
  );

  const floorPath = data.reduce(
    (acc, d, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.distress_floor)}`,
    ''
  );

  // Area under distress floor
  const floorAreaPath = `${floorPath} L ${getX(data.length - 1)} ${height - padding.bottom} L ${getX(0)} ${
    height - padding.bottom
  } Z`;

  // Y-axis ticks
  const yTickCount = 5;
  const yTicks = Array.from({ length: yTickCount }, (_, i) => {
    return Math.round(minPrice + (i / (yTickCount - 1)) * (maxPrice - minPrice));
  });

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Header & Controls */}
      <div className="p-5 border-b border-gray-100 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5" />
              Agmarknet Mandi API Grounding
            </span>
            <span className="text-xs text-gray-500 font-medium">• Guntur & Krishna Mandis</span>
          </div>
          <h3 className="text-base font-bold text-gray-900">
            Price Discovery & Anti-Distress Floor Protection
          </h3>
          <p className="text-xs text-gray-500">
            Enforces a 7-day rolling average price floor. Buyer bids below the threshold are blocked to prevent distress dumps.
          </p>
        </div>

        {/* Commodity Toggle */}
        <div className="inline-flex rounded-lg border border-gray-200 p-1 bg-gray-50">
          <button
            onClick={() => onCommodityChange('Guntur Teja Mirchi')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
              commodity === 'Guntur Teja Mirchi'
                ? 'bg-white text-gray-900 shadow-xs'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            🌶️ Guntur Teja Mirchi
          </button>
          <button
            onClick={() => onCommodityChange('Shankar-6 Cotton')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
              commodity === 'Shankar-6 Cotton'
                ? 'bg-white text-gray-900 shadow-xs'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            🌱 Shankar-6 Cotton
          </button>
        </div>
      </div>

      {/* Metric Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 px-5 py-4 bg-gray-50/50 border-b border-gray-100">
        <div>
          <div className="text-[11px] font-medium text-gray-500 uppercase tracking-wider">
            Latest Mandi Modal
          </div>
          <div className="text-lg font-extrabold text-gray-900">
            ₹{latest.daily_modal_price.toLocaleString('en-IN')}{' '}
            <span className="text-xs font-medium text-gray-500">/ qtl</span>
          </div>
          <div
            className={`text-xs font-semibold flex items-center gap-0.5 ${
              spotChange >= 0 ? 'text-emerald-600' : 'text-red-500'
            }`}
          >
            {spotChange >= 0 ? '▲' : '▼'} ₹{Math.abs(spotChange)} vs yesterday
          </div>
        </div>

        <div>
          <div className="text-[11px] font-medium text-gray-500 uppercase tracking-wider">
            7-Day Rolling Benchmark
          </div>
          <div className="text-lg font-extrabold text-sky-700">
            ₹{latest.rolling_avg_7d.toLocaleString('en-IN')}{' '}
            <span className="text-xs font-medium text-gray-500">/ qtl</span>
          </div>
          <div className="text-xs text-gray-500">Smoothed market trend</div>
        </div>

        <div>
          <div className="text-[11px] font-medium text-gray-500 uppercase tracking-wider">
            Distress Floor (93% MSP+)
          </div>
          <div className="text-lg font-extrabold text-rose-600">
            ₹{latest.distress_floor.toLocaleString('en-IN')}{' '}
            <span className="text-xs font-medium text-gray-500">/ qtl</span>
          </div>
          <div className="text-xs text-rose-700 font-medium">Automatic trade barrier</div>
        </div>

        <div>
          <div className="text-[11px] font-medium text-gray-500 uppercase tracking-wider">
            Safety Shield Status
          </div>
          <div className="text-sm font-bold text-emerald-700 flex items-center gap-1 mt-1">
            <CheckCircleIcon className="w-4 h-4 text-emerald-600" />
            Active Protection
          </div>
          <div className="text-xs text-gray-500">0 Distress bids breached</div>
        </div>
      </div>

      {/* SVG Interactive Chart */}
      <div className="p-4 relative">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[340px] select-none"
        >
          {/* Horizontal Grid lines */}
          {yTicks.map((tick) => {
            const y = getY(tick);
            return (
              <g key={tick}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#F1F5F9"
                  strokeWidth="1"
                />
                <text
                  x={padding.left - 10}
                  y={y + 4}
                  textAnchor="end"
                  fill="#94A3B8"
                  fontSize="10"
                  fontFamily="system-ui"
                >
                  ₹{tick.toLocaleString('en-IN')}
                </text>
              </g>
            );
          })}

          {/* Distress Zone Shading */}
          <path d={floorAreaPath} fill="#FEE2E2" fillOpacity="0.4" />

          {/* Daily Modal Price Line (Dotted Gray) */}
          <path
            d={spotPath}
            fill="none"
            stroke="#94A3B8"
            strokeWidth="1.5"
            strokeDasharray="3,3"
          />

          {/* Distress Floor Line (Red Dash) */}
          <path
            d={floorPath}
            fill="none"
            stroke="#EF4444"
            strokeWidth="2"
            strokeDasharray="4,3"
          />

          {/* 7-Day Rolling Average Line (Solid Cyan/Blue) */}
          <path
            d={rollingPath}
            fill="none"
            stroke="#0284C7"
            strokeWidth="3"
            strokeLinecap="round"
          />

          {/* Interactive Data Points & Hover Area */}
          {data.map((d, i) => {
            const x = getX(i);
            const ySpot = getY(d.daily_modal_price);
            const isHovered = hoveredPoint?.date === d.date;

            return (
              <g key={d.date} onMouseEnter={() => setHoveredPoint(d)} className="cursor-pointer">
                {/* Transparent hit target */}
                <rect
                  x={x - 10}
                  y={padding.top}
                  width="20"
                  height={height - padding.top - padding.bottom}
                  fill="transparent"
                />

                {/* Spot marker */}
                <circle
                  cx={x}
                  cy={ySpot}
                  r={isHovered ? '5' : '3'}
                  fill={isHovered ? '#0284C7' : '#FFFFFF'}
                  stroke="#0284C7"
                  strokeWidth={isHovered ? '2.5' : '1.5'}
                />

                {/* Date labels on X axis for sampled points */}
                {i % 5 === 0 && (
                  <text
                    x={x}
                    y={height - padding.bottom + 18}
                    textAnchor="middle"
                    fill="#64748B"
                    fontSize="10"
                    fontFamily="system-ui"
                  >
                    {d.date}
                  </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* Hover Tooltip */}
        {hoveredPoint && (
          <div className="absolute top-4 right-4 bg-gray-900 text-white p-3 rounded-lg shadow-xl text-xs space-y-1 max-w-[200px] border border-gray-700 pointer-events-none animate-in fade-in">
            <div className="font-bold text-gray-300 pb-1 border-b border-gray-800 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-sky-400" />
              Date: {hoveredPoint.date}
            </div>
            <div className="flex justify-between text-gray-300">
              <span>Spot Modal:</span>
              <strong className="text-white">₹{hoveredPoint.daily_modal_price}</strong>
            </div>
            <div className="flex justify-between text-sky-400">
              <span>7-Day Rolling:</span>
              <strong>₹{hoveredPoint.rolling_avg_7d}</strong>
            </div>
            <div className="flex justify-between text-rose-400">
              <span>Distress Floor:</span>
              <strong>₹{hoveredPoint.distress_floor}</strong>
            </div>
          </div>
        )}

        {/* Chart Legend */}
        <div className="flex flex-wrap items-center justify-center gap-6 mt-3 text-xs text-gray-600">
          <div className="flex items-center gap-2">
            <span className="w-4 h-0.5 bg-gray-400 border-b border-dashed border-gray-500 inline-block" />
            <span>Daily Mandi Modal (₹/qtl)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-5 h-1 bg-sky-600 rounded-full inline-block" />
            <span className="font-medium text-sky-900">7-Day Rolling Average (Trend Benchmark)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-5 h-0.5 bg-rose-500 border-b-2 border-dashed border-rose-500 inline-block" />
            <span className="font-medium text-rose-700">Distress-Sale Protection Floor (Mandatory Minimum)</span>
          </div>
        </div>
      </div>
    </div>
  );
};

function CheckCircleIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  );
}
