import React, { useState } from 'react';
import { LcvVehicle, MatchedContract } from '../types';
import { GUNTUR_APMC_LAT, GUNTUR_APMC_LON, VIJAYAWADA_HUB_LAT, VIJAYAWADA_HUB_LON } from '../data/mockData';
import { MapPin, Truck, Navigation, Layers, Info, CheckCircle2 } from 'lucide-react';

interface FoliumRoutingMapProps {
  lcvVehicles: LcvVehicle[];
  poolingRadiusKm: number;
  allAsks: MatchedContract[];
}

export const FoliumRoutingMap: React.FC<FoliumRoutingMapProps> = ({
  lcvVehicles,
  poolingRadiusKm,
  allAsks,
}) => {
  const [selectedVehicle, setSelectedVehicle] = useState<string | 'all'>('all');
  const [selectedMarker, setSelectedMarker] = useState<any | null>(null);

  // Geographic bounds calculation for Guntur/Vijayawada region
  // Lat range: 16.15 to 16.65, Lon range: 80.32 to 80.68
  const minLat = 16.15;
  const maxLat = 16.68;
  const minLon = 80.30;
  const maxLon = 80.70;

  // Convert GPS (lat, lon) to SVG coordinates (width=800, height=520)
  const mapWidth = 800;
  const mapHeight = 520;

  const projectCoords = (lat: number, lon: number) => {
    const x = ((lon - minLon) / (maxLon - minLon)) * (mapWidth - 80) + 40;
    const y = ((maxLat - lat) / (maxLat - minLat)) * (mapHeight - 80) + 40;
    return { x, y };
  };

  const hubCoord = projectCoords(GUNTUR_APMC_LAT, GUNTUR_APMC_LON);
  const vijayawadaCoord = projectCoords(VIJAYAWADA_HUB_LAT, VIJAYAWADA_HUB_LON);

  // 8km radius in SVG pixels
  // In degrees: 8km is ~0.072 degrees latitude
  const radiusDeg = poolingRadiusKm / 111.0;
  const radiusPx = (radiusDeg / (maxLat - minLat)) * (mapHeight - 80);

  const vehicleColors = ['#0284C7', '#059669', '#D97706', '#7C3AED'];

  const filteredVehicles =
    selectedVehicle === 'all'
      ? lcvVehicles
      : lcvVehicles.filter((v) => v.vehicle_id === selectedVehicle);

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Map Control Bar */}
      <div className="p-4 border-b border-gray-100 flex flex-wrap items-center justify-between gap-4 bg-gray-50/70">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-emerald-100 rounded-md text-emerald-700">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-gray-900">
              Interactive GIS Route Simulator (Folium & Leaflet Engine)
            </h4>
            <p className="text-xs text-gray-500">
              Corridor: Guntur APMC Market Yard ↔ Vijayawada Krishna Basin
            </p>
          </div>
        </div>

        {/* LCV Filter Pills */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-semibold text-gray-500 mr-1">Vehicle Circuit:</span>
          <button
            onClick={() => setSelectedVehicle('all')}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
              selectedVehicle === 'all'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-100'
            }`}
          >
            All Active LCVs ({lcvVehicles.length})
          </button>
          {lcvVehicles.map((v, i) => (
            <button
              key={v.vehicle_id}
              onClick={() => setSelectedVehicle(v.vehicle_id)}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                selectedVehicle === v.vehicle_id
                  ? 'text-white shadow-xs'
                  : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-100'
              }`}
              style={{
                backgroundColor:
                  selectedVehicle === v.vehicle_id ? vehicleColors[i % vehicleColors.length] : undefined,
              }}
            >
              {v.vehicle_id} ({v.utilization_pct}%)
            </button>
          ))}
        </div>
      </div>

      {/* Main Map Visualizer */}
      <div className="relative bg-[#F8FAFC] border-b border-gray-200 overflow-hidden select-none">
        {/* Geographic Base Grid & Waterway representation (Krishna River) */}
        <svg
          viewBox={`0 0 ${mapWidth} ${mapHeight}`}
          className="w-full h-auto max-h-[500px]"
          style={{ background: '#F8FAFC' }}
        >
          <defs>
            <pattern id="gridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#E2E8F0" strokeWidth="0.8" strokeDasharray="2,2" />
            </pattern>
            {/* Krishna River Path (meandering from Amaravati to Vijayawada) */}
            <linearGradient id="riverGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#BAE6FD" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#7DD3FC" stopOpacity="0.9" />
            </linearGradient>
          </defs>

          {/* Background grid */}
          <rect width="100%" height="100%" fill="url(#gridPattern)" />

          {/* Simulated Krishna River corridor */}
          <path
            d="M 120 120 Q 300 150 480 180 T 780 240"
            fill="none"
            stroke="url(#riverGrad)"
            strokeWidth="14"
            strokeLinecap="round"
          />
          <text x="560" y="195" fill="#0284C7" fontSize="10" fontWeight="600" opacity="0.8">
            Krishna River Basin
          </text>

          {/* Highway NH-16 (Kolkata-Chennai corridor connecting Vijayawada & Guntur) */}
          <path
            d={`M ${hubCoord.x} ${hubCoord.y} Q ${(hubCoord.x + vijayawadaCoord.x) / 2 + 10} ${
              (hubCoord.y + vijayawadaCoord.y) / 2 - 10
            } ${vijayawadaCoord.x} ${vijayawadaCoord.y}`}
            fill="none"
            stroke="#CBD5E1"
            strokeWidth="6"
            strokeLinecap="round"
          />
          <path
            d={`M ${hubCoord.x} ${hubCoord.y} Q ${(hubCoord.x + vijayawadaCoord.x) / 2 + 10} ${
              (hubCoord.y + vijayawadaCoord.y) / 2 - 10
            } ${vijayawadaCoord.x} ${vijayawadaCoord.y}`}
            fill="none"
            stroke="#94A3B8"
            strokeWidth="2"
            strokeDasharray="6,4"
          />
          <text
            x={(hubCoord.x + vijayawadaCoord.x) / 2 - 40}
            y={(hubCoord.y + vijayawadaCoord.y) / 2 - 18}
            fill="#64748B"
            fontSize="9"
            fontWeight="700"
          >
            NH-16 EXPRESSWAY CORRIDOR
          </text>

          {/* 8km Haversine Pooling Geofence Circle */}
          <circle
            cx={hubCoord.x}
            cy={hubCoord.y}
            r={radiusPx}
            fill="#10B981"
            fillOpacity="0.08"
            stroke="#059669"
            strokeWidth="2"
            strokeDasharray="4,4"
          />
          <text
            x={hubCoord.x}
            y={hubCoord.y - radiusPx - 8}
            textAnchor="middle"
            fill="#047857"
            fontSize="10"
            fontWeight="700"
          >
            {poolingRadiusKm} km Haversine Aggregation Geofence
          </text>

          {/* Secondary Hub: Vijayawada */}
          <g transform={`translate(${vijayawadaCoord.x}, ${vijayawadaCoord.y})`}>
            <circle cx="0" cy="0" r="14" fill="#E0F2FE" stroke="#0284C7" strokeWidth="1.5" />
            <circle cx="0" cy="0" r="5" fill="#0284C7" />
            <text x="18" y="4" fill="#0369A1" fontSize="11" fontWeight="700">
              Vijayawada Sub-Terminal
            </text>
          </g>

          {/* LCV Aggregated Route Polylines */}
          {filteredVehicles.map((vehicle, vIdx) => {
            const color = vehicleColors[vIdx % vehicleColors.length];
            const routePoints = [hubCoord];

            vehicle.lots.forEach((lot) => {
              routePoints.push(projectCoords(lot.lat, lot.lon));
            });
            // Loop back to destination hub
            routePoints.push(hubCoord);

            const pathString = routePoints.reduce(
              (acc, pt, idx) => `${acc} ${idx === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`,
              ''
            );

            return (
              <g key={vehicle.vehicle_id}>
                {/* Outer Glow */}
                <path
                  d={pathString}
                  fill="none"
                  stroke={color}
                  strokeWidth="6"
                  strokeOpacity="0.25"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                {/* Core Path Line */}
                <path
                  d={pathString}
                  fill="none"
                  stroke={color}
                  strokeWidth="2.8"
                  strokeDasharray="6,4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            );
          })}

          {/* Clustered Farmer Pickup Locations (Green Markers) */}
          {filteredVehicles.map((vehicle, vIdx) =>
            vehicle.lots.map((lot) => {
              const pt = projectCoords(lot.lat, lot.lon);
              const isSelected = selectedMarker?.contract_id === lot.contract_id;

              return (
                <g
                  key={lot.contract_id}
                  transform={`translate(${pt.x}, ${pt.y})`}
                  className="cursor-pointer transition-transform hover:scale-125"
                  onClick={() => setSelectedMarker({ ...lot, vehicle_id: vehicle.vehicle_id })}
                >
                  {/* Pin Drop Pin */}
                  <circle
                    cx="0"
                    cy="0"
                    r={isSelected ? '14' : '10'}
                    fill="#10B981"
                    stroke="#FFFFFF"
                    strokeWidth="2.5"
                    className="filter drop-shadow-md"
                  />
                  <circle cx="0" cy="0" r="4" fill="#047857" />
                  <text
                    x="14"
                    y="4"
                    fill="#064E3B"
                    fontSize="10"
                    fontWeight="700"
                    className="pointer-events-none drop-shadow-xs"
                  >
                    {lot.farmer_name.split(' ')[0]} ({lot.weight_kg}kg)
                  </text>
                </g>
              );
            })
          )}

          {/* Central Destination Buyer Hub (Red Marker) */}
          <g
            transform={`translate(${hubCoord.x}, ${hubCoord.y})`}
            className="cursor-pointer"
            onClick={() =>
              setSelectedMarker({
                type: 'hub',
                name: 'Guntur APMC Yard (Destination Hub)',
                desc: "Asia's largest dry chilli & cotton clearing yard. All 2-ton LCV aggregated routes terminate here for zero-cash weighing.",
              })
            }
          >
            <circle cx="0" cy="0" r="20" fill="#FEE2E2" stroke="#EF4444" strokeWidth="2" />
            <circle cx="0" cy="0" r="10" fill="#EF4444" stroke="#FFFFFF" strokeWidth="2" />
            <rect x="-4" y="-4" width="8" height="8" fill="#FFFFFF" rx="1" />
            <text x="24" y="-6" fill="#991B1B" fontSize="12" fontWeight="800">
              GUNTUR APMC YARD
            </text>
            <text x="24" y="8" fill="#B91C1C" fontSize="9" fontWeight="600">
              Buyer Aggregation Terminal
            </text>
          </g>
        </svg>

        {/* Legend Overlay */}
        <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs p-3 rounded-lg border border-gray-200 shadow-xs text-xs space-y-1.5 max-w-[210px]">
          <div className="font-bold text-gray-800 text-[11px] uppercase tracking-wider mb-1">
            Map Legend
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded-full bg-red-500 border border-white shadow-xs inline-block" />
            <span className="text-gray-700 font-medium">Buyer Delivery Hub (Guntur)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded-full bg-emerald-500 border border-white shadow-xs inline-block" />
            <span className="text-gray-700 font-medium">Farmer Pickups (Green)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-5 h-1 bg-sky-500 border-t border-b border-sky-600 inline-block" />
            <span className="text-gray-700 font-medium">LCV Aggregated Polyline</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded-full bg-emerald-100 border border-emerald-500 border-dashed inline-block" />
            <span className="text-gray-700 font-medium">8km Haversine Geofence</span>
          </div>
        </div>

        {/* Marker Detail Popup */}
        {selectedMarker && (
          <div className="absolute bottom-3 right-3 bg-white p-4 rounded-xl border border-gray-300 shadow-lg text-xs max-w-[280px] animate-in fade-in slide-in-from-bottom-2">
            <div className="flex justify-between items-start mb-2">
              <span className="font-bold text-gray-900 text-sm">
                {selectedMarker.type === 'hub' ? '🏢 ' + selectedMarker.name : '👨‍🌾 ' + selectedMarker.farmer_name}
              </span>
              <button
                onClick={() => setSelectedMarker(null)}
                className="text-gray-400 hover:text-gray-600 font-bold px-1"
              >
                ✕
              </button>
            </div>
            {selectedMarker.type === 'hub' ? (
              <p className="text-gray-600 leading-relaxed">{selectedMarker.desc}</p>
            ) : (
              <div className="space-y-1 text-gray-600">
                <p>
                  Village: <strong className="text-gray-900">{selectedMarker.village}</strong>
                </p>
                <p>
                  Commodity: <strong className="text-gray-900">{selectedMarker.commodity}</strong>
                </p>
                <p>
                  Load Weight: <strong className="text-emerald-700">{selectedMarker.weight_kg} kg</strong>
                </p>
                <p>
                  Clearing Rate: <strong>₹{selectedMarker.clearing_price_qtl}/qtl</strong>
                </p>
                <p>
                  Dispatched in: <span className="text-sky-700 font-bold">{selectedMarker.vehicle_id}</span>
                </p>
                <div className="pt-2 border-t border-gray-100 text-[10px] text-gray-500">
                  GPS: {selectedMarker.lat}, {selectedMarker.lon}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* LCV Fleet Manifest Cards */}
      <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 bg-gray-50/50">
        {filteredVehicles.map((vehicle, i) => (
          <div
            key={vehicle.vehicle_id}
            className="p-3.5 bg-white rounded-lg border border-gray-200 shadow-xs hover:border-emerald-500 transition-colors"
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <span className="font-bold text-gray-900 text-sm flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-emerald-600" />
                  {vehicle.vehicle_id}
                </span>
                <span className="text-xs text-gray-500 font-medium">
                  {vehicle.vehicle_reg} • Driver: {vehicle.driver_name}
                </span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                {vehicle.utilization_pct}% Full
              </span>
            </div>

            {/* Capacity Progress Bar */}
            <div className="w-full bg-gray-100 rounded-full h-2 mb-2 overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{
                  width: `${Math.min(100, vehicle.utilization_pct)}%`,
                  backgroundColor: vehicleColors[i % vehicleColors.length],
                }}
              />
            </div>

            <div className="flex justify-between text-xs text-gray-600 mb-2">
              <span>
                Load: <strong>{vehicle.current_load_kg}</strong> / 2000 kg
              </span>
              <span>
                Cargo: <strong>₹{vehicle.total_val.toLocaleString('en-IN')}</strong>
              </span>
            </div>

            {/* Farmers Packed */}
            <div className="text-[11px] text-gray-500 space-y-0.5 pt-2 border-t border-gray-100">
              <div className="font-semibold text-gray-700">Packed Farmer Lots ({vehicle.lots.length}):</div>
              {vehicle.lots.map((l) => (
                <div key={l.contract_id} className="flex justify-between">
                  <span>
                    • {l.farmer_name} ({l.village})
                  </span>
                  <span className="font-medium text-gray-700">{l.weight_kg} kg</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
