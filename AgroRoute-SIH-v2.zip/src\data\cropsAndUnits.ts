import { SupportedLanguage } from './translations';

export interface CropInfo {
  id: string;
  name: Record<SupportedLanguage, string>;
  icon: string;
  category: 'Spices' | 'Fibre' | 'Cereals' | 'Pulses' | 'Oilseeds' | 'Vegetables' | 'Commercial';
  pricePerQtl: number;
  distressFloor: number;
  defaultUnit: string;
}

export interface WeightUnit {
  id: string;
  name: Record<SupportedLanguage, string>;
  shortCode: string;
  kgMultiplier: number;
  description: Record<SupportedLanguage, string>;
}

export const INDIAN_WEIGHT_UNITS: WeightUnit[] = [
  {
    id: 'quintal',
    shortCode: 'Qtl',
    kgMultiplier: 100,
    name: {
      te: 'క్వింటాల్ (100 కేజీలు)',
      hi: 'क्विंटल (100 किलो)',
      en: 'Quintal (100 kg)',
    },
    description: {
      te: '1 క్వింటాల్ = 100 కేజీలు (మండీ ప్రామాణికం)',
      hi: '1 क्विंटल = 100 किलोग्राम (मंडी मानक)',
      en: '1 Quintal = 100 Kilograms (Standard Mandi unit)',
    },
  },
  {
    id: 'kg',
    shortCode: 'kg',
    kgMultiplier: 1,
    name: {
      te: 'కిలోగ్రామ్ / కేజీ (1 కేజీ)',
      hi: 'किलोग्राम / किलो (1 किलो)',
      en: 'Kilogram / KG (1 kg)',
    },
    description: {
      te: 'ఖచ్చితమైన డిజిటల్ స్కేల్ బరువు',
      hi: 'सटीक डिजिटल तराजू वजन',
      en: 'Exact digital weighbridge weight',
    },
  },
  {
    id: 'bag',
    shortCode: 'Bags',
    kgMultiplier: 50,
    name: {
      te: 'బస్తా / సంచి (50 కేజీలు)',
      hi: 'बोरी / कट्टा (50 किलो)',
      en: 'Standard Bag / Bori (50 kg)',
    },
    description: {
      te: '1 ప్రామాణిక గన్నీ సంచి = 50 కేజీలు',
      hi: '1 मानक जूट बोरी = 50 किलोग्राम',
      en: '1 standard gunny bag = 50 kg',
    },
  },
  {
    id: 'candy',
    shortCode: 'Candy',
    kgMultiplier: 356,
    name: {
      te: 'ఖండీ (356 కేజీలు - పత్తి మండీ)',
      hi: 'खंडी / कैंडी (356 किलो - कपास)',
      en: 'Cotton Candy / Khandi (356 kg)',
    },
    description: {
      te: '1 పత్తి ఖండీ = 356 కేజీలు (CCI మరియు APMC ట్రేడింగ్)',
      hi: '1 कपास खंडी = 356 किलोग्राम (CCI और APMC व्यापार)',
      en: '1 Cotton Candy = 356 kg (CCI / APMC trading standard)',
    },
  },
  {
    id: 'tonne',
    shortCode: 'MT',
    kgMultiplier: 1000,
    name: {
      te: 'మెట్రిక్ టన్ను (1,000 కేజీలు)',
      hi: 'मीट्रिक टन (1,000 किलो)',
      en: 'Metric Tonne (1,000 kg)',
    },
    description: {
      te: '1 టన్ను = 10 క్వింటాళ్లు = 1,000 కేజీలు',
      hi: '1 टन = 10 क्विंटल = 1,000 किलोग्राम',
      en: '1 Metric Ton = 10 Quintals = 1,000 kg',
    },
  },
  {
    id: 'maund',
    shortCode: 'Maund',
    kgMultiplier: 40,
    name: {
      te: 'మణుగు / మన్ (40 కేజీలు)',
      hi: 'मन / मण (40 किलो)',
      en: 'Maund / Man (40 kg)',
    },
    description: {
      te: '1 సాంప్రదాయ మణుగు = 40 కేజీలు',
      hi: '1 पारम्परिक मन = 40 किलोग्राम',
      en: '1 traditional maund = 40 kg',
    },
  },
  {
    id: 'small_katta',
    shortCode: 'Katta',
    kgMultiplier: 25,
    name: {
      te: 'చిన్న కట్టా (25 కేజీలు)',
      hi: 'छोटा कट्टा / पैकेट (25 किलो)',
      en: 'Small Bag / Katta (25 kg)',
    },
    description: {
      te: '1 చిన్న కట్టా = 25 కేజీలు',
      hi: '1 छोटा कट्टा = 25 किलोग्राम',
      en: '1 small pack/bag = 25 kg',
    },
  },
];

export const ALL_CROPS: CropInfo[] = [
  {
    id: 'chilli',
    name: {
      te: 'గుంటూరు తేజ ఎర్ర మిర్చి (Teja Chilli)',
      hi: 'गुंटूर तेजा लाल मिर्च (Teja Chilli)',
      en: 'Guntur Teja Red Chilli',
    },
    icon: '🌶️',
    category: 'Spices',
    pricePerQtl: 21800,
    distressFloor: 20274,
    defaultUnit: 'quintal',
  },
  {
    id: 'cotton',
    name: {
      te: 'శంకర్-6 దూది / పత్తి (Shankar-6 Cotton)',
      hi: 'शंकर-6 कपास / रुई (Cotton)',
      en: 'Shankar-6 Cotton (Kapas)',
    },
    icon: '🌾',
    category: 'Fibre',
    pricePerQtl: 7450,
    distressFloor: 6928,
    defaultUnit: 'quintal',
  },
  {
    id: 'turmeric',
    name: {
      te: 'దుగ్గిరాల పసుపు (Duggirala Turmeric)',
      hi: 'दुग्गिराला हल्दी (Turmeric)',
      en: 'Duggirala Turmeric',
    },
    icon: '🟡',
    category: 'Spices',
    pricePerQtl: 14200,
    distressFloor: 13200,
    defaultUnit: 'quintal',
  },
  {
    id: 'paddy',
    name: {
      te: 'సోనా మసూరి వరి / ధాన్యం (Paddy)',
      hi: 'सोना मसूरी धान / चावल (Paddy)',
      en: 'Sona Masoori Paddy (Grain)',
    },
    icon: '🌾',
    category: 'Cereals',
    pricePerQtl: 2350,
    distressFloor: 2183,
    defaultUnit: 'quintal',
  },
  {
    id: 'maize',
    name: {
      te: 'పసుపు మొక్కజొన్న (Yellow Maize)',
      hi: 'पीला मक्का (Yellow Maize)',
      en: 'Yellow Maize',
    },
    icon: '🌽',
    category: 'Cereals',
    pricePerQtl: 2280,
    distressFloor: 2090,
    defaultUnit: 'quintal',
  },
  {
    id: 'bengal_gram',
    name: {
      te: 'దేశవాళీ శనగలు (Bengal Gram / Chana)',
      hi: 'देसी चना (Bengal Gram / Chana)',
      en: 'Bengal Gram / Desi Chana',
    },
    icon: '🟤',
    category: 'Pulses',
    pricePerQtl: 6100,
    distressFloor: 5670,
    defaultUnit: 'quintal',
  },
  {
    id: 'red_gram',
    name: {
      te: 'కందులు / తూర్ దాల్ (Red Gram / Tur)',
      hi: 'अरहर / तूर दाल (Red Gram)',
      en: 'Red Gram / Tur Dal',
    },
    icon: '🥣',
    category: 'Pulses',
    pricePerQtl: 10400,
    distressFloor: 9672,
    defaultUnit: 'quintal',
  },
  {
    id: 'black_gram',
    name: {
      te: 'మినుములు / ఉరద్ (Black Gram / Urad)',
      hi: 'उड़द दाल (Black Gram / Urad)',
      en: 'Black Gram / Urad',
    },
    icon: '⚫',
    category: 'Pulses',
    pricePerQtl: 8200,
    distressFloor: 7626,
    defaultUnit: 'quintal',
  },
  {
    id: 'green_gram',
    name: {
      te: 'పెసలు / మూంగ్ (Green Gram / Moong)',
      hi: 'मूंग दाल (Green Gram / Moong)',
      en: 'Green Gram / Moong',
    },
    icon: '🟢',
    category: 'Pulses',
    pricePerQtl: 8600,
    distressFloor: 7998,
    defaultUnit: 'quintal',
  },
  {
    id: 'groundnut',
    name: {
      te: 'వేరుశనగ కాయలు (Groundnut pods)',
      hi: 'मूंगफली फली (Groundnut pods)',
      en: 'Groundnut in Shell',
    },
    icon: '🥜',
    category: 'Oilseeds',
    pricePerQtl: 6800,
    distressFloor: 6324,
    defaultUnit: 'quintal',
  },
  {
    id: 'soybean',
    name: {
      te: 'సోయాబీన్ (Soybean)',
      hi: 'सोयाबीन (Soybean)',
      en: 'Yellow Soybean',
    },
    icon: '🌱',
    category: 'Oilseeds',
    pricePerQtl: 4650,
    distressFloor: 4324,
    defaultUnit: 'quintal',
  },
  {
    id: 'tobacco',
    name: {
      te: 'వర్జీనియా పొగాకు (FCV Tobacco)',
      hi: 'वर्जीनिया तम्बाकू (FCV Tobacco)',
      en: 'Virginia Flue-Cured Tobacco',
    },
    icon: '🍂',
    category: 'Commercial',
    pricePerQtl: 18500,
    distressFloor: 17205,
    defaultUnit: 'quintal',
  },
  {
    id: 'onion',
    name: {
      te: 'మంచి ఉల్లిపాయలు (Mandi Onions)',
      hi: 'लाल प्याज (Mandi Onions)',
      en: 'Red Onion (Mandi Grade)',
    },
    icon: '🧅',
    category: 'Vegetables',
    pricePerQtl: 2400,
    distressFloor: 2150,
    defaultUnit: 'quintal',
  },
  {
    id: 'tomato',
    name: {
      te: 'హైబ్రిడ్ టమాటా (Hybrid Tomato)',
      hi: 'हाइब्रिड टमाटर (Hybrid Tomato)',
      en: 'Hybrid Fresh Tomato',
    },
    icon: '🍅',
    category: 'Vegetables',
    pricePerQtl: 1850,
    distressFloor: 1650,
    defaultUnit: 'quintal',
  },
  {
    id: 'jowar',
    name: {
      te: 'తెల్ల జొన్నలు (White Sorghum / Jowar)',
      hi: 'सफेद ज्वार (White Sorghum / Jowar)',
      en: 'White Sorghum / Jowar',
    },
    icon: '🌾',
    category: 'Cereals',
    pricePerQtl: 3180,
    distressFloor: 2950,
    defaultUnit: 'quintal',
  },
  {
    id: 'sugarcane',
    name: {
      te: 'మంచి చెరకు (Sugarcane)',
      hi: 'गन्ना (Sugarcane)',
      en: 'Fresh Sugarcane',
    },
    icon: '🎋',
    category: 'Commercial',
    pricePerQtl: 340,
    distressFloor: 315,
    defaultUnit: 'tonne',
  },
];
