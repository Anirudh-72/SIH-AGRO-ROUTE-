import React, { useState, useEffect, useRef } from 'react';
import { SupportedLanguage, TRANSLATIONS } from '../data/translations';
import { speakVernacularText, stopSpeech } from '../utils/speechUtils';
import {
  X,
  Bot,
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  ArrowRight,
  Globe,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

interface KisanAiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  commodity: string;
}

export const KisanAiAssistantModal: React.FC<KisanAiAssistantModalProps> = ({
  isOpen,
  onClose,
  language,
  onLanguageChange,
  commodity,
}) => {
  const t = TRANSLATIONS[language];
  const [inputText, setInputText] = useState('');
  const [isListeningMic, setIsListeningMic] = useState(false);
  const [activeSpeechId, setActiveSpeechId] = useState<string | null>(null);

  const initialGreeting =
    language === 'te'
      ? `నమస్కారం! నేను మీ రైతు AI మిత్రుడిని. గుంటూరు మార్కెట్ లో ఈరోజు ${commodity} ధరలు, ఉచిత లారీ బుకింగ్ మరియు మీ బ్యాంక్ ఖాతాకు డబ్బుల జమ గురించి ఏదైనా అడగండి.`
      : language === 'hi'
      ? `नमस्ते! मैं आपका किसान AI साथी हूँ। आज गुंटूर मंडी में ${commodity} का भाव, फ्री पिकअप गाड़ी की बुकिंग और बैंक खाते में भुगतान के बारे में कुछ भी पूछें।`
      : `Hello! I am your Kisan AI Saathi. Ask me anything about today's ${commodity} mandi rates, doorstep vehicle booking, or your direct bank transfer.`;

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'bot',
      text: initialGreeting,
      timestamp: 'Just now',
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen) return null;

  // Vernacular Response Generator with operations research & Agmarknet domain knowledge
  const generateBotReply = (query: string, lang: SupportedLanguage): string => {
    const q = query.toLowerCase();

    if (lang === 'te') {
      if (q.includes('తూకం') || q.includes('బరువు') || q.includes('యూనిట్') || q.includes('క్వింటాల్') || q.includes('బస్తా') || q.includes('క్యాండీ') || q.includes('మణుగు') || q.includes('కేజీ')) {
        return `భారతీయ రైతుల తూకం వివరాలు: 1 క్వింటాల్ = 100 కేజీలు; 1 ప్రామాణిక బస్తా = 50 కేజీలు; 1 కాటన్ క్యాండీ = 356 కేజీలు; 1 మణుగు = 40 కేజీలు; 1 మెట్రిక్ టన్ను = 1,000 కేజీలు. మీరు నేరుగా మీ దిగుబడి సంఖ్యను ఎంటర్ చేసి తూకం యూనిట్ సెలెక్ట్ చేసుకోవచ్చు.`;
      }
      if (q.includes('పంట') || q.includes('రకాలు') || q.includes('లిస్ట్') || q.includes('డ్రాప్ డౌన్')) {
        return `మన ప్లాట్‌ఫారమ్‌లో 16 రకాల పంటలు ఉన్నాయి: గుంటూరు మిర్చి, శంకర్-6 పత్తి, పసుపు, వరి, మొక్కజొన్న, శనగలు, వేరుశనగ, పొద్దుతిరుగుడు, టమోటా, ఉల్లి మొదలైనవి. 'పంట ఎంచుకోండి' డ్రాప్‌డౌన్ నుండి మీకు కావలసిన పంటను సులభంగా ఎంచుకోవచ్చు.`;
      }
      if (q.includes('ధర') || q.includes('రేటు') || q.includes('మిర్చి') || q.includes('పత్తి') || q.includes('price')) {
        return `ఈరోజు గుంటూరు APMC యార్డ్ లో క్వింటాల్ కు రూ. 21,800 (కేజీకి రూ. 218). ఇది ప్రభుత్వ కనీస రక్షణ ధర రూ. 20,274 కంటే రూ. 18 ఎక్కువ. ఆక్షన్‌లో నేరుగా పెద్ద కొనుగోలుదారులతో మ్యాచ్ అవుతుంది.`;
      }
      if (q.includes('డబ్బు') || q.includes('ఖాతా') || q.includes('పేమెంట్') || q.includes('payment') || q.includes('money')) {
        return `మీ పంట సొమ్ము ₹91,560 స్టేట్ బ్యాంక్ ఆఫ్ ఇండియా ఖాతా •••• 4012 కు నేరుగా జమ చేయబడింది (NPCI UTR: 202609099412). ఎటువంటి దళారీ కమీషన్ లేదా నగదు తగ్గింపులు లేవు. 100% పారదర్శకం.`;
      }
      if (q.includes('లారీ') || q.includes('వాహనం') || q.includes('బుకింగ్') || q.includes('ట్రక్') || q.includes('truck')) {
        return `మీ తాడికొండ గ్రామానికి LCV-01 (AP 07 TJ 3401) కేటాయించబడింది. డ్రైవర్ జి. వెంకటేశ్ మరో 25 నిమిషాల్లో మీ ఊరి కామన్ సర్వీస్ సెంటర్ వద్దకు చేరుకుంటారు. మీ బస్తాలు సిద్ధంగా ఉంచుకోండి.`;
      }
      if (q.includes('రక్షణ') || q.includes('ఫ్లోర్') || q.includes('కనీస')) {
        return `మా వ్యవస్థ 7 రోజుల సగటు ఆధారంగా 'యాంటీ-డిస్ట్రెస్ ప్రైస్ ఫ్లోర్' అమలు చేస్తుంది. వ్యాపారులు లేదా దళారులు ఈ కనీస ధర కంటే తక్కువ ధరకు కొనడం సాధ్యం కాదు.`;
      }
      return `రైతు సోదరులారా, మీ ప్రశ్న పరిశీలించబడింది. ఈరోజు ధర కేజీకి రూ. 218 గా ఉంది మరియు లారీలు మీ గ్రామంలో సిద్ధంగా ఉన్నాయి. తదుపరి వివరాల కోసం టోల్ ఫ్రీ 1800-425-1515 కు కాల్ చేయవచ్చు.`;
    } else if (lang === 'hi') {
      if (q.includes('वजन') || q.includes('इकाई') || q.includes('क्विंटल') || q.includes('बोरी') || q.includes('खांडी') || q.includes('मन') || q.includes('किलो')) {
        return `भारतीय कृषि वजन इकाइयां: 1 क्विंटल = 100 किलो; 1 मानक बोरी = 50 किलो; 1 कपास खांडी = 356 किलो; 1 मन = 40 किलो; 1 मीट्रिक टन = 1,000 किलो। आप अपनी उपज की मात्रा संख्या में लिखकर इकाई चुन सकते हैं।`;
      }
      if (q.includes('फसल') || q.includes('ड्रॉपडाउन') || q.includes('सूची') || q.includes('किस्म')) {
        return `हमारे प्लेटफॉर्म पर 16 प्रमुख फसलें उपलब्ध हैं: गुंटूर मिर्च, शंकर-6 कपास, हल्दी, धान, मक्का, चना, मूंगफली, सोयाबीन आदि। आप 'सभी फसलें' ड्रॉपडाउन से अपनी पसंद चुन सकते हैं।`;
      }
      if (q.includes('भाव') || q.includes('दाम') || q.includes('रेट') || q.includes('मिर्च') || q.includes('कपास') || q.includes('price')) {
        return `आज गुंटूर मंडी में शुद्ध दर ₹21,800 प्रति क्विंटल (यानी ₹218 प्रति किलो) है। यह सरकारी संकट-रोधी मूल्य ₹20,274 से ₹18 अधिक है। आज अपनी फसल बेचना पूरी तरह सुरक्षित है।`;
      }
      if (q.includes('पैसा') || q.includes('खाता') || q.includes('भुगतान') || q.includes('पेमेंट') || q.includes('money')) {
        return `आपकी फसल का पूरा भुगतान ₹91,560 भारतीय स्टेट बैंक खाता •••• 4012 में सीधे आधार DBT द्वारा जमा हो चुका है। शून्य कमीशन और शून्य कटौती।`;
      }
      if (q.includes('गाड़ी') || q.includes('ट्रक') || q.includes('पिकअप') || q.includes('लॉरी') || q.includes('truck')) {
        return `आपके गांव के लिए 2-टन गाड़ी LCV-01 (AP 07 TJ 3401) रवाना हो चुकी है। चालक श्री जी. वेंकटेश लगभग 25 मिनट में ग्राम केंद्र पर पहुंचेंगे।`;
      }
      if (q.includes('सुरक्षा') || q.includes('फ्लोर') || q.includes('न्यूनतम')) {
        return `हमारा सिस्टम 7 दिनों के औसत मूल्य के आधार पर संकट-रोधी न्यूनतम मूल्य सुरक्षित रखता है। कोई भी खरीदार इस मूल्य से कम में फसल नहीं खरीद सकता।`;
      }
      return `किसान भाई, आपका प्रश्न दर्ज हो गया है। आज का भाव ₹218/किलो है और पिकअप गाड़ियां सक्रिय हैं। अधिक जानकारी के लिए किसान हेल्पलाइन 1800-425-1515 पर कॉल करें।`;
    } else {
      if (q.includes('weight') || q.includes('unit') || q.includes('quintal') || q.includes('bag') || q.includes('candy') || q.includes('maund') || q.includes('kg')) {
        return `Supported Indian Agricultural Weight Units: 1 Quintal = 100 kg; 1 Standard Bag/Bori = 50 kg; 1 Cotton Candy (Khandi) = 356 kg; 1 Maund (Man) = 40 kg; 1 Metric Tonne = 1,000 kg; 1 Small Bag (Katta) = 25 kg. You can directly enter your harvest quantity and choose any unit from the dropdown!`;
      }
      if (q.includes('crop') || q.includes('dropdown') || q.includes('variety') || q.includes('list')) {
        return `Our platform supports 16 regional crops across Spices, Fibre, Cereals, Pulses, Oilseeds, and Vegetables including Guntur Chilli, Shankar-6 Cotton, Salem Turmeric, Sona Masoori Paddy, Maize, Bengal Gram, Groundnut, and more with live Mandi rates.`;
      }
      if (q.includes('price') || q.includes('rate') || q.includes('mandi') || q.includes('chilli') || q.includes('cotton')) {
        return `Today's cleared market rate at Guntur APMC is Rs. 21,800 per quintal (Rs. 218 per kg). This is Rs. 18 higher than the distress floor. Double-auction guarantees optimal cleared value.`;
      }
      if (q.includes('money') || q.includes('payment') || q.includes('bank') || q.includes('dbt')) {
        return `Your payout of Rs. 91,560 has been credited directly to SBI A/C ending in 4012 with UTR ref 202609099412. Zero cash cuts, zero middlemen deductions.`;
      }
      if (q.includes('truck') || q.includes('vehicle') || q.includes('pickup') || q.includes('lcv')) {
        return `2-Ton LCV-01 (AP 07 TJ 3401) driven by G. Venkatesh is en route to Tadikonda and is estimated to arrive in 25 minutes.`;
      }
      return `Thank you for your query. Today's clearing price is Rs. 218/kg with active vehicle dispatches. You can also reach our toll-free kisan helpline at 1800-425-1515.`;
    }
  };

  const handleSend = (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');

    // Generate smart vernacular response
    setTimeout(() => {
      const replyText = generateBotReply(query, language);
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);

      // Automatically speak the response for farmer convenience
      handleSpeakMessage(botMsg.id, replyText);
    }, 600);
  };

  const handleSpeakMessage = (id: string, text: string) => {
    if (activeSpeechId === id) {
      stopSpeech();
      setActiveSpeechId(null);
      return;
    }

    setActiveSpeechId(id);
    speakVernacularText(
      text,
      language,
      () => setActiveSpeechId(id),
      () => setActiveSpeechId(null),
      () => setActiveSpeechId(null)
    );
  };

  // Mic speech simulation / speech recognition
  const handleToggleMic = () => {
    if (isListeningMic) {
      setIsListeningMic(false);
      return;
    }

    setIsListeningMic(true);

    // If browser supports webkitSpeechRecognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      try {
        const SpeechRecognition =
          (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.lang = language === 'te' ? 'te-IN' : language === 'hi' ? 'hi-IN' : 'en-IN';
        recognition.interimResults = false;

        recognition.onresult = (event: any) => {
          const spoken = event.results[0][0].transcript;
          setIsListeningMic(false);
          handleSend(spoken);
        };

        recognition.onerror = () => {
          setIsListeningMic(false);
        };

        recognition.start();
        return;
      } catch (err) {
        console.warn('Speech recognition not available:', err);
      }
    }

    // Fallback simulation if browser blocks mic permission
    setTimeout(() => {
      setIsListeningMic(false);
      const fallbackSpoken =
        language === 'te'
          ? 'ఈరోజు మిర్చి ధర ఎంత?'
          : language === 'hi'
          ? 'आज मिर्च का भाव क्या है?'
          : 'What is the chilli price today?';
      handleSend(fallbackSpoken);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-gray-200 overflow-hidden flex flex-col h-[650px] max-h-[90vh]">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-400 text-emerald-950 flex items-center justify-center font-black">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black">{t.aiAssistantTitle}</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/40 text-emerald-200">
                  Online
                </span>
              </div>
              <p className="text-xs text-emerald-200">{t.aiAssistantSubtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Switcher inside Chat */}
            <div className="flex items-center bg-black/30 p-0.5 rounded-lg text-xs font-bold">
              <button
                onClick={() => onLanguageChange('te')}
                className={`px-2 py-1 rounded ${
                  language === 'te' ? 'bg-emerald-500 text-white' : 'text-gray-300'
                }`}
              >
                తెలుగు
              </button>
              <button
                onClick={() => onLanguageChange('hi')}
                className={`px-2 py-1 rounded ${
                  language === 'hi' ? 'bg-emerald-500 text-white' : 'text-gray-300'
                }`}
              >
                हिंदी
              </button>
              <button
                onClick={() => onLanguageChange('en')}
                className={`px-2 py-1 rounded ${
                  language === 'en' ? 'bg-emerald-500 text-white' : 'text-gray-300'
                }`}
              >
                EN
              </button>
            </div>

            <button
              onClick={() => {
                stopSpeech();
                onClose();
              }}
              className="p-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quick Question Chips */}
        <div className="p-3 bg-gray-50 border-b border-gray-200 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="font-bold text-gray-500 text-[11px] whitespace-nowrap">
            💡 Quick:
          </span>
          {t.sampleQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="px-3 py-1.5 rounded-full bg-white border border-gray-300 text-gray-800 font-semibold hover:bg-emerald-50 hover:border-emerald-400 whitespace-nowrap transition-all shrink-0"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Message Log */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#F8FAFC]">
          {messages.map((msg) => {
            const isBot = msg.sender === 'bot';
            const isSpeaking = activeSpeechId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex items-start gap-2.5 ${isBot ? 'justify-start' : 'justify-end'}`}
              >
                {isBot && (
                  <div className="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center shrink-0 text-xs font-black mt-1">
                    🌱
                  </div>
                )}

                <div
                  className={`max-w-[82%] p-3.5 rounded-2xl text-xs leading-relaxed shadow-xs relative ${
                    isBot
                      ? 'bg-white text-gray-900 border border-gray-200 rounded-tl-xs'
                      : 'bg-emerald-700 text-white rounded-tr-xs'
                  }`}
                >
                  <p>{msg.text}</p>

                  <div className="flex items-center justify-between gap-3 mt-2 pt-1 border-t border-gray-100/30 text-[10px] text-gray-400">
                    <span>{msg.timestamp}</span>
                    {isBot && (
                      <button
                        onClick={() => handleSpeakMessage(msg.id, msg.text)}
                        className={`flex items-center gap-1 font-bold px-2 py-0.5 rounded transition-all ${
                          isSpeaking
                            ? 'bg-amber-100 text-amber-900 animate-pulse'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {isSpeaking ? (
                          <>
                            <VolumeX className="w-3 h-3" />
                            <span>Stop</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3 h-3" />
                            <span>🔊 Listen</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>

                {!isBot && (
                  <div className="w-8 h-8 rounded-full bg-gray-200 text-gray-700 flex items-center justify-center shrink-0 text-xs font-black mt-1">
                    👨‍🌾
                  </div>
                )}
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-gray-200">
          {isListeningMic && (
            <div className="mb-2 p-2 bg-amber-50 border border-amber-300 text-amber-900 rounded-lg text-xs font-bold flex items-center gap-2 animate-pulse">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span>
                {language === 'te'
                  ? 'మీరు మాట్లాడండి, వింటున్నాను...'
                  : language === 'hi'
                  ? 'आप बोलिए, मैं सुन रहा हूँ...'
                  : 'Listening to your voice query...'}
              </span>
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <button
              type="button"
              onClick={handleToggleMic}
              className={`p-2.5 rounded-xl border flex items-center justify-center transition-all ${
                isListeningMic
                  ? 'bg-rose-600 text-white border-rose-600 animate-pulse'
                  : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
              }`}
              title="Speak Query"
            >
              {isListeningMic ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={t.typeOrSpeak}
              className="flex-1 py-2.5 px-3.5 bg-gray-50 border border-gray-300 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-emerald-500 focus:bg-white text-gray-900"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              className="py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <span>{t.sendBtn}</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
