import React from 'react';
import { SupportedLanguage, TRANSLATIONS } from '../data/translations';
import {
  Sprout,
  Building2,
  ShoppingCart,
  PhoneCall,
  Landmark,
  Globe,
  ArrowRight,
} from 'lucide-react';

interface ModeSelectionScreenProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onSelectKisanMode: () => void;
  onSelectOperatorMode: () => void;
  onSelectBuyerMode: () => void;
  onSelectIvrMode: () => void;
  onSelectAdminMode: () => void;
}

export const ModeSelectionScreen: React.FC<ModeSelectionScreenProps> = ({
  language,
  onLanguageChange,
  onSelectKisanMode,
  onSelectOperatorMode,
  onSelectBuyerMode,
  onSelectIvrMode,
  onSelectAdminMode,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <div className="min-h-screen bg-[#F4F6F5] flex flex-col">
      {/* Top Bar */}
      <header className="bg-white border-b border-gray-200 px-5 py-3 flex items-center justify-between shadow-sm">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-700 flex items-center justify-center">
            <Sprout className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-base font-black text-gray-900 tracking-tight">AgroRoute</span>
            <span className="ml-2 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
              APMC Guntur
            </span>
          </div>
        </div>

        {/* Language Switcher */}
        <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl border border-gray-200">
          <Globe className="w-3.5 h-3.5 text-gray-400 ml-1.5" />
          {(['te', 'hi', 'en'] as SupportedLanguage[]).map((lang) => (
            <button
              key={lang}
              onClick={() => onLanguageChange(lang)}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${
                language === lang
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {lang === 'te' ? 'తెలుగు' : lang === 'hi' ? 'हिंदी' : 'English'}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-10 max-w-xl mx-auto w-full">
        {/* Page heading */}
        <div className="text-center mb-10">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">
            Govt. of Andhra Pradesh
          </p>
          <h1 className="text-2xl font-black text-gray-900">{t.selectMode}</h1>
        </div>

        {/* Primary Mode Cards — stacked vertically */}
        <div className="w-full space-y-3">
          {/* Kisan Mode */}
          <button
            id="select-kisan-mode-btn"
            onClick={onSelectKisanMode}
            className="w-full bg-white hover:bg-emerald-50 border-2 border-emerald-500 rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-all active:scale-98 text-left"
          >
            <div className="w-14 h-14 rounded-xl bg-emerald-100 border border-emerald-300 flex items-center justify-center shrink-0">
              <Sprout className="w-7 h-7 text-emerald-700" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-black text-gray-900 text-base">{t.kisanMode}</div>
              <div className="text-xs text-gray-500 font-medium mt-0.5">{t.enterKisanMode}</div>
            </div>
            <ArrowRight className="w-5 h-5 text-emerald-600 shrink-0" />
          </button>

          {/* Operator Mode */}
          <button
            id="select-operator-mode-btn"
            onClick={onSelectOperatorMode}
            className="w-full bg-white hover:bg-sky-50 border-2 border-sky-500 rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-all active:scale-98 text-left"
          >
            <div className="w-14 h-14 rounded-xl bg-sky-100 border border-sky-300 flex items-center justify-center shrink-0">
              <Building2 className="w-7 h-7 text-sky-700" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-black text-gray-900 text-base">{t.operatorMode2}</div>
              <div className="text-xs text-gray-500 font-medium mt-0.5">{t.enterOperatorMode}</div>
            </div>
            <ArrowRight className="w-5 h-5 text-sky-600 shrink-0" />
          </button>

          {/* Buyer Mode */}
          <button
            id="select-buyer-mode-btn"
            onClick={onSelectBuyerMode}
            className="w-full bg-white hover:bg-indigo-50 border-2 border-indigo-500 rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-all active:scale-98 text-left"
          >
            <div className="w-14 h-14 rounded-xl bg-indigo-100 border border-indigo-300 flex items-center justify-center shrink-0">
              <ShoppingCart className="w-7 h-7 text-indigo-700" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-black text-gray-900 text-base">{t.buyerMode}</div>
              <div className="text-xs text-gray-500 font-medium mt-0.5">{t.enterBuyerMode}</div>
            </div>
            <ArrowRight className="w-5 h-5 text-indigo-600 shrink-0" />
          </button>
        </div>

        {/* Secondary Modes */}
        <div className="w-full mt-3 grid grid-cols-2 gap-3">
          <button
            id="select-ivr-mode-btn"
            onClick={onSelectIvrMode}
            className="bg-slate-800 hover:bg-slate-900 text-white rounded-2xl p-4 flex flex-col items-start gap-2 transition-all active:scale-98"
          >
            <PhoneCall className="w-5 h-5 text-emerald-400" />
            <span className="text-sm font-black">{t.ivrMode}</span>
          </button>

          <button
            id="select-admin-mode-btn"
            onClick={onSelectAdminMode}
            className="bg-slate-800 hover:bg-slate-900 text-white rounded-2xl p-4 flex flex-col items-start gap-2 transition-all active:scale-98"
          >
            <Landmark className="w-5 h-5 text-blue-400" />
            <span className="text-sm font-black">{t.adminMode}</span>
          </button>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-3 px-4 text-center">
        <p className="text-xs text-gray-500 font-medium">
          Toll-Free Helpdesk: 1800-425-1515 &nbsp;·&nbsp; Zero-Cash Escrow · APMC Act Compliant
        </p>
      </footer>
    </div>
  );
};
