export interface FarmerOrderRecord {
  orderId: string;
  farmerName: string;
  phone: string;
  aadhaarLast4: string;
  aadhaarFull?: string; // full 12-digit aadhaar for search
  village: string;
  cropId: string;
  cropName: string;
  yieldQuantity: number;
  unit: string;
  netWeightKg: number;
  ratePerQtl: number;
  totalPayout: number;
  bookingTime: string;
  status: 'SCHEDULED' | 'IN_TRANSIT' | 'WEIGHED_AT_APMC' | 'DBT_PAID';
  vehicleId: string;
  driverName: string;
  driverPhone: string;
  bankName: string;
  accountLast4: string;
  utrNumber?: string;
}

export const INITIAL_FARMER_ORDERS: FarmerOrderRecord[] = [
  {
    orderId: 'ORD-APMC-8891',
    farmerName: 'K. Venkateswara Rao',
    phone: '98480 12345',
    aadhaarLast4: '4012',
    aadhaarFull: '987600004012',
    village: 'Tadikonda',
    cropId: 'chilli',
    cropName: 'Guntur Teja Chilli',
    yieldQuantity: 10,
    unit: 'Quintal',
    netWeightKg: 1000,
    ratePerQtl: 21800,
    totalPayout: 218000,
    bookingTime: 'Today, 08:30 AM',
    status: 'IN_TRANSIT',
    vehicleId: 'AP 07 TJ 3401 (2-Ton LCV-01)',
    driverName: 'G. Venkatesh',
    driverPhone: '94401 55667',
    bankName: 'State Bank of India (SBI)',
    accountLast4: '4012',
  },
  {
    orderId: 'ORD-APMC-8889',
    farmerName: 'V. Sambasiva Rao',
    phone: '98480 44321',
    aadhaarLast4: '8834',
    aadhaarFull: '876500008834',
    village: 'Tadikonda',
    cropId: 'chilli',
    cropName: 'Guntur Teja Chilli',
    yieldQuantity: 4.2,
    unit: 'Quintal',
    netWeightKg: 420,
    ratePerQtl: 21800,
    totalPayout: 91560,
    bookingTime: 'Yesterday, 11:20 AM',
    status: 'DBT_PAID',
    vehicleId: 'AP 07 TA 2024 (2-Ton LCV-02)',
    driverName: 'K. Rambabu',
    driverPhone: '98491 88990',
    bankName: 'Andhra Pragathi Grameena Bank',
    accountLast4: '8834',
    utrNumber: 'NPCI-UTR-202609099412',
  },
  {
    orderId: 'ORD-APMC-8884',
    farmerName: 'K. Venkata Reddy',
    phone: '98491 66778',
    aadhaarLast4: '1902',
    aadhaarFull: '765400001902',
    village: 'Mangalagiri',
    cropId: 'cotton',
    cropName: 'Shankar-6 Cotton',
    yieldQuantity: 12,
    unit: 'Bags',
    netWeightKg: 600,
    ratePerQtl: 7450,
    totalPayout: 44700,
    bookingTime: 'Yesterday, 03:45 PM',
    status: 'DBT_PAID',
    vehicleId: 'AP 07 TJ 3401 (2-Ton LCV-01)',
    driverName: 'G. Venkatesh',
    driverPhone: '94401 55667',
    bankName: 'Union Bank of India',
    accountLast4: '1902',
    utrNumber: 'NPCI-UTR-202609098901',
  },
  {
    orderId: 'ORD-APMC-8879',
    farmerName: 'M. Subrahmanyam',
    phone: '94402 33445',
    aadhaarLast4: '5561',
    aadhaarFull: '654300005561',
    village: 'Pedakakani',
    cropId: 'turmeric',
    cropName: 'Duggirala Turmeric',
    yieldQuantity: 6.8,
    unit: 'Quintal',
    netWeightKg: 680,
    ratePerQtl: 14200,
    totalPayout: 96560,
    bookingTime: '08 Sep 2026, 10:15 AM',
    status: 'WEIGHED_AT_APMC',
    vehicleId: 'AP 07 TC 1102 (2-Ton LCV-03)',
    driverName: 'S. Srinivasa Rao',
    driverPhone: '98485 77881',
    bankName: 'Canara Bank',
    accountLast4: '5561',
  },
  {
    orderId: 'ORD-APMC-8871',
    farmerName: 'P. Nageswara Rao',
    phone: '99890 11223',
    aadhaarLast4: '7723',
    aadhaarFull: '543200007723',
    village: 'Amaravati Rural',
    cropId: 'paddy',
    cropName: 'Sona Masoori Paddy',
    yieldQuantity: 30,
    unit: 'Bags',
    netWeightKg: 1500,
    ratePerQtl: 2350,
    totalPayout: 35250,
    bookingTime: '07 Sep 2026, 09:00 AM',
    status: 'DBT_PAID',
    vehicleId: 'AP 07 TA 2024 (2-Ton LCV-02)',
    driverName: 'K. Rambabu',
    driverPhone: '98491 88990',
    bankName: 'State Bank of India (SBI)',
    accountLast4: '7723',
    utrNumber: 'NPCI-UTR-202609071234',
  },
  {
    orderId: 'ORD-APMC-8865',
    farmerName: 'B. Anjaneyulu',
    phone: '98483 99887',
    aadhaarLast4: '3309',
    aadhaarFull: '432100003309',
    village: 'Chebrolu',
    cropId: 'maize',
    cropName: 'Yellow Maize',
    yieldQuantity: 8,
    unit: 'Quintal',
    netWeightKg: 800,
    ratePerQtl: 2280,
    totalPayout: 18240,
    bookingTime: '06 Sep 2026, 02:30 PM',
    status: 'DBT_PAID',
    vehicleId: 'AP 07 TJ 3401 (2-Ton LCV-01)',
    driverName: 'G. Venkatesh',
    driverPhone: '94401 55667',
    bankName: 'Indian Bank',
    accountLast4: '3309',
    utrNumber: 'NPCI-UTR-202609067712',
  },
];
