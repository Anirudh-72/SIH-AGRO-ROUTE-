/// <reference types="vite/client" />
/**
 * Firebase Integration and Resilient Offline Storage Layer for AgroRoute.
 * Handles Firebase Authentication & Cloud Firestore with seamless local persistence
 * fallback so the demo never fails even without network or credentials.
 */

import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  Firestore,
  collection,
  onSnapshot,
  addDoc,
  updateDoc,
  doc,
  getDocs,
  setDoc,
} from 'firebase/firestore';
import {
  getAuth,
  Auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
} from 'firebase/auth';
import {
  FarmerAsk,
  BuyerBid,
  MatchedContract,
  BuyerProfile,
  OperatorProfile,
  FarmerProfile,
  GrievanceRecord,
} from './types';
import {
  INITIAL_FARMER_ASKS,
  INITIAL_BUYER_BIDS,
  GUNTUR_APMC_LAT,
  GUNTUR_APMC_LON,
  VIJAYAWADA_HUB_LAT,
  VIJAYAWADA_HUB_LON,
} from './data/mockData';

// Initial Verified APMC Buyers
export const INITIAL_BUYERS: BuyerProfile[] = [
  {
    buyer_id: 'B-ITC-901',
    business_name: 'ITC Agri-Business Division',
    trader_license: 'APMC-TR-GNT-109',
    gstin: '37AAACI1681G1Z0',
    phone: '98480 11223',
    email: 'itc.guntur@itcagri.in',
    verified: true,
    hub_name: 'Guntur APMC Yard Hub',
    lat: GUNTUR_APMC_LAT,
    lon: GUNTUR_APMC_LON,
    commodities: ['Guntur Teja Mirchi'],
  },
  {
    buyer_id: 'B-MDH-902',
    business_name: 'Mahashian Spices Procurement',
    trader_license: 'APMC-TR-GNT-214',
    gstin: '37AABCM8822F1ZX',
    phone: '98492 33445',
    email: 'procurement@mdhspices.com',
    verified: true,
    hub_name: 'Guntur Cold Storage Cluster',
    lat: 16.3200,
    lon: 80.4500,
    commodities: ['Guntur Teja Mirchi'],
  },
  {
    buyer_id: 'B-TEX-903',
    business_name: 'Coastal Andhra Spinning Mills',
    trader_license: 'APMC-TR-VJA-405',
    gstin: '37AACCC4411K1ZQ',
    phone: '98660 55667',
    email: 'cotton.purchase@coastalmills.in',
    verified: true,
    hub_name: 'Vijayawada Auto Nagar Yard',
    lat: VIJAYAWADA_HUB_LAT,
    lon: VIJAYAWADA_HUB_LON,
    commodities: ['Shankar-6 Cotton'],
  },
];

// Initial Operators
export const INITIAL_OPERATORS: OperatorProfile[] = [
  {
    vle_id: 'VLE-GNT-402',
    center_name: 'Tadikonda Gram Panchayat CSC #402',
    operator_name: 'R. Koteswara Rao',
    phone: '98481 00223',
    email: 'vle.tadikonda@csc.gov.in',
    role: 'VLE',
  },
  {
    vle_id: 'VLE-GNT-105',
    center_name: 'Pedakakani Village Secretariat #105',
    operator_name: 'M. Lakshmi Narayana',
    phone: '94402 11224',
    email: 'vle.pedakakani@csc.gov.in',
    role: 'VLE',
  },
  {
    vle_id: 'ADMIN-GNT-01',
    center_name: 'Guntur District Collectorate APMC Oversight',
    operator_name: 'District Marketing Officer (Guntur)',
    phone: '0863-223400',
    email: 'dmo.guntur@ap.gov.in',
    role: 'District Admin',
  },
];

// Initial Grievances
export const INITIAL_GRIEVANCES: GrievanceRecord[] = [
  {
    grievance_id: 'GRV-2026-081',
    contract_id: 'TXN-AUC-101',
    raised_by: 'farmer',
    party_name: 'V. Sambasiva Rao',
    phone: '98480*****',
    category: 'payment_delay',
    description: 'Bank credit SMS received, but UTR confirmation taking longer than 2 hours.',
    status: 'Resolved',
    resolution_note: 'NPCI IMPS batch cleared successfully. Funds verified in SBI A/C ending in 4102.',
    timestamp: '2026-09-14 11:30:00',
  },
];

// Read environment config
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || import.meta.env.FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || import.meta.env.FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || import.meta.env.FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || import.meta.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || import.meta.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || import.meta.env.FIREBASE_APP_ID,
};

// Check if credentials are meaningfully present
const hasValidFirebaseConfig = Boolean(
  firebaseConfig.apiKey &&
    firebaseConfig.projectId &&
    firebaseConfig.apiKey !== 'MY_FIREBASE_API_KEY' &&
    !firebaseConfig.apiKey.includes('MY_')
);

let app: FirebaseApp | null = null;
let firestoreDb: Firestore | null = null;
let authClient: Auth | null = null;

if (hasValidFirebaseConfig) {
  try {
    app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
    firestoreDb = getFirestore(app);
    authClient = getAuth(app);
  } catch (err) {
    console.warn('Firebase initialization skipped or failed, using local resilient store:', err);
    firestoreDb = null;
    authClient = null;
  }
}

export const isFirebaseLive = Boolean(firestoreDb && authClient);

// =========================================================================
// REACTIVE LOCAL STORAGE & IN-MEMORY STORE (FALLBACK & OFFLINE RESILIENT)
// =========================================================================
const STORAGE_KEYS = {
  ASKS: 'agroroute_farmer_asks_v2',
  BIDS: 'agroroute_buyer_bids_v2',
  BUYERS: 'agroroute_buyers_v2',
  GRIEVANCES: 'agroroute_grievances_v2',
  AUTH_USER: 'agroroute_auth_user_v2',
};

function loadStoredData<T>(key: string, defaultVal: T): T {
  if (typeof window === 'undefined') return defaultVal;
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : defaultVal;
  } catch (e) {
    return defaultVal;
  }
}

function persistData<T>(key: string, val: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {
    // Ignore storage quota limits in demo
  }
}

// In-Memory Reactive State
let localFarmerAsks: FarmerAsk[] = loadStoredData(STORAGE_KEYS.ASKS, INITIAL_FARMER_ASKS);
let localBuyerBids: BuyerBid[] = loadStoredData(STORAGE_KEYS.BIDS, INITIAL_BUYER_BIDS);
let localBuyers: BuyerProfile[] = loadStoredData(STORAGE_KEYS.BUYERS, INITIAL_BUYERS);
let localGrievances: GrievanceRecord[] = loadStoredData(STORAGE_KEYS.GRIEVANCES, INITIAL_GRIEVANCES);

// Listeners for Pub/Sub pattern
type Listener<T> = (data: T) => void;
const askListeners = new Set<Listener<FarmerAsk[]>>();
const bidListeners = new Set<Listener<BuyerBid[]>>();
const buyerListeners = new Set<Listener<BuyerProfile[]>>();
const grievanceListeners = new Set<Listener<GrievanceRecord[]>>();

function notifyAskListeners() {
  persistData(STORAGE_KEYS.ASKS, localFarmerAsks);
  askListeners.forEach((fn) => fn([...localFarmerAsks]));
}

function notifyBidListeners() {
  persistData(STORAGE_KEYS.BIDS, localBuyerBids);
  bidListeners.forEach((fn) => fn([...localBuyerBids]));
}

function notifyBuyerListeners() {
  persistData(STORAGE_KEYS.BUYERS, localBuyers);
  buyerListeners.forEach((fn) => fn([...localBuyers]));
}

function notifyGrievanceListeners() {
  persistData(STORAGE_KEYS.GRIEVANCES, localGrievances);
  grievanceListeners.forEach((fn) => fn([...localGrievances]));
}

// =========================================================================
// PUBLIC API: SUBSCRIPTIONS & CRUD
// =========================================================================

export function subscribeToFarmerAsks(callback: (asks: FarmerAsk[]) => void): () => void {
  callback([...localFarmerAsks]);
  askListeners.add(callback);

  // If live firestore is available, attach live onSnapshot listener
  if (firestoreDb) {
    try {
      const unsub = onSnapshot(collection(firestoreDb, 'farmerAsks'), (snapshot) => {
        const cloudAsks: FarmerAsk[] = [];
        snapshot.forEach((doc) => cloudAsks.push(doc.data() as FarmerAsk));
        if (cloudAsks.length > 0) {
          localFarmerAsks = cloudAsks;
          callback(cloudAsks);
        }
      });
      return () => {
        askListeners.delete(callback);
        unsub();
      };
    } catch (e) {
      console.warn('Firestore snapshot error:', e);
    }
  }

  return () => askListeners.delete(callback);
}

export function subscribeToBuyerBids(callback: (bids: BuyerBid[]) => void): () => void {
  callback([...localBuyerBids]);
  bidListeners.add(callback);

  if (firestoreDb) {
    try {
      const unsub = onSnapshot(collection(firestoreDb, 'buyerBids'), (snapshot) => {
        const cloudBids: BuyerBid[] = [];
        snapshot.forEach((doc) => cloudBids.push(doc.data() as BuyerBid));
        if (cloudBids.length > 0) {
          localBuyerBids = cloudBids;
          callback(cloudBids);
        }
      });
      return () => {
        bidListeners.delete(callback);
        unsub();
      };
    } catch (e) {
      console.warn('Firestore snapshot error:', e);
    }
  }

  return () => bidListeners.delete(callback);
}

export function subscribeToBuyers(callback: (buyers: BuyerProfile[]) => void): () => void {
  callback([...localBuyers]);
  buyerListeners.add(callback);
  return () => buyerListeners.delete(callback);
}

export function subscribeToGrievances(callback: (grvs: GrievanceRecord[]) => void): () => void {
  callback([...localGrievances]);
  grievanceListeners.add(callback);
  return () => grievanceListeners.delete(callback);
}

// Add new Farmer Ask
export async function addFarmerAskRecord(ask: FarmerAsk): Promise<void> {
  localFarmerAsks = [ask, ...localFarmerAsks];
  notifyAskListeners();

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, 'farmerAsks', ask.farmer_id), ask);
    } catch (e) {
      console.warn('Error saving ask to Firestore:', e);
    }
  }
}

// Add new Buyer Bid
export async function addBuyerBidRecord(bid: BuyerBid): Promise<void> {
  localBuyerBids = [bid, ...localBuyerBids];
  notifyBidListeners();

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, 'buyerBids', bid.bid_id), bid);
    } catch (e) {
      console.warn('Error saving bid to Firestore:', e);
    }
  }
}

// Register or update Buyer Profile
export async function registerOrUpdateBuyer(profile: BuyerProfile): Promise<void> {
  const existingIdx = localBuyers.findIndex((b) => b.buyer_id === profile.buyer_id || b.email === profile.email);
  if (existingIdx >= 0) {
    localBuyers[existingIdx] = profile;
  } else {
    localBuyers = [profile, ...localBuyers];
  }
  notifyBuyerListeners();

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, 'buyers', profile.buyer_id), profile);
    } catch (e) {
      console.warn('Error saving buyer to Firestore:', e);
    }
  }
}

// Verify Buyer License (Operator/Admin action)
export function verifyBuyerTraderLicense(buyerId: string): void {
  localBuyers = localBuyers.map((b) => (b.buyer_id === buyerId ? { ...b, verified: true } : b));
  notifyBuyerListeners();
}

// Raise Grievance
export async function submitGrievance(grievance: GrievanceRecord): Promise<void> {
  localGrievances = [grievance, ...localGrievances];
  notifyGrievanceListeners();

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, 'grievances', grievance.grievance_id), grievance);
    } catch (e) {
      console.warn('Error saving grievance to Firestore:', e);
    }
  }
}

// Aliases for convenience
export const saveFarmerAsk = addFarmerAskRecord;
export const saveBuyerBid = addBuyerBidRecord;
export const saveGrievance = submitGrievance;

// Resolve Grievance
export function resolveGrievance(grievanceId: string, resolutionNote: string): void {
  localGrievances = localGrievances.map((g) =>
    g.grievance_id === grievanceId
      ? { ...g, status: 'Resolved', resolution_note: resolutionNote }
      : g
  );
  notifyGrievanceListeners();
}

// Reset Demo Data
export function resetDemoDatabase(): void {
  localFarmerAsks = [...INITIAL_FARMER_ASKS];
  localBuyerBids = [...INITIAL_BUYER_BIDS];
  localBuyers = [...INITIAL_BUYERS];
  localGrievances = [...INITIAL_GRIEVANCES];
  notifyAskListeners();
  notifyBidListeners();
  notifyBuyerListeners();
  notifyGrievanceListeners();
}

// =========================================================================
// AUTHENTICATION CLIENT (PHONE OTP, OPERATOR PIN, BUYER CREDENTIALS)
// =========================================================================

export interface AuthSession {
  role: 'farmer' | 'operator' | 'buyer' | 'admin';
  identifier: string;
  name: string;
  token?: string;
  profile?: any;
}

export function getCurrentStoredSession(): AuthSession | null {
  return loadStoredData<AuthSession | null>(STORAGE_KEYS.AUTH_USER, null);
}

export function setStoredSession(session: AuthSession | null): void {
  persistData(STORAGE_KEYS.AUTH_USER, session);
}

// 1. Farmer Phone Auth Simulation & Verification
export async function sendFarmerPhoneOtp(phone: string): Promise<{ success: boolean; demoOtp: string }> {
  // Simulates instant SMS OTP dispatch via APMC-NPCI gateway
  const demoOtp = '5566';
  return { success: true, demoOtp };
}

export async function verifyFarmerPhoneOtp(
  phone: string,
  otp: string,
  farmerName?: string,
  village?: string
): Promise<{ success: boolean; farmer: FarmerProfile }> {
  if (otp === '5566' || otp === '1234' || otp.length === 4 || otp.length === 6) {
    const profile: FarmerProfile = {
      phone,
      name: farmerName || 'G. Srinivasa Rao',
      village: village || 'Tadikonda',
      preferred_language: 'te',
      bank_account_or_upi: `${phone}@sbi`,
      aadhaar_ref: 'XXXX-XXXX-4102',
    };
    setStoredSession({
      role: 'farmer',
      identifier: phone,
      name: profile.name,
      profile,
    });
    return { success: true, farmer: profile };
  }
  throw new Error('Invalid OTP. Please check SMS code.');
}

// 2. Operator Auth
export async function authenticateOperator(
  vleId: string,
  pin: string
): Promise<{ success: boolean; operator: OperatorProfile }> {
  const found = INITIAL_OPERATORS.find(
    (op) => op.vle_id.toLowerCase() === vleId.trim().toLowerCase()
  );
  if (found || pin === '1234' || pin === '4321') {
    const op = found || {
      vle_id: vleId,
      center_name: 'Gram Panchayat CSC Center',
      operator_name: 'VLE Operator',
      phone: '98480 00000',
      email: `${vleId.toLowerCase()}@csc.gov.in`,
      role: vleId.includes('ADMIN') ? 'District Admin' : 'VLE',
    };
    setStoredSession({
      role: op.role === 'District Admin' ? 'admin' : 'operator',
      identifier: op.vle_id,
      name: op.operator_name,
      profile: op,
    });
    return { success: true, operator: op };
  }
  throw new Error('Invalid Operator ID or PIN.');
}

// 3. Buyer Auth
export async function authenticateBuyer(
  emailOrLicense: string,
  password?: string
): Promise<{ success: boolean; buyer: BuyerProfile }> {
  const cleanInput = emailOrLicense.trim().toLowerCase();
  const buyer = localBuyers.find(
    (b) =>
      b.email.toLowerCase() === cleanInput ||
      b.trader_license.toLowerCase() === cleanInput ||
      b.buyer_id.toLowerCase() === cleanInput ||
      b.business_name.toLowerCase().includes(cleanInput)
  );

  if (buyer) {
    setStoredSession({
      role: 'buyer',
      identifier: buyer.email,
      name: buyer.business_name,
      profile: buyer,
    });
    return { success: true, buyer };
  }

  // Fallback demo matching for any input
  const fallback = localBuyers[0];
  setStoredSession({
    role: 'buyer',
    identifier: fallback.email,
    name: fallback.business_name,
    profile: fallback,
  });
  return { success: true, buyer: fallback };
}
