import React, { useState } from 'react';
import { Download, Copy, Check, FileCode, Terminal, PlayCircle } from 'lucide-react';

interface PythonScriptViewerProps {
  pythonCode: string;
}

export const PythonScriptViewer: React.FC<PythonScriptViewerProps> = ({ pythonCode }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(pythonCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([pythonCode], { type: 'text/x-python;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'app.py');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const lineCount = pythonCode.split('\n').length;

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Top Banner */}
      <div className="p-5 border-b border-gray-100 flex flex-wrap items-center justify-between gap-4 bg-gray-50/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 bg-sky-100 text-sky-700 rounded-md">
              <FileCode className="w-4 h-4" />
            </span>
            <h3 className="text-base font-bold text-gray-900">
              Single-File Streamlit Application (app.py)
            </h3>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
              {lineCount} Lines • Production Ready
            </span>
          </div>
          <p className="text-xs text-gray-500">
            Autonomous single-file Python script implementing pure deterministic Operations Research logic, Folium GIS routing, Plotly price discovery, and VLE anti-corruption layer.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-800 flex items-center gap-1.5 border border-gray-300 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied to Clipboard!' : 'Copy Code'}
          </button>
          <button
            onClick={handleDownload}
            className="px-4 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Download app.py
          </button>
        </div>
      </div>

      {/* Terminal Quickstart instructions */}
      <div className="px-5 py-3 bg-[#0F172A] text-gray-300 text-xs font-mono flex flex-wrap items-center justify-between gap-3 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="text-gray-400">Run Locally:</span>
          <span className="text-emerald-300">pip install streamlit pandas numpy plotly folium streamlit-folium</span>
          <span className="text-gray-600">&&</span>
          <span className="text-sky-300 font-bold">streamlit run app.py</span>
        </div>
        <div className="text-[11px] text-gray-400">
          Target Python Version: 3.9+ (No ML / No GPU dependencies)
        </div>
      </div>

      {/* Code Display Area */}
      <div className="p-4 bg-[#090D16] text-gray-200 font-mono text-xs overflow-x-auto max-h-[600px] select-text">
        <pre className="leading-relaxed">
          <code>{pythonCode}</code>
        </pre>
      </div>
    </div>
  );
};
